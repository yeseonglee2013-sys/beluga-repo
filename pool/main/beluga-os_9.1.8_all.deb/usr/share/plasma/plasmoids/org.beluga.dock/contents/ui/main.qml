/*
    Beluga OS 독 (Beluga 자체 제작)
    - 마우스를 대면 근처 아이콘들이 물결처럼 커짐 (맥 독 확대)
    - 앱을 켜는 동안 아이콘이 통통 튐
    - 실행 중인 앱 아래 점, 이름 말풍선, 오른쪽 클릭 메뉴(새 창 / 독에 고정·해제 / 종료)
    - 맨 끝 휴지통
    앱 목록·창 정보는 KDE의 TaskManager 모듈에서 받아오고, 화면은 전부 여기서 그림.
    SPDX-License-Identifier: GPL-2.0-or-later
*/
import QtQuick
import QtQuick.Layouts

import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.extras as PlasmaExtras
import org.kde.kirigami as Kirigami
import org.kde.taskmanager as TaskManager
import org.kde.plasma.private.taskmanager as TaskManagerApplet

PlasmoidItem {
    id: dock

    preferredRepresentation: fullRepresentation
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground

    // ---- 크기 ----
    readonly property real iconSize: Plasmoid.configuration.iconSize          // 평소 아이콘 크기
    readonly property real maxScale: Plasmoid.configuration.magnification     // 마우스 바로 아래 아이콘 배율
    readonly property real gap: Math.round(iconSize * 0.18)                   // 아이콘 사이 간격
    readonly property real pad: Math.round(iconSize * 0.2)                    // 독 배경 안쪽 여백
    readonly property real sigma: iconSize * 1.15                             // 확대가 퍼지는 폭
    readonly property int itemCount: taskRepeater.count + 1                   // 앱들 + 휴지통
    // 평소 폭 + 확대될 때 늘어나는 만큼 미리 확보 (패널 크기가 출렁이지 않게)
    readonly property real restWidth: itemCount * (iconSize + gap) + pad * 2 + separatorWidth
    readonly property real separatorWidth: gap * 2 + 1

    Layout.minimumWidth: restWidth + iconSize * (maxScale - 1) * 2.2
    Layout.preferredWidth: Layout.minimumWidth
    Layout.fillHeight: true

    // 마우스 위치 (독 안에 있을 때만), 부드럽게 따라감
    property real mouseX: -1
    property bool hovering: false
    property real hoverAmount: hovering ? 1 : 0
    Behavior on hoverAmount { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }

    function scaleAt(centerX) {
        if (dock.mouseX < 0) return 1;
        const d = centerX - dock.mouseX;
        return 1 + (dock.maxScale - 1) * Math.exp(-(d * d) / (2 * dock.sigma * dock.sigma)) * dock.hoverAmount;
    }

    // ---- 앱 / 창 목록 (KDE) ----
    TaskManager.TasksModel {
        id: tasksModel
        sortMode: TaskManager.TasksModel.SortManual
        groupMode: TaskManager.TasksModel.GroupApplications
        separateLaunchers: false        // 고정된 앱을 켜면 그 자리에서 실행 중으로 바뀜 (맥처럼)
        launchInPlace: true
        filterByScreen: false
        filterByVirtualDesktop: false
        filterByActivity: true
        filterNotMinimized: false
        onLauncherListChanged: Plasmoid.configuration.launchers = launcherList
        Component.onCompleted: {
            launcherList = Plasmoid.configuration.launchers;
            taskRepeater.model = tasksModel;
        }
    }
    TaskManagerApplet.Backend { id: backend }

    function isPinned(url) { return tasksModel.launcherPosition(url) !== -1; }

    // ---- 화면 ----
    Item {
        id: stage
        anchors.fill: parent

        // 마우스 추적 (클릭은 아래 아이콘들이 받음)
        MouseArea {
            id: tracker
            anchors.fill: parent
            hoverEnabled: true
            acceptedButtons: Qt.NoButton
            onPositionChanged: mouse => { dock.mouseX = mouse.x; dock.hovering = true; }
            onEntered: dock.hovering = true
            onExited: { dock.hovering = false; leaveTimer.restart(); }
        }
        Timer { id: leaveTimer; interval: 200; onTriggered: if (!dock.hovering) dock.mouseX = -1 }

        // 독 배경 (유리판): 아이콘 줄 폭을 따라 늘었다 줄었다
        Rectangle {
            id: plate
            anchors.bottom: parent.bottom
            anchors.bottomMargin: Math.round(dock.iconSize * 0.08)
            anchors.horizontalCenter: parent.horizontalCenter
            width: row.width + dock.pad * 2
            height: dock.iconSize + dock.pad * 2
            radius: Math.round(dock.iconSize * 0.36)
            color: Qt.rgba(1, 1, 1, 0.42)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.55)
            Rectangle {   // 바깥 가는 테두리 (밝은 배경에서도 독이 보이게)
                anchors.fill: parent
                anchors.margins: -1
                radius: parent.radius + 1
                color: "transparent"
                border.width: 1
                border.color: Qt.rgba(0, 0, 0, 0.12)
            }
        }

        Row {
            id: row
            anchors.bottom: plate.bottom
            anchors.bottomMargin: dock.pad
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 0

            Repeater {
                id: taskRepeater
                delegate: DockIcon {
                    dockRoot: dock
                    tasks: tasksModel
                    backendRef: backend
                }
            }

            // 구분선
            Item {
                width: dock.separatorWidth
                height: dock.iconSize
                Rectangle {
                    anchors.centerIn: parent
                    width: 1
                    height: parent.height * 0.75
                    color: Qt.rgba(0, 0, 0, 0.18)
                }
            }

            // 휴지통
            DockIcon {
                dockRoot: dock
                isTrash: true
                index: -1
                model: null
            }
        }
    }
}
