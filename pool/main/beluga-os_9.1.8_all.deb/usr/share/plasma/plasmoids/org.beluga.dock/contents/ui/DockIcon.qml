/*
    Beluga 독 아이콘 하나: 확대 / 튀기 / 실행 중 점 / 이름 말풍선 / 클릭 / 오른쪽 클릭 메뉴
    SPDX-License-Identifier: GPL-2.0-or-later
*/
import QtQuick

import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.extras as PlasmaExtras
import org.kde.kirigami as Kirigami
import org.kde.taskmanager as TaskManager

Item {
    id: cell

    required property Item dockRoot
    property var tasks: null            // TasksModel (휴지통은 없음)
    property var backendRef: null
    property bool isTrash: false

    // Repeater가 넣어주는 값 (휴지통은 없음)
    required property int index
    required property var model

    readonly property real s: dockRoot.iconSize
    readonly property real slotW: s + dockRoot.gap
    // 평소(확대 전) 자리의 가운데 x → 이걸로 배율 계산 (실제 자리로 계산하면 서로 밀어내며 떨림)
    readonly property int slot: isTrash ? dockRoot.itemCount - 1 : index
    readonly property real restRowWidth: dockRoot.itemCount * slotW + dockRoot.separatorWidth
    readonly property real restCenter: (dockRoot.width - restRowWidth) / 2 + slot * slotW + slotW / 2
                                       + (isTrash ? dockRoot.separatorWidth : 0)
    readonly property real zoom: dockRoot.scaleAt(restCenter)

    readonly property bool running: !isTrash && model && model.IsWindow === true
    readonly property bool starting: !isTrash && model && model.IsStartup === true

    width: s * zoom + dockRoot.gap
    height: s * zoom

    // ---- 튀기 (앱 켜는 중) ----
    property real bounce: 0
    SequentialAnimation {
        id: bounceAnim
        loops: 3
        NumberAnimation { target: cell; property: "bounce"; to: cell.s * 0.55; duration: 260; easing.type: Easing.OutQuad }
        NumberAnimation { target: cell; property: "bounce"; to: 0; duration: 260; easing.type: Easing.InQuad }
    }
    onStartingChanged: if (starting) bounceAnim.restart()
    function launchBounce() { bounceAnim.restart(); }

    Kirigami.Icon {
        id: image
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: cell.bounce
        width: cell.s * cell.zoom
        height: width
        source: cell.isTrash ? "user-trash" : (cell.model ? cell.model.decoration : "")
        active: mouse.containsMouse
        smooth: true
        // 누르는 동안 살짝 어둡게
        opacity: mouse.pressed ? 0.7 : 1
    }

    // 실행 중 점
    Rectangle {
        visible: cell.running
        width: Math.max(4, Math.round(cell.s * 0.09))
        height: width
        radius: width / 2
        color: Qt.rgba(0.1, 0.1, 0.12, 0.85)
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.bottom
        anchors.topMargin: Math.round(dockRoot.pad * 0.3)
    }

    // 이름 말풍선 (KDE 툴팁 창이라 독 밖 위쪽에 뜸)
    PlasmaCore.ToolTipArea {
        anchors.fill: parent
        mainText: cell.isTrash ? "휴지통" : (cell.model ? cell.model.display : "")
        location: PlasmaCore.Types.BottomEdge
        interactive: false
    }

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
        onPositionChanged: m => { const p = mapToItem(dockRoot, m.x, m.y); dockRoot.mouseX = p.x; dockRoot.hovering = true; }
        onEntered: dockRoot.hovering = true
        onClicked: m => {
            if (cell.isTrash) {
                if (m.button === Qt.LeftButton) Qt.openUrlExternally("trash:/");
                return;
            }
            const idx = cell.tasks.makeModelIndex(cell.index);
            if (m.button === Qt.RightButton) { cell.openMenu(); return; }
            if (m.button === Qt.MiddleButton) { cell.tasks.requestNewInstance(idx); cell.launchBounce(); return; }
            if (cell.model.IsLauncher || cell.model.IsStartup) {
                cell.tasks.requestActivate(idx);          // 고정된 앱 켜기
                cell.launchBounce();
            } else if (cell.model.IsGroupParent) {
                // 창이 여러 개: 맨 위 창을 앞으로 (이미 앞이면 전부 최소화)
                if (cell.model.IsActive) cell.tasks.requestToggleMinimized(idx);
                else cell.tasks.requestActivate(cell.tasks.makeModelIndex(cell.index, 0));
            } else if (cell.model.IsActive) {
                cell.tasks.requestToggleMinimized(idx);   // 맥처럼: 앞에 있는 앱 다시 누르면 내려감
            } else {
                cell.tasks.requestActivate(idx);
            }
        }
    }

    // 최소화할 때 창이 이 아이콘으로 빨려 들어가도록 위치 알려줌 (지니 효과)
    Timer {
        interval: 400; running: cell.running; repeat: false
        onTriggered: if (cell.tasks) cell.tasks.requestPublishDelegateGeometry(
                         cell.tasks.makeModelIndex(cell.index), cell.backendRef.globalRect(cell), cell)
    }
    onRunningChanged: if (running && tasks) tasks.requestPublishDelegateGeometry(
                          tasks.makeModelIndex(index), backendRef.globalRect(cell), cell)

    // ---- 오른쪽 클릭 메뉴 ----
    function openMenu() {
        const m = menuComponent.createObject(cell);
        m.visualParent = cell;
        m.openRelative();
    }
    Component {
        id: menuComponent
        PlasmaExtras.Menu {
            id: menu
            placement: PlasmaExtras.Menu.TopPosedCenterAlignedPopup
            onStatusChanged: if (status === PlasmaExtras.Menu.Closed) menu.destroy()
            readonly property var launcherUrl: cell.model ? cell.model.LauncherUrlWithoutIcon : ""
            readonly property bool pinned: launcherUrl.toString() !== "" && dockRoot.isPinned(launcherUrl)

            PlasmaExtras.MenuItem {
                text: "새 창"
                icon: "window-new"
                visible: menu.launcherUrl.toString() !== ""
                onClicked: { cell.tasks.requestNewInstance(cell.tasks.makeModelIndex(cell.index)); cell.launchBounce(); }
            }
            PlasmaExtras.MenuItem {
                text: menu.pinned ? "독에서 빼기" : "독에 고정"
                icon: menu.pinned ? "window-unpin" : "window-pin"
                visible: menu.launcherUrl.toString() !== ""
                onClicked: menu.pinned ? cell.tasks.requestRemoveLauncher(menu.launcherUrl)
                                       : cell.tasks.requestAddLauncher(cell.model.LauncherUrl)
            }
            PlasmaExtras.MenuItem { separator: true; visible: cell.running }
            PlasmaExtras.MenuItem {
                text: "종료"
                icon: "application-exit"
                visible: cell.running
                onClicked: cell.tasks.requestClose(cell.tasks.makeModelIndex(cell.index))
            }
        }
    }
}
