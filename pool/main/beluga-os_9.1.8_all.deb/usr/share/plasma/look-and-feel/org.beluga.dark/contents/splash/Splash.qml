/*
    Beluga OS 로그인 직후 로딩 화면: 부팅 화면과 똑같이 (남색 배경 + 벨루가 로고 + 도는 점 8개)
    구조는 KDE Breeze 로딩 화면(Marco Martin, GPL-2.0-or-later)과 같게 → 이 Plasma 버전에서 확실히 동작
    SPDX-License-Identifier: GPL-2.0-or-later
*/
import QtQuick

Rectangle {
    id: root
    color: "#21398a"

    property int stage      // KSplash가 단계마다 올려줌 (끝나면 KDE가 알아서 닫음)

    onStageChanged: {
        if (stage == 2) {
            introAnimation.running = true;
        }
    }

    Item {
        id: content
        anchors.fill: parent
        opacity: 0

        Image {
            id: logo
            readonly property real size: Math.round(root.height * 0.22)
            anchors.horizontalCenter: parent.horizontalCenter
            y: Math.round(root.height * 0.40 - size / 2)
            width: size
            height: size
            asynchronous: true
            smooth: true
            fillMode: Image.PreserveAspectFit
            source: "images/logo.png"
        }

        // 도는 점 8개 (부팅 화면과 같은 모양)
        Item {
            id: spinner
            property int head: 0
            width: Math.round(root.height * 0.052)
            height: width
            anchors.horizontalCenter: parent.horizontalCenter
            y: Math.round(root.height * 0.72 - height / 2)
            Repeater {
                model: 8
                Image {
                    source: "images/dot.png"
                    width: Math.max(4, Math.round(root.height * 0.0105))
                    height: width
                    smooth: true
                    asynchronous: true
                    readonly property real a: index * 2 * Math.PI / 8
                    x: spinner.width / 2 + Math.sin(a) * spinner.width / 2 - width / 2
                    y: spinner.height / 2 - Math.cos(a) * spinner.height / 2 - height / 2
                    opacity: Math.max(0.12, 1.0 - ((spinner.head - index + 8) % 8) * 0.16)
                }
            }
            Timer {
                interval: 90
                running: true
                repeat: true
                onTriggered: spinner.head = (spinner.head + 1) % 8
            }
        }
    }

    OpacityAnimator {
        id: introAnimation
        running: false
        target: content
        from: 0
        to: 1
        duration: 500
        easing.type: Easing.InOutQuad
    }
}
