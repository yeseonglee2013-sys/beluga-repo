/*
    Beluga OS 설치 중 슬라이드 (Beluga 자체 제작, Calamares slideshow API 2)
    남색 배경 + 벨루가 로고 + 한국어 안내가 6초마다 바뀜
    SPDX-License-Identifier: GPL-3.0-or-later
*/
import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation
{
    id: presentation

    Timer {
        interval: 6000
        running: true
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    Rectangle { anchors.fill: parent; color: "#21398a"; z: -1 }

    component BelugaSlide: Slide {
        property string title
        property string body
        Image {
            id: logo
            source: "beluga-logo.png"
            width: 150; height: 150
            fillMode: Image.PreserveAspectFit
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.topMargin: parent.height * 0.12
            smooth: true
        }
        Text {
            id: t
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: logo.bottom
            anchors.topMargin: 28
            text: title
            color: "white"
            font.pixelSize: 26
            font.bold: true
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: t.bottom
            anchors.topMargin: 14
            width: Math.min(parent.width * 0.8, 620)
            text: body
            color: "#dde6ff"
            font.pixelSize: 16
            wrapMode: Text.WordWrap
            horizontalAlignment: Text.AlignHCenter
            lineHeight: 1.3
        }
    }

    BelugaSlide { title: "Beluga OS를 설치하고 있어요"; body: "몇 분이면 끝나요. 끝나면 USB를 뽑고 다시 시작하면 돼요." }
    BelugaSlide { title: "맥처럼 예쁜 화면"; body: "위에는 메뉴바, 아래에는 독. 창 버튼은 빨강·노랑·초록이에요.\n다크 모드도 설정에서 바로 바꿀 수 있어요." }
    BelugaSlide { title: "로블록스 · 로블록스 스튜디오"; body: "바탕화면 아이콘이나 독에서 바로 켤 수 있어요." }
    BelugaSlide { title: "윈도우 프로그램(exe)도 열 수 있어요"; body: "exe 파일을 더블클릭하면 빠르게 열기(Bottles)나 윈도우로 열기(가상머신)를 고를 수 있어요." }
    BelugaSlide { title: "업데이트는 Beluga가 챙겨요"; body: "Beluga가 확인한 업데이트만 한꺼번에 들어와요. 알림이 오면 눌러서 설치하세요." }
}
