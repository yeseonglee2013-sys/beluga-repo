D2Coding: SIL Open Font License 1.1 (c) NAVER Corp. https://github.com/naver/d2codingfont
Pretendard: SIL Open Font License 1.1 (Pretendard-LICENSE.txt) https://github.com/orioncactus/pretendard
