# Beluga 콘솔 기본 모양 (2026-11-05, 개편 계획 G2)
[Appearance]
ColorScheme=Beluga
Font=D2Coding,11,-1,5,400,0,0,0,0,0,0,0,0,0,0,1

[General]
Name=Beluga
Parent=FALLBACK/
TerminalMargin=10

[Scrolling]
HistoryMode=2
