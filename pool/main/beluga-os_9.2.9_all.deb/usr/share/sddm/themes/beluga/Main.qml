// Beluga OS 로그인 화면 (SDDM 테마, 2026-11-05) — 디자인 규칙 A: 단정, 강조색 #185FA5, 모서리 4/6/8, Pretendard
//  가운데: 큰 시계 · 날짜 / 그 아래 카드: 사진 · 이름 · 비밀번호 · 들어가기
//  아래 왼쪽: 화면 종류(세션) / 아래 오른쪽: 절전 · 다시 시작 · 끄기
import QtQuick
import QtQuick.Controls
import QtQuick.Effects
import SddmComponents 2.0

Rectangle {
    id: root
    width: 1920
    height: 1080
    color: "#16181C"
    readonly property color accent: config.accent || "#185FA5"
    readonly property string fontName: "Pretendard Variable"
    property int userIndex: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
    property int sessionIndex: sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0
    property string userName: ""
    property string realName: ""
    property string faceIcon: ""
    property string sessionName: ""
    property bool busy: false

    function pick(n, r, i) { userName = n; realName = r || n; faceIcon = i || "" }
    function login() {
        if (busy || !userName) return
        busy = true
        err.text = ""
        sddm.login(userName, pw.text, sessionIndex)
    }

    // 지금 고른 사용자 이름/사진 (userModel은 목록이라 Repeater로 그 한 칸만 읽음)
    Repeater {
        model: userModel
        delegate: Item {
            required property int index
            required property string name
            required property string realName
            required property string icon
            function sync() { if (index === root.userIndex) root.pick(name, realName, icon) }
            Component.onCompleted: sync()
            Connections { target: root; function onUserIndexChanged() { sync() } }
        }
    }
    Repeater {
        model: sessionModel
        delegate: Item {
            required property int index
            required property string name
            function sync() { if (index === root.sessionIndex) root.sessionName = name }
            Component.onCompleted: sync()
            Connections { target: root; function onSessionIndexChanged() { sync() } }
        }
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            root.busy = false
            pw.text = ""
            err.text = "비밀번호가 맞지 않아요. 다시 입력해 주세요."
            shake.restart()
            pw.forceActiveFocus()
        }
        function onLoginSucceeded() { fadeOut.start() }
    }

    // ---- 배경: 벨루가 바탕화면 + 살짝 흐리고 어둡게 ----
    Image {
        id: bg
        anchors.fill: parent
        source: config.background
        fillMode: Image.PreserveAspectCrop
        visible: false
    }
    MultiEffect {
        anchors.fill: bg
        source: bg
        blurEnabled: true
        blur: 0.5
        blurMax: 48
        brightness: -0.1
    }
    Rectangle { anchors.fill: parent; color: "#000000"; opacity: 0.18 }

    // ---- 시계 ----
    Column {
        id: clock
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.16
        spacing: 4
        Text {
            id: timeT
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#FFFFFF"
            font.family: root.fontName
            font.pixelSize: Math.round(root.height * 0.1)
            font.weight: Font.DemiBold
            text: Qt.formatTime(new Date(), "HH:mm")
        }
        Text {
            id: dateT
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#E8EAED"
            font.family: root.fontName
            font.pixelSize: 20
            text: Qt.locale("ko_KR").toString(new Date(), "M월 d일 dddd")
        }
        Timer {
            interval: 1000
            repeat: true
            running: true
            onTriggered: {
                timeT.text = Qt.formatTime(new Date(), "HH:mm")
                dateT.text = Qt.locale("ko_KR").toString(new Date(), "M월 d일 dddd")
            }
        }
    }

    // ---- 로그인 카드 ----
    Rectangle {
        id: card
        width: 360
        height: col.implicitHeight + 48
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: clock.bottom
        anchors.topMargin: root.height * 0.07
        radius: 8
        color: Qt.rgba(0.086, 0.094, 0.11, 0.72)
        border.color: Qt.rgba(1, 1, 1, 0.08)
        border.width: 1
        transform: Translate { id: shakeX; x: 0 }
        SequentialAnimation {
            id: shake
            loops: 2
            NumberAnimation { target: shakeX; property: "x"; to: -8; duration: 40 }
            NumberAnimation { target: shakeX; property: "x"; to: 8; duration: 60 }
            NumberAnimation { target: shakeX; property: "x"; to: 0; duration: 40 }
        }

        Column {
            id: col
            anchors.centerIn: parent
            width: parent.width - 48
            spacing: 12

            // 사진 (동그라미)
            Item {
                width: 80
                height: 80
                anchors.horizontalCenter: parent.horizontalCenter
                Image {
                    id: face
                    anchors.fill: parent
                    source: root.faceIcon !== "" ? root.faceIcon : "/usr/share/sddm/faces/.face.icon"
                    onStatusChanged: if (status === Image.Error) source = "/usr/share/sddm/faces/.face.icon"
                    fillMode: Image.PreserveAspectCrop
                    sourceSize: Qt.size(160, 160)
                    visible: false
                }
                Rectangle { id: faceMask; anchors.fill: parent; radius: width / 2; visible: false; layer.enabled: true }
                MultiEffect {
                    anchors.fill: parent
                    source: face
                    maskEnabled: true
                    maskSource: faceMask
                }
            }
            // 이름 (사용자가 여럿이면 양옆 화살표로 바꾸기)
            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 8
                SmallBtn {
                    visible: userModel.count > 1
                    label: "‹"
                    onClicked: root.userIndex = (root.userIndex + userModel.count - 1) % userModel.count
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.realName
                    color: "#FFFFFF"
                    font.family: root.fontName
                    font.pixelSize: 20
                    font.weight: Font.DemiBold
                }
                SmallBtn {
                    visible: userModel.count > 1
                    label: "›"
                    onClicked: root.userIndex = (root.userIndex + 1) % userModel.count
                }
            }
            // 비밀번호 + 들어가기
            Row {
                width: parent.width
                spacing: 8
                TextField {
                    id: pw
                    width: parent.width - go.width - 8
                    height: 40
                    echoMode: TextInput.Password
                    passwordCharacter: "●"
                    placeholderText: "비밀번호"
                    placeholderTextColor: "#9AA0AA"
                    color: "#FFFFFF"
                    font.family: root.fontName
                    font.pixelSize: 15
                    leftPadding: 12
                    focus: true
                    enabled: !root.busy
                    background: Rectangle {
                        radius: 4
                        color: Qt.rgba(1, 1, 1, 0.08)
                        border.width: 1
                        border.color: pw.activeFocus ? root.accent : Qt.rgba(1, 1, 1, 0.14)
                    }
                    Keys.onReturnPressed: root.login()
                    Keys.onEnterPressed: root.login()
                    onTextChanged: if (text !== "") err.text = ""
                }
                Rectangle {
                    id: go
                    width: 40
                    height: 40
                    radius: 4
                    color: goMouse.pressed ? Qt.darker(root.accent, 1.15) : (goMouse.containsMouse ? Qt.lighter(root.accent, 1.12) : root.accent)
                    Text {
                        anchors.centerIn: parent
                        text: root.busy ? "…" : "→"
                        color: "#FFFFFF"
                        font.pixelSize: 18
                        font.family: root.fontName
                    }
                    MouseArea {
                        id: goMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.login()
                    }
                }
            }
            Text {
                id: err
                width: parent.width
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                color: "#FF8A89"
                font.family: root.fontName
                font.pixelSize: 13
                visible: text !== ""
            }
            Text {
                width: parent.width
                horizontalAlignment: Text.AlignHCenter
                visible: keyboard.capsLock
                text: "Caps Lock이 켜져 있어요"
                color: "#E8C36A"
                font.family: root.fontName
                font.pixelSize: 13
            }
        }
    }

    // ---- 아래 왼쪽: 화면 종류 (Beluga / 예비 X11), 누르면 다음 것으로 ----
    SmallBtn {
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.margins: 24
        visible: sessionModel.rowCount() > 1
        label: root.sessionName
        onClicked: root.sessionIndex = (root.sessionIndex + 1) % sessionModel.rowCount()
    }

    // ---- 아래 오른쪽: 전원 ----
    Row {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 24
        spacing: 8
        SmallBtn { label: "절전"; visible: sddm.canSuspend; onClicked: sddm.suspend() }
        SmallBtn { label: "다시 시작"; visible: sddm.canReboot; onClicked: sddm.reboot() }
        SmallBtn { label: "끄기"; visible: sddm.canPowerOff; onClicked: sddm.powerOff() }
    }

    // 들어갈 때 화면이 부드럽게 어두워짐 (바탕화면 뜨기 전 번쩍임 없이)
    Rectangle { id: veil; anchors.fill: parent; color: "#16181C"; opacity: 0 }
    NumberAnimation { id: fadeOut; target: veil; property: "opacity"; to: 1; duration: 250; easing.type: Easing.OutCubic }

    Component.onCompleted: pw.forceActiveFocus()

    // 작은 글자 버튼 (반투명 칸, 모서리 4)
    component SmallBtn: Rectangle {
        id: sb
        property string label: ""
        signal clicked()
        width: Math.max(40, t.implicitWidth + 24)
        height: 32
        radius: 4
        color: m.pressed ? Qt.rgba(1, 1, 1, 0.18) : (m.containsMouse ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(1, 1, 1, 0.08))
        Text {
            id: t
            anchors.centerIn: parent
            text: sb.label
            color: "#E8EAED"
            font.family: root.fontName
            font.pixelSize: 13
        }
        MouseArea {
            id: m
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sb.clicked()
        }
    }
}
