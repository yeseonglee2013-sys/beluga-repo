// Beluga OS 기본 화면 배치 (2026-11-05 대개편, docs/개편-계획.md A1~A8)
//   위: 얇은 바 하나 — 왼쪽 벨루가 로고(누르면 가운데 검색창) ......... 한/영 | 상태칸(블루투스·와이파이·소리·배터리·알림)
//   아래: 작업 표시줄/독 없음
//   바탕화면: 큰 시계 + 잔잔하게 움직이는 배경화면, 위젯은 오른쪽 클릭으로 추가
// 새 사용자: KDE가 이 파일로 처음 화면을 만듦 (모든 테마의 레이아웃 파일이 이 파일과 같음 → 테마를 바꿔도 Beluga 화면)

// 이미 있는 패널은 지우고 새로 (기존 사용자에게 다시 적용할 때)
var old = panels();
for (var i = 0; i < old.length; i++) old[i].remove();

// ---- 위쪽 바 ----
var bar = new Panel;
bar.location = "top";
bar.height = 2 * Math.floor(gridUnit * 1.8 / 2);
bar.floating = false;
bar.lengthMode = "fill";
bar.opacity = "translucent";
bar.hiding = "none";

bar.addWidget("org.beluga.logo");                             // 벨루가 로고 = 검색창 열기 (윈도우 키와 같음)
bar.addWidget("org.kde.plasma.panelspacer");
bar.addWidget("org.kde.plasma.kimpanel");                     // 한 | 한국어
var tray = bar.addWidget("org.kde.plasma.systemtray");        // 블루투스·와이파이·소리·배터리·알림 (알약 모양 칸)
tray.currentConfigGroup = ["General"];
tray.writeConfig("scaleIconsToFit", "false");

// ---- 바탕화면: 배경 + 큰 시계 ----
var desktopsArray = desktopsForActivity(currentActivity());
for (var j = 0; j < desktopsArray.length; j++) {
    var d = desktopsArray[j];
    d.wallpaperPlugin = "org.beluga.live";
    d.currentConfigGroup = ["Wallpaper", "org.beluga.live", "General"];
    d.writeConfig("Source", "file:///usr/share/wallpapers/Beluga/contents/images/3840x2160.jpg");
    var g = screenGeometry(d.screen);
    var w = Math.round(g.width * 0.32), h = Math.round(g.height * 0.2);
    d.addWidget("org.beluga.clock", Math.round((g.width - w) / 2), Math.round(g.height * 0.1), w, h);
}
