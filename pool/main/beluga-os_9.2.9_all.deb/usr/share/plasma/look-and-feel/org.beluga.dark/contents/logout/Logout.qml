/*
    SPDX-FileCopyrightText: 2014 Aleix Pol Gonzalez <aleixpol@blue-systems.com>

    SPDX-License-Identifier: GPL-2.0-or-later

    Beluga OS 종료 화면 (2026-11-05 개편, 사용자 사진 기준)
    - 가운데 둥근 카드: 프로필 사진 + "안녕히 계세요 ○○○" / 구분선 / 2줄 × 3칸 타일
      세션 잠금 · 로그아웃 · 전원 끄기 / 재부팅 · 절전 · 최대 절전
    - 라이트/다크 자동 (시스템 색을 보고 판단)
    - 화살표 키로 이동, Enter로 실행, Esc 또는 바깥 클릭으로 취소
    - 종료/재부팅/절전 등 실제 동작은 KDE 원본 신호 그대로 (검증된 동작)
*/

import QtQuick 2.15
import QtQuick.Layouts 1.2
import QtQuick.Controls 2.12 as QQC2

import org.kde.plasma.components 3.0 as PlasmaComponents
import org.kde.coreaddons 1.0 as KCoreAddons
import org.kde.kirigami 2.20 as Kirigami

import "timer.js" as AutoTriggerTimer

import org.kde.plasma.private.sessions

Item {
    id: root
    Kirigami.Theme.inherit: false
    Kirigami.Theme.colorSet: Kirigami.Theme.Window
    height: screenGeometry.height
    width: screenGeometry.width

    signal logoutRequested()
    signal haltRequested()
    signal haltUpdateRequested()
    signal suspendRequested(int spdMethod)
    signal rebootRequested()
    signal rebootRequested2(int opt)
    signal rebootUpdateRequested()
    signal cancelRequested()
    signal lockScreenRequested()
    signal cancelSoftwareUpdateRequested()

    property alias backgroundColor: backgroundRect.color

    function sleepRequested() { root.suspendRequested(2); }
    function hibernateRequested() { root.suspendRequested(4); }

    property real timeout: 30
    property real remainingTime: root.timeout

    property var currentAction: {
        switch (sdtype) {
        case ShutdownType.ShutdownTypeReboot:
            return () => softwareUpdatePending ? rebootUpdateRequested() : rebootRequested();
        case ShutdownType.ShutdownTypeHalt:
            return () => softwareUpdatePending ? haltUpdateRequested() : haltRequested();
        default:
            return () => logoutRequested();
        }
    }

    readonly property bool showAllOptions: sdtype === ShutdownType.ShutdownTypeDefault

    // ---- 색 (라이트/다크) ----
    function isLightColor(c) { return Math.max(c.r, c.g, c.b) > 0.5 }
    readonly property bool light: isLightColor(Kirigami.Theme.backgroundColor)
    readonly property color cardColor:   light ? "#f7f9fb" : "#202226"
    readonly property color tileColor:   light ? "#e6edf3" : "#1c2a36"
    readonly property color tileHover:   light ? "#d6e2ec" : "#25384a"
    readonly property color tileFocus:   "#21398a"                       // 벨루가 남색
    readonly property color textColor:   light ? "#1b1d21" : "#f2f4f7"
    readonly property color lineColor:   light ? "#cfd6dd" : "#4a4d52"

    KCoreAddons.KUser { id: kuser }

    SessionsModel {
        id: sessionsModel
        includeUnusedSessions: false
    }

    QQC2.Action {
        onTriggered: root.cancelRequested()
        shortcut: "Escape"
    }

    onRemainingTimeChanged: {
        if (remainingTime <= 0) {
            (currentAction)();
        }
    }

    Timer {
        id: countDownTimer
        running: !showAllOptions
        repeat: true
        interval: 1000
        onTriggered: remainingTime--
        Component.onCompleted: {
            AutoTriggerTimer.addCancelAutoTriggerCallback(function() {
                countDownTimer.running = false;
            });
        }
    }

    Rectangle {
        id: backgroundRect
        anchors.fill: parent
        color: "black"
        opacity: 0.45
    }
    MouseArea {
        anchors.fill: parent
        onClicked: cancelRequested()
    }

    // ---- 타일 목록: [아이콘, 글자, 보이기, 쓸 수 있음, 동작] ----
    readonly property var tiles: [
        { icon: "system-lock-screen", text: "세션 잠금", enabled: true,
          run: function() { root.lockScreenRequested() } },
        { icon: "system-log-out", text: "로그아웃", enabled: canLogout,
          run: function() { root.logoutRequested() } },
        { icon: softwareUpdatePending ? "system-shutdown-update" : "system-shutdown",
          text: softwareUpdatePending ? "업데이트 후 끄기" : "전원 끄기", enabled: maysd,
          run: function() { softwareUpdatePending ? root.haltUpdateRequested() : root.haltRequested() } },
        { icon: softwareUpdatePending ? "system-reboot-update" : "system-reboot",
          text: softwareUpdatePending ? "업데이트 후 재부팅" : "재부팅", enabled: maysd,
          run: function() { softwareUpdatePending ? root.rebootUpdateRequested() : root.rebootRequested() } },
        { icon: "system-suspend", text: "절전", enabled: spdMethods.SuspendState,
          run: function() { root.sleepRequested() } },
        { icon: "system-suspend-hibernate", text: "최대 절전", enabled: spdMethods.HibernateState,
          run: function() { root.hibernateRequested() } }
    ]
    // 처음 선택: 바로 "재부팅"/"끄기"를 누르고 들어왔으면 그 칸, 아니면 전원 끄기
    property int current: sdtype === ShutdownType.ShutdownTypeReboot ? 3
                        : sdtype === ShutdownType.ShutdownTypeNone ? 1 : 2

    function runTile(i) {
        if (i >= 0 && i < tiles.length && tiles[i].enabled) tiles[i].run();
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Kirigami.Units.gridUnit * 25
        height: column.implicitHeight + Kirigami.Units.gridUnit * 2.5
        radius: 22
        color: root.cardColor
        border.color: Qt.rgba(1, 1, 1, root.light ? 0 : 0.06)
        border.width: 1
        MouseArea { anchors.fill: parent }        // 카드 안을 눌러도 취소 안 됨

        // 나타날 때 살짝 커지면서 보이기
        scale: 0.94
        opacity: 0
        Component.onCompleted: { scale = 1; opacity = 1; tileGrid.forceActiveFocus() }
        Behavior on scale { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
        Behavior on opacity { NumberAnimation { duration: 140 } }

        ColumnLayout {
            id: column
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.margins: Kirigami.Units.gridUnit * 1.25
            spacing: Kirigami.Units.gridUnit

            // 프로필 + 인사
            RowLayout {
                spacing: Kirigami.Units.gridUnit * 0.9
                Rectangle {
                    Layout.preferredWidth: Kirigami.Units.gridUnit * 2.6
                    Layout.preferredHeight: Layout.preferredWidth
                    radius: width / 2
                    color: root.light ? "#c9d3dc" : "#e8eaed"
                    clip: true
                    Image {
                        id: face
                        anchors.fill: parent
                        source: kuser.faceIconUrl
                        sourceSize.width: 128
                        sourceSize.height: 128
                        fillMode: Image.PreserveAspectCrop
                        visible: status === Image.Ready
                    }
                    Kirigami.Icon {
                        anchors.centerIn: parent
                        width: parent.width * 0.62
                        height: width
                        source: "user-identity"
                        color: "#5f6368"
                        isMask: true
                        visible: !face.visible
                    }
                }
                PlasmaComponents.Label {
                    Layout.fillWidth: true
                    text: "안녕히 계세요 " + (kuser.fullName || kuser.loginName)
                    font.pointSize: Kirigami.Theme.defaultFont.pointSize + 3
                    font.bold: true
                    color: root.textColor
                    elide: Text.ElideRight
                    textFormat: Text.PlainText
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 1
                color: root.lineColor
            }

            // 바로 "끄기/재부팅"을 눌러서 들어온 경우: 몇 초 뒤 자동 실행 안내
            PlasmaComponents.Label {
                Layout.fillWidth: true
                visible: countDownTimer.running
                horizontalAlignment: Text.AlignHCenter
                color: root.textColor
                opacity: 0.8
                text: {
                    switch (sdtype) {
                    case ShutdownType.ShutdownTypeReboot: return Math.max(0, root.remainingTime) + "초 뒤 재부팅합니다";
                    case ShutdownType.ShutdownTypeNone: return Math.max(0, root.remainingTime) + "초 뒤 로그아웃합니다";
                    default: return Math.max(0, root.remainingTime) + "초 뒤 전원을 끕니다";
                    }
                }
            }
            PlasmaComponents.Label {
                Layout.fillWidth: true
                visible: sessionsModel.count > 1
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                color: root.textColor
                opacity: 0.8
                text: "다른 사용자 " + (sessionsModel.count - 1) + "명이 로그인해 있어요. 끄거나 재부팅하면 그 사용자의 작업이 사라질 수 있어요."
            }

            // 2줄 × 3칸 타일
            GridLayout {
                id: tileGrid
                Layout.fillWidth: true
                columns: 3
                rowSpacing: Kirigami.Units.gridUnit * 0.75
                columnSpacing: Kirigami.Units.gridUnit * 0.75
                focus: true

                Keys.onLeftPressed:  root.current = (root.current + 5) % 6
                Keys.onRightPressed: root.current = (root.current + 1) % 6
                Keys.onUpPressed:    root.current = (root.current + 3) % 6
                Keys.onDownPressed:  root.current = (root.current + 3) % 6
                Keys.onReturnPressed: root.runTile(root.current)
                Keys.onEnterPressed:  root.runTile(root.current)
                Keys.onSpacePressed:  root.runTile(root.current)

                Repeater {
                    model: root.tiles.length
                    delegate: Rectangle {
                        id: tile
                        required property int index
                        readonly property var info: root.tiles[index]
                        readonly property bool selected: root.current === index
                        Layout.fillWidth: true
                        Layout.preferredHeight: Kirigami.Units.gridUnit * 5
                        radius: 14
                        color: !info.enabled ? root.tileColor
                             : selected ? root.tileFocus
                             : mouse.containsMouse ? root.tileHover : root.tileColor
                        opacity: info.enabled ? 1 : 0.4
                        scale: mouse.pressed ? 0.96 : 1
                        Behavior on color { ColorAnimation { duration: 90 } }
                        Behavior on scale { NumberAnimation { duration: 80 } }

                        ColumnLayout {
                            anchors.centerIn: parent
                            width: parent.width - Kirigami.Units.gridUnit
                            spacing: Kirigami.Units.smallSpacing * 2
                            Kirigami.Icon {
                                Layout.alignment: Qt.AlignHCenter
                                Layout.preferredWidth: Kirigami.Units.iconSizes.medium
                                Layout.preferredHeight: Kirigami.Units.iconSizes.medium
                                source: tile.info.icon
                                color: tile.selected ? "white" : root.textColor
                                isMask: true
                            }
                            PlasmaComponents.Label {
                                Layout.fillWidth: true
                                horizontalAlignment: Text.AlignHCenter
                                wrapMode: Text.WordWrap
                                text: tile.info.text
                                color: tile.selected ? "white" : root.textColor
                                textFormat: Text.PlainText
                            }
                        }
                        MouseArea {
                            id: mouse
                            anchors.fill: parent
                            hoverEnabled: true
                            enabled: tile.info.enabled
                            cursorShape: Qt.PointingHandCursor
                            onEntered: root.current = tile.index
                            onClicked: root.runTile(tile.index)
                        }
                    }
                }
            }
        }
    }
}
