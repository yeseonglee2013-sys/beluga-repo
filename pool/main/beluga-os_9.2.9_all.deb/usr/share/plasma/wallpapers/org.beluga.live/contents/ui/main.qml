/*
    Beluga OS 잔잔한 배경화면 (2026-11-05)
    - 그림: 아주 천천히 커졌다 작아졌다(40초) + 아래에서 위로 떠오르는 작은 물방울
    - 영상: 소리 없이 계속 반복 재생
    SPDX-License-Identifier: GPL-2.0-or-later
*/
import QtQuick
import QtMultimedia
import QtQuick.Particles
import org.kde.plasma.plasmoid

WallpaperItem {
    id: root
    readonly property string src: root.configuration.Source || ""
    readonly property bool isVideo: /\.(mp4|webm|mkv|mov|m4v)$/i.test(src)
    readonly property bool motion: root.configuration.Motion !== false
    readonly property bool bubbles: root.configuration.Bubbles !== false

    Rectangle { anchors.fill: parent; color: "#0b2a4a" }   // 그림이 뜨기 전 / 없을 때 깊은 바다색

    Image {
        id: pic
        visible: !root.isVideo
        anchors.fill: parent
        source: root.isVideo ? "" : root.src
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        cache: false
        sourceSize.width: root.width * 1.1
        sourceSize.height: root.height * 1.1
        transformOrigin: Item.Center
        SequentialAnimation on scale {
            running: root.motion && !root.isVideo && pic.status === Image.Ready
            loops: Animation.Infinite
            NumberAnimation { from: 1.0; to: 1.06; duration: 40000; easing.type: Easing.InOutSine }
            NumberAnimation { from: 1.06; to: 1.0; duration: 40000; easing.type: Easing.InOutSine }
        }
    }

    Video {
        id: vid
        visible: root.isVideo
        anchors.fill: parent
        source: root.isVideo ? root.src : ""
        loops: MediaPlayer.Infinite
        muted: true
        autoPlay: true
        fillMode: VideoOutput.PreserveAspectCrop
    }

    // 물방울: 아래에서 천천히 떠오르며 흔들림
    ParticleSystem {
        id: sys
        anchors.fill: parent
        running: root.bubbles && !root.isVideo
    }
    ImageParticle {
        system: sys
        source: "qrc:///particleresources/glowdot.png"
        color: "#9fd8ff"
        colorVariation: 0.15
        alpha: 0.5
        alphaVariation: 0.3
    }
    Emitter {
        system: sys
        anchors.bottom: parent.bottom
        width: parent.width
        height: 10
        emitRate: Math.max(4, parent.width / 220)
        lifeSpan: 16000
        lifeSpanVariation: 5000
        size: 10
        sizeVariation: 8
        velocity: AngleDirection { angle: 270; angleVariation: 8; magnitude: 70; magnitudeVariation: 30 }
    }
    Wander {
        system: sys
        anchors.fill: parent
        xVariance: 40
        pace: 30
    }
}
