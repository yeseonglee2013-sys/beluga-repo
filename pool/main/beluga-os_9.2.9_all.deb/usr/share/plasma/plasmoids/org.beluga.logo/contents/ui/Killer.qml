// Beluga 프로세스 종료 창 (Ctrl+Shift+Backspace)
//  - 내가 켠 프로그램 전부 (백그라운드 포함, 시스템 부품은 숨김), 램 많이 쓰는 순
//  - 각각 램 / CPU / GPU 사용량, 1초마다 새로고침
//  - 누르면 바로 종료 (같은 앱의 프로세스 전부). 타자 치면 이름으로 거르기. Esc 닫기
import QtQuick
import QtQuick.Controls
import org.kde.kirigami as Kirigami

Item {
    id: root
    signal closed()
    property var shell: null
    property bool shown: false
    property var gone: ({})                   // 방금 종료한 것 (목록에서 바로 사라지게)

    SystemPalette { id: pal }
    readonly property bool light: Math.max(pal.window.r, pal.window.g, pal.window.b) > 0.5
    readonly property color cardColor: light ? "#f7f9fb" : "#1d1f23"
    readonly property color rowColor: light ? Qt.rgba(0, 0, 0, 0.035) : Qt.rgba(1, 1, 1, 0.045)
    readonly property color textColor: light ? "#1b1d21" : "#f2f4f7"
    readonly property color subColor: light ? "#5f6670" : "#a4aab3"
    readonly property color danger: "#E24B4A"

    readonly property var shownList: {
        var q = search.text.trim().toLowerCase()
        var out = []
        var all = shell ? shell.procs : []
        for (var i = 0; i < all.length; i++) {
            var p = all[i]
            if (root.gone[p.key]) continue
            if (q && p.name.toLowerCase().indexOf(q) < 0 && p.key.toLowerCase().indexOf(q) < 0) continue
            out.push(p)
        }
        return out
    }

    function open() {
        gone = ({})
        search.text = ""
        shown = true
        search.forceActiveFocus()
    }
    function close() {
        shown = false
        closeTimer.restart()
    }
    function killApp(p) {
        var g = root.gone; g[p.key] = true; root.gone = g
        shell.killPids(p.pids)
    }
    Timer { id: closeTimer; interval: 130; onTriggered: root.closed() }
    // 종료한 앱이 다시 켜지면 다시 보이게 (3초 뒤 표시 지움)
    Timer { interval: 3000; running: root.shown; repeat: true; onTriggered: root.gone = ({}) }

    Rectangle {
        anchors.fill: parent
        color: "black"
        opacity: root.shown ? 0.4 : 0
        Behavior on opacity { NumberAnimation { duration: 120 } }
        MouseArea { anchors.fill: parent; onClicked: root.close() }
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(parent.width * 0.86, 820)
        height: Math.min(parent.height * 0.8, 760)
        radius: 8
        color: root.cardColor
        border.color: root.light ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(1, 1, 1, 0.06)
        scale: root.shown ? 1 : 0.94
        opacity: root.shown ? 1 : 0
        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
        Behavior on opacity { NumberAnimation { duration: 110 } }
        MouseArea { anchors.fill: parent }

        Column {
            id: head
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.margins: 24
            spacing: 12
            Row {
                spacing: 10
                Text { text: "프로세스 종료"; color: root.textColor; font.pixelSize: 22; font.bold: true }
                Text {
                    anchors.baseline: parent.children[0].baseline
                    text: "누르면 바로 종료돼요 · Esc 닫기"
                    color: root.subColor
                    font.pixelSize: 14
                }
            }
            TextField {
                id: search
                width: parent.width
                placeholderText: "이름으로 찾기"
                color: root.textColor
                placeholderTextColor: root.subColor
                font.pixelSize: 15
                background: Rectangle { radius: 4; color: root.rowColor }
                Keys.onEscapePressed: root.close()
                Keys.onReturnPressed: if (root.shownList.length === 1) root.killApp(root.shownList[0])
            }
            // 열 제목
            Item {
                width: parent.width
                height: 18
                Text { x: 52; text: "프로그램"; color: root.subColor; font.pixelSize: 12 }
                Text { anchors.right: parent.right; anchors.rightMargin: 230; text: "램"; color: root.subColor; font.pixelSize: 12 }
                Text { anchors.right: parent.right; anchors.rightMargin: 140; text: "CPU"; color: root.subColor; font.pixelSize: 12 }
                Text { anchors.right: parent.right; anchors.rightMargin: 60; text: "GPU"; color: root.subColor; font.pixelSize: 12 }
            }
        }

        ListView {
            id: list
            anchors.top: head.bottom
            anchors.topMargin: 6
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.margins: 16
            clip: true
            spacing: 6
            model: root.shownList
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar {}
            delegate: Rectangle {
                id: row
                required property var modelData
                width: list.width
                height: 56
                radius: 6
                color: mouse.containsMouse ? Qt.rgba(0.85, 0.23, 0.23, root.light ? 0.12 : 0.22) : root.rowColor
                Behavior on color { ColorAnimation { duration: 80 } }

                Kirigami.Icon {
                    id: ic
                    x: 12
                    anchors.verticalCenter: parent.verticalCenter
                    width: 32; height: 32
                    source: row.modelData.icon
                    fallback: "application-x-executable"
                }
                Column {
                    anchors.left: ic.right
                    anchors.leftMargin: 12
                    anchors.right: ramT.left
                    anchors.rightMargin: 12
                    anchors.verticalCenter: parent.verticalCenter
                    Text {
                        width: parent.width
                        text: row.modelData.name
                        color: root.textColor
                        font.pixelSize: 15
                        font.bold: true
                        elide: Text.ElideRight
                    }
                    Text {
                        width: parent.width
                        text: row.modelData.key + (row.modelData.count > 1 ? " · 프로세스 " + row.modelData.count + "개" : "")
                        color: root.subColor
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                }
                Text {
                    id: ramT
                    anchors.right: parent.right; anchors.rightMargin: 214
                    anchors.verticalCenter: parent.verticalCenter
                    text: row.modelData.ramText
                    color: root.textColor
                    font.pixelSize: 14
                }
                Meter { anchors.right: parent.right; anchors.rightMargin: 124; value: row.modelData.cpu; textColor: root.textColor }
                Meter { anchors.right: parent.right; anchors.rightMargin: 44; value: row.modelData.gpu; textColor: root.textColor }
                Text {
                    anchors.right: parent.right; anchors.rightMargin: 12
                    anchors.verticalCenter: parent.verticalCenter
                    text: "종료"
                    color: root.danger
                    font.pixelSize: 13
                    font.bold: true
                    opacity: mouse.containsMouse ? 1 : 0
                }
                MouseArea {
                    id: mouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.killApp(row.modelData)
                }
            }
            Text {
                anchors.centerIn: parent
                visible: list.count === 0
                text: search.text ? "그 이름의 프로그램이 없어요" : "켜져 있는 프로그램이 없어요"
                color: root.subColor
                font.pixelSize: 15
            }
        }
    }

    component Meter: Item {
        property real value: 0
        property color textColor: "white"
        width: 70
        height: 30
        anchors.verticalCenter: parent ? parent.verticalCenter : undefined
        Text {
            anchors.right: parent.right
            anchors.top: parent.top
            text: value.toFixed(value < 10 ? 1 : 0) + "%"
            color: textColor
            font.pixelSize: 13
        }
        Rectangle {
            anchors.bottom: parent.bottom
            width: parent.width
            height: 4
            radius: 2
            color: Qt.rgba(0.5, 0.5, 0.5, 0.25)
            Rectangle {
                width: parent.width * Math.min(1, value / 100)
                height: parent.height
                radius: 2
                color: value > 60 ? "#E24B4A" : value > 25 ? "#e3a21a" : "#185FA5"
                Behavior on width { NumberAnimation { duration: 300 } }
            }
        }
    }
}
