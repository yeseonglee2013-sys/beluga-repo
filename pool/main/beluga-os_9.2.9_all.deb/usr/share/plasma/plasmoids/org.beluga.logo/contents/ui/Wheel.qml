// Beluga 휠 (Tab+1~9 / 절전 휠 Esc+Tab)
//  - 칸 8개가 원을 따라 배치, 마우스를 그 방향으로 움직이면 선택
//  - 클릭 = 실행, Esc / 바깥 클릭 = 닫기, ← → = 칸 이동, Enter = 실행, 1~9 = 다른 탭
//  - 빈 칸을 누르면 Beluga 설정(휠 탭)을 열어서 바로 채울 수 있음
import QtQuick
import QtQuick.Controls
import org.kde.kirigami as Kirigami

Item {
    id: root
    signal closed()
    property var shell: null

    property int tab: 0                       // 0~8, -1 = 절전
    readonly property var tabData: !shell ? { name: "", slots: [] } : (tab < 0 ? shell.sleepTab : (shell.tabs[tab] || { name: "", slots: [] }))
    readonly property var slots: tabData.slots || []
    property int selected: -1
    property bool mouseMoved: false
    property bool shown: false

    // ---- 색 ----
    SystemPalette { id: pal }
    readonly property bool light: Math.max(pal.window.r, pal.window.g, pal.window.b) > 0.5
    readonly property color ringColor: light ? Qt.rgba(0.97, 0.98, 0.99, 0.92) : Qt.rgba(0.09, 0.10, 0.12, 0.88)
    readonly property color slotColor: light ? Qt.rgba(0, 0, 0, 0.05) : Qt.rgba(1, 1, 1, 0.07)
    readonly property color textColor: light ? "#1b1d21" : "#f2f4f7"
    readonly property color accent: "#21398a"
    readonly property color accentLight: "#3d63d6"

    // ---- 크기 ----
    readonly property real ringR: Math.min(width, height) * 0.19      // 칸 중심까지 거리
    readonly property real slotD: ringR * 0.52
    readonly property real centerD: ringR * 0.95

    function open(t) {
        tab = t
        selected = -1
        mouseMoved = false
        shown = true
        focusItem.forceActiveFocus()
    }
    function close() {
        shown = false
        closeTimer.restart()
    }
    function activate(i) {
        if (i < 0) return
        if (!slots[i]) {                       // 빈 칸 → 설정 열기
            if (tab >= 0) shell.openSettings()
            close()
            return
        }
        var t = tab
        close()
        shell.runSlot(t, i)
    }
    function slotAngle(i) { return (-90 + i * 45) * Math.PI / 180 }

    Timer { id: closeTimer; interval: 130; onTriggered: root.closed() }

    // 어두워지는 배경
    Rectangle {
        anchors.fill: parent
        color: "black"
        opacity: root.shown ? 0.32 : 0
        Behavior on opacity { NumberAnimation { duration: 120 } }
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onPositionChanged: (m) => {
            var dx = m.x - ring.x - ring.width / 2, dy = m.y - ring.y - ring.height / 2
            var d = Math.sqrt(dx * dx + dy * dy)
            if (d < root.centerD * 0.45) { root.selected = -1; return }
            root.mouseMoved = true
            var a = Math.atan2(dy, dx) * 180 / Math.PI + 90      // 위 = 0도, 시계 방향
            if (a < 0) a += 360
            root.selected = Math.round(a / 45) % 8
        }
        onClicked: (m) => {
            var dx = m.x - ring.x - ring.width / 2, dy = m.y - ring.y - ring.height / 2
            var outside = Math.sqrt(dx * dx + dy * dy) > root.ringR + root.slotD
            if (m.button === Qt.RightButton || outside || root.selected < 0) root.close()
            else root.activate(root.selected)
        }
    }

    Item {
        id: focusItem
        focus: true
        Keys.onEscapePressed: root.close()
        Keys.onLeftPressed: root.selected = (root.selected < 0 ? 0 : (root.selected + 7) % 8)
        Keys.onRightPressed: root.selected = (root.selected < 0 ? 0 : (root.selected + 1) % 8)
        Keys.onUpPressed: root.selected = 0
        Keys.onDownPressed: root.selected = 4
        Keys.onReturnPressed: root.activate(root.selected)
        Keys.onEnterPressed: root.activate(root.selected)
        Keys.onPressed: (e) => {
            if (root.tab >= 0 && e.key >= Qt.Key_1 && e.key <= Qt.Key_9) { root.open(e.key - Qt.Key_1); e.accepted = true }
        }
    }

    // ---- 휠 ----
    Item {
        id: ring
        width: (root.ringR + root.slotD * 0.75) * 2
        height: width
        anchors.centerIn: parent
        scale: root.shown ? 1 : 0.86
        opacity: root.shown ? 1 : 0
        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack; easing.overshoot: 1.2 } }
        Behavior on opacity { NumberAnimation { duration: 110 } }

        // 바탕 원 (가운데가 비어 있는 도넛 느낌: 바깥 원 + 안쪽 원)
        Rectangle {
            anchors.centerIn: parent
            width: parent.width
            height: width
            radius: width / 2
            color: root.ringColor
            border.color: root.light ? Qt.rgba(0, 0, 0, 0.08) : Qt.rgba(1, 1, 1, 0.08)
            border.width: 1
        }

        // 선택한 방향 표시: 바깥쪽 가장자리에 빛나는 점
        Rectangle {
            visible: root.selected >= 0
            width: root.slotD * 0.22
            height: width
            radius: width / 2
            color: root.accentLight
            x: ring.width / 2 + Math.cos(root.slotAngle(Math.max(0, root.selected))) * (ring.width / 2 - width * 0.9) - width / 2
            y: ring.height / 2 + Math.sin(root.slotAngle(Math.max(0, root.selected))) * (ring.height / 2 - width * 0.9) - height / 2
            Behavior on x { NumberAnimation { duration: 90 } }
            Behavior on y { NumberAnimation { duration: 90 } }
        }

        Repeater {
            model: 8
            delegate: Item {
                id: slot
                required property int index
                readonly property var info: root.slots[index] || null
                readonly property bool sel: root.selected === index
                width: root.slotD
                height: root.slotD
                x: ring.width / 2 + Math.cos(root.slotAngle(index)) * root.ringR - width / 2
                y: ring.height / 2 + Math.sin(root.slotAngle(index)) * root.ringR - height / 2
                scale: sel ? 1.14 : 1
                Behavior on scale { NumberAnimation { duration: 90; easing.type: Easing.OutCubic } }

                Rectangle {
                    anchors.fill: parent
                    radius: width / 2
                    color: slot.sel ? (slot.info ? root.accent : Qt.rgba(0.5, 0.5, 0.5, 0.3)) : root.slotColor
                    Behavior on color { ColorAnimation { duration: 90 } }
                }
                Kirigami.Icon {
                    visible: !!slot.info
                    anchors.centerIn: parent
                    width: parent.width * 0.5
                    height: width
                    source: slot.info ? (slot.info.icon || "application-x-executable") : ""
                    fallback: "application-x-executable"
                }
                Text {
                    visible: !slot.info
                    anchors.centerIn: parent
                    text: "+"
                    color: root.textColor
                    opacity: 0.35
                    font.pixelSize: parent.width * 0.4
                }
            }
        }

        // 가운데: 탭 이름 + 고른 칸 이름 (절전 휠은 지금 상태)
        Rectangle {
            anchors.centerIn: parent
            width: root.centerD
            height: width
            radius: width / 2
            color: root.light ? Qt.rgba(1, 1, 1, 0.9) : Qt.rgba(0.14, 0.15, 0.18, 0.95)
            border.color: root.light ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(1, 1, 1, 0.06)
            Column {
                anchors.centerIn: parent
                width: parent.width * 0.82
                spacing: 4
                Text {
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    text: root.tabData.name || ""
                    color: root.textColor
                    opacity: 0.6
                    font.pixelSize: root.centerD * 0.11
                    elide: Text.ElideRight
                }
                Text {
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    maximumLineCount: 2
                    elide: Text.ElideRight
                    text: root.selected >= 0 ? (root.slots[root.selected] ? root.slots[root.selected].label : "비어 있음 · 눌러서 채우기")
                                             : (root.tab < 0 ? shell.sleepState : "방향을 고르세요")
                    color: root.textColor
                    font.pixelSize: root.centerD * 0.13
                    font.bold: root.selected >= 0
                }
            }
        }
    }

    // 아래: 탭 9개 점 (절전 휠에선 숨김)
    Row {
        visible: root.tab >= 0
        anchors.top: ring.bottom
        anchors.topMargin: 18
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 8
        opacity: root.shown ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 120 } }
        Repeater {
            model: 9
            delegate: Rectangle {
                required property int index
                width: index === root.tab ? 22 : 8
                height: 8
                radius: 4
                color: "white"
                opacity: index === root.tab ? 0.95 : 0.45
                Behavior on width { NumberAnimation { duration: 120 } }
                MouseArea { anchors.fill: parent; anchors.margins: -6; onClicked: root.open(parent.index) }
            }
        }
    }
    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 40
        text: root.tab < 0 ? "Esc 닫기" : "Tab+1~9 다른 휠 · 방향 고르고 클릭 · Esc 닫기"
        color: "white"
        opacity: root.shown ? 0.7 : 0
        font.pixelSize: 14
    }
}
