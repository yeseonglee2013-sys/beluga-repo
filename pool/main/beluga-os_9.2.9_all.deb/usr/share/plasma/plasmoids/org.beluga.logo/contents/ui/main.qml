/*
    Beluga OS 위쪽 바 왼쪽 로고 (2026-11-05)
    - 누르면 화면 가운데 Beluga 검색 카드. 윈도우 키와 같은 동작
    - 휠·절전 휠·프로세스 종료·검색 화면이 이 부품 안(BelugaShell.qml)에 있음 = 위쪽 바가 있으면 무조건 켜져 있음 (2026-11-06)
    - 그림은 파일에서 바로 읽음 (아이콘 테마 이름으로 찾으면 VM에서 안 그려지던 문제 피함)
    SPDX-License-Identifier: GPL-2.0-or-later
*/
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.plasma5support as P5Support

PlasmoidItem {
    id: root
    preferredRepresentation: fullRepresentation
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground

    P5Support.DataSource {
        id: run
        engine: "executable"
        connectedSources: []
        onNewData: (source) => disconnectSource(source)
    }

    BelugaShell { id: belugaShell }

    fullRepresentation: Item {
        Layout.minimumWidth: height + 8
        Layout.preferredWidth: height + 8
        Layout.fillHeight: true

        Rectangle {
            anchors.centerIn: parent
            width: parent.height - 4
            height: width
            radius: width / 2
            color: mouse.containsMouse ? Qt.rgba(0.5, 0.5, 0.5, 0.22) : "transparent"
            Behavior on color { ColorAnimation { duration: 100 } }
        }
        Image {
            anchors.centerIn: parent
            width: parent.height * 0.72
            height: width
            source: "file:///usr/share/pixmaps/beluga-start.png"
            sourceSize.width: 128
            sourceSize.height: 128
            fillMode: Image.PreserveAspectFit
            smooth: true
            scale: mouse.pressed ? 0.88 : 1
            Behavior on scale { NumberAnimation { duration: 80 } }
        }
        // 업데이트 점 (있음 = 파랑 / 다시 시작하면 설치 = 초록 / 실패·되돌림 = 빨강) — 누르면 업데이트 카드
        Rectangle {
            visible: belugaShell.updateBadge !== ""
            width: 8; height: 8; radius: 4
            color: belugaShell.updateBadge || "transparent"
            border.color: "#FFFFFF"; border.width: 1
            anchors.right: parent.right; anchors.top: parent.top
            anchors.rightMargin: 3; anchors.topMargin: 3
        }
        MouseArea {
            id: mouse
            anchors.fill: parent
            hoverEnabled: true
            // 업데이트 점이 있으면 업데이트 카드, 아니면 Beluga 검색 카드 (윈도우 키와 같음)
            onClicked: belugaShell.updateBadge !== "" ? belugaShell.openUpdate() : belugaShell.openSearch()
        }
    }
}
