// Beluga 검색 카드 (윈도우 키) — KWin 안에서 직접 그림 (KDE 검색창 KRunner 안 빌림, 2026-11-05)
//  - 화면 가운데 카드: 위에 입력칸, 아래 결과 (앱 · Beluga 동작(전원 끄기 등) · 계산)
//  - 한글 초성으로도 찾음 (ㅂㄹㄱ → 벨루가), 영어 이름/찾는 말로도 찾음. 웹 검색 없음
//  - ↑↓ 고르기 · Enter 실행 · Esc / 바깥 클릭 닫기
//  디자인 규칙 A: 모서리 4/6/8, 강조색 #185FA5
import QtQuick
import QtQuick.Controls
import org.kde.kirigami as Kirigami

Item {
    id: root
    signal closed()
    signal runAction(var action)          // 동작 칸 (전원 끄기 등)
    signal launchApp(string path)         // 앱
    property var apps: []                 // [{name, sub, icon, path, keys}]
    property bool shown: false
    property int current: 0

    SystemPalette { id: pal }
    readonly property bool light: Math.max(pal.window.r, pal.window.g, pal.window.b) > 0.5
    readonly property color cardColor: light ? "#FFFFFF" : "#1F2227"
    readonly property color fieldColor: light ? "#F5F6F8" : "#272A30"
    readonly property color lineColor: light ? "#D9DCE1" : "#33373E"
    readonly property color textColor: light ? "#1D2129" : "#E8EAED"
    readonly property color subColor: light ? "#5B6270" : "#9AA0AA"
    readonly property color accent: "#185FA5"

    // Beluga 동작 (앱처럼 찾아짐)
    readonly property var actions: [
        { name: "전원 끄기", sub: "Beluga 끄기", icon: "system-shutdown", keys: "shutdown power off 종료 끄기", action: { type: "system", value: "shutdown" } },
        { name: "다시 시작", sub: "재부팅", icon: "system-reboot", keys: "reboot restart 재부팅 재시작", action: { type: "system", value: "reboot" } },
        { name: "로그아웃", sub: "다른 사용자로", icon: "system-log-out", keys: "logout 로그아웃", action: { type: "system", value: "logout" } },
        { name: "화면 잠금", sub: "", icon: "system-lock-screen", keys: "lock 잠금", action: { type: "system", value: "lock" } },
        { name: "절전", sub: "지금 절전", icon: "system-suspend", keys: "sleep suspend 절전 잠자기", action: { type: "system", value: "suspend" } },
        { name: "업데이트", sub: "커널까지 전부 · 다시 시작할 때 설치", icon: "system-software-update", keys: "update upgrade 업데이트 업그레이드 커널 kernel", action: { type: "system", value: "update" } },
        { name: "Beluga 설정", sub: "", icon: "preferences-system", keys: "settings 설정 환경설정", action: { type: "system", value: "settings" } },
        { name: "터미널", sub: "", icon: "utilities-terminal", keys: "terminal cmd shell 터미널 명령", action: { type: "system", value: "terminal" } },
        { name: "파일", sub: "파일 관리자", icon: "system-file-manager", keys: "files explorer 파일 탐색기", action: { type: "system", value: "files" } },
        { name: "작업 관리자", sub: "Ctrl+Shift+Esc", icon: "utilities-system-monitor", keys: "task manager 작업관리자", action: { type: "system", value: "taskmgr" } },
        { name: "프로세스 종료", sub: "Tab+Backspace", icon: "process-stop", keys: "kill process 종료 강제종료", action: { type: "system", value: "killer" } },
        { name: "스크린샷", sub: "", icon: "camera-photo", keys: "screenshot capture 캡처 스크린샷", action: { type: "system", value: "screenshot" } },
        { name: "화면 녹화", sub: "", icon: "media-record", keys: "record 녹화", action: { type: "system", value: "record" } }
    ]

    // ---- 한글 초성 ----
    readonly property string cho: "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
    function chosung(s) {
        var out = ""
        for (var i = 0; i < s.length; i++) {
            var c = s.charCodeAt(i)
            out += (c >= 0xAC00 && c <= 0xD7A3) ? cho.charAt(Math.floor((c - 0xAC00) / 588)) : s.charAt(i)
        }
        return out
    }
    function isCho(q) { for (var i = 0; i < q.length; i++) if (cho.indexOf(q.charAt(i)) < 0 && q.charAt(i) !== " ") return false; return q.length > 0 }

    // 점수: 이름 시작 > 이름 안 > 초성 > 찾는 말
    function score(it, q, qc) {
        var n = it.name.toLowerCase()
        if (n.indexOf(q) === 0) return 100
        if (n.indexOf(q) > 0) return 80
        if (qc && chosung(it.name).indexOf(q) >= 0) return 70
        if ((it.sub || "").toLowerCase().indexOf(q) >= 0) return 50
        if ((it.keys || "").toLowerCase().indexOf(q) >= 0) return 40
        return 0
    }
    function calc(q) {
        if (!/^[0-9+\-*/().%^ ]+$/.test(q) || !/[0-9]/.test(q) || !/[+\-*/%^]/.test(q)) return null
        try {
            var v = Function("return (" + q.replace(/\^/g, "**") + ")")()
            if (typeof v !== "number" || !isFinite(v)) return null
            return Math.round(v * 1e10) / 1e10
        } catch (e) { return null }
    }
    readonly property var results: {
        var q = field.text.trim().toLowerCase()
        if (!q) return []
        var out = [], qc = isCho(q)
        var c = calc(q)
        if (c !== null) out.push({ name: "= " + c, sub: "계산", icon: "accessories-calculator", calc: String(c), s: 1000 })
        var all = actions.concat(apps)
        for (var i = 0; i < all.length; i++) {
            var s = score(all[i], q, qc)
            if (s > 0) { var it = all[i]; out.push({ name: it.name, sub: it.sub, icon: it.icon, path: it.path, action: it.action, s: s + (it.action ? 5 : 0) }) }
        }
        out.sort(function (a, b) { return b.s - a.s || a.name.localeCompare(b.name) })
        return out.slice(0, 8)
    }
    onResultsChanged: current = 0

    function open() {
        field.text = ""
        current = 0
        shown = true
        field.forceActiveFocus()
    }
    function close() { shown = false; closeTimer.restart() }
    function activate(i) {
        var r = results[i]
        if (!r) return
        close()
        if (r.calc) return
        if (r.action) root.runAction(r.action)
        else if (r.path) root.launchApp(r.path)
    }
    Timer { id: closeTimer; interval: 110; onTriggered: root.closed() }

    Rectangle {
        anchors.fill: parent
        color: "black"
        opacity: root.shown ? 0.25 : 0
        Behavior on opacity { NumberAnimation { duration: 100 } }
        MouseArea { anchors.fill: parent; onClicked: root.close() }
    }

    Rectangle {
        id: card
        width: Math.min(parent.width - 64, 640)
        height: col.implicitHeight + 16
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.22
        radius: 8
        color: root.cardColor
        border.color: root.lineColor
        border.width: 1
        opacity: root.shown ? 1 : 0
        scale: root.shown ? 1 : 0.97
        Behavior on opacity { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
        Behavior on scale { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
        MouseArea { anchors.fill: parent }

        Column {
            id: col
            x: 8
            y: 8
            width: parent.width - 16
            spacing: 4

            Rectangle {
                width: parent.width
                height: 48
                radius: 6
                color: root.fieldColor
                Kirigami.Icon {
                    id: mag
                    source: "search"
                    width: 20
                    height: 20
                    x: 14
                    anchors.verticalCenter: parent.verticalCenter
                    color: root.subColor
                }
                TextField {
                    id: field
                    anchors.left: mag.right
                    anchors.leftMargin: 8
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    placeholderText: "앱, 설정, 전원 끄기, 계산…"
                    placeholderTextColor: root.subColor
                    color: root.textColor
                    font.pixelSize: 17
                    background: Item {}
                    Keys.onEscapePressed: root.close()
                    Keys.onDownPressed: root.current = Math.min(root.current + 1, Math.max(0, root.results.length - 1))
                    Keys.onUpPressed: root.current = Math.max(root.current - 1, 0)
                    Keys.onReturnPressed: root.activate(root.current)
                    Keys.onEnterPressed: root.activate(root.current)
                }
            }

            Repeater {
                model: root.results
                delegate: Rectangle {
                    id: row
                    required property var modelData
                    required property int index
                    readonly property bool sel: index === root.current
                    width: col.width
                    height: 44
                    radius: 4
                    color: sel ? root.accent : (m.containsMouse ? (root.light ? Qt.rgba(0, 0, 0, 0.04) : Qt.rgba(1, 1, 1, 0.05)) : "transparent")
                    Kirigami.Icon {
                        id: ic
                        x: 12
                        anchors.verticalCenter: parent.verticalCenter
                        width: 28
                        height: 28
                        source: row.modelData.icon || "application-x-executable"
                        fallback: "application-x-executable"
                    }
                    Text {
                        id: nm
                        anchors.left: ic.right
                        anchors.leftMargin: 12
                        anchors.verticalCenter: parent.verticalCenter
                        text: row.modelData.name
                        color: row.sel ? "#FFFFFF" : root.textColor
                        font.pixelSize: 14
                        font.weight: Font.DemiBold
                    }
                    Text {
                        anchors.left: nm.right
                        anchors.leftMargin: 8
                        anchors.right: parent.right
                        anchors.rightMargin: 12
                        anchors.verticalCenter: parent.verticalCenter
                        text: row.modelData.sub || ""
                        color: row.sel ? Qt.rgba(1, 1, 1, 0.8) : root.subColor
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                    MouseArea {
                        id: m
                        anchors.fill: parent
                        hoverEnabled: true
                        onEntered: root.current = row.index
                        onClicked: root.activate(row.index)
                    }
                }
            }
            Text {
                visible: field.text.trim() !== "" && root.results.length === 0
                width: parent.width
                height: 40
                verticalAlignment: Text.AlignVCenter
                horizontalAlignment: Text.AlignHCenter
                text: "찾는 게 없어요"
                color: root.subColor
                font.pixelSize: 13
            }
        }
    }
}
