// Beluga 휠 · 절전 휠 · 프로세스 종료 창 · 검색 카드 — 위쪽 바를 그리는 plasmashell 안에서 돎 (2026-11-06, 원칙 1: OS에 박기)
//  - 단축키는 KWin이 받고(/usr/share/kwin/scripts/beluga) beluga-ctl → FIFO 통로로 여기 전달
//    FIFO = $XDG_RUNTIME_DIR/beluga-shell.fifo, 한 줄씩: "wheel N" | "sleep" | "kill" | "search"
//  - KWin이 직접 그린 창은 키보드 초점을 못 받아서 화면은 여기(plasmashell = 보통 창, 키보드 정상)
//  - 실행은 /usr/lib/beluga/os/beluga-do (불리면 할 일만 하고 끝나는 OS 명령)
import QtQuick
import QtQuick.Window
import org.kde.plasma.plasma5support as P5Support

Item {
    id: root
    readonly property string helper: "/usr/lib/beluga/os/beluga-do"
    readonly property string cfgUser: "\"${XDG_CONFIG_HOME:-$HOME/.config}/beluga/wheel.json\""

    // ---- 명령 실행 (끝나면 결과 받기) ----
    P5Support.DataSource {
        id: exe
        engine: "executable"
        property var cbs: ({})
        onNewData: (src, data) => {
            var cb = cbs[src]
            delete cbs[src]
            disconnectSource(src)
            if (cb) cb(data["stdout"] || "", data["exit code"])
        }
        function run(cmd, cb) {
            if (cb) cbs[cmd] = cb
            connectSource(cmd)
        }
    }

    // ---- 단축키 받는 통로: 한 줄 오면 처리하고 다시 기다림 ----
    property int listenSeq: 0
    function listen() {
        listenSeq++
        exe.run("f=\"${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/beluga-shell.fifo\"; [ -p \"$f\" ] || { rm -f \"$f\"; mkfifo -m 600 \"$f\"; }; read -r l < \"$f\"; echo \"$l\" #listen" + listenSeq,
                function (out) { root.handle(out.trim()); listenTimer.restart() })
    }
    Timer { id: listenTimer; interval: 30; onTriggered: root.listen() }
    function handle(cmd) {
        var p = cmd.split(" ")
        if (p[0] === "wheel") openWheel(Math.max(1, Math.min(9, parseInt(p[1]) || 1)) - 1)
        else if (p[0] === "sleep") openWheel(-1)
        else if (p[0] === "kill") openKiller()
        else if (p[0] === "search") openSearch()
        else if (p[0] === "update") openUpdate()
    }

    QtObject {
        id: shell
        property var tabs: []
        property var procs: []
        property var apps: []
        function reloadApps() {
            exe.run(root.helper + " apps", function (out) {
                var l = out.split("\n"), a = []
                for (var i = 0; i < l.length; i++) {
                    var f = l[i].split("\t")
                    if (f.length >= 5) a.push({ name: f[0], sub: f[1], icon: f[2], path: f[3], keys: f[4] })
                }
                if (a.length) shell.apps = a
            })
        }
        property string sleepState: ""
        property int ncpu: 1
        property var prev: ({})            // pid → [시각ms, CPU틱, GPUns] (사용률 계산용)
        readonly property var sleepTab: ({ name: "절전", slots: [
            { label: "계속 안 꺼지기", icon: "system-suspend-inhibited", action: { type: "sleep", value: "never" } },
            { label: "5분 뒤 절전", icon: "chronometer", action: { type: "sleep", value: "5" } },
            { label: "10분 뒤 절전", icon: "chronometer", action: { type: "sleep", value: "10" } },
            { label: "30분 뒤 절전", icon: "chronometer", action: { type: "sleep", value: "30" } },
            { label: "1시간 뒤 절전", icon: "chronometer", action: { type: "sleep", value: "60" } },
            { label: "지금 절전", icon: "system-suspend", action: { type: "sleep", value: "now" } },
            { label: "원래대로", icon: "edit-undo", action: { type: "sleep", value: "reset" } },
            null ] })
        // 죽으면 화면/로그인/소리/입력이 망가지는 시스템 부품 + 이 창이 부르는 명령은 목록에서 숨김
        readonly property var hidden: ["systemd", "(sd-pam)", "dbus-daemon", "dbus-broker", "dbus-broker-lau", "pipewire",
            "pipewire-pulse", "wireplumber", "pulseaudio", "kwin_wayland", "kwin_wayland_wr", "kwin_x11", "Xwayland",
            "plasmashell", "ksmserver", "kded6", "kglobalacceld", "kaccess", "polkit-kde-auth", "startplasma-way",
            "startplasma-x11", "plasma_session", "kactivitymanage", "kwalletd6", "ksecretd", "xdg-desktop-por",
            "xdg-document-po", "xdg-permission-", "at-spi-bus-laun", "at-spi2-registr", "dconf-service", "baloo_file",
            "baloo_file_extr", "baloorunner", "krunner", "fcitx5", "xembedsniproxy", "gmenudbusmenupr",
            "kscreen_backend", "org_kde_powerde", "DiscoverNotifie", "obexd", "mpris-proxy", "gvfsd", "gvfsd-fuse",
            "gvfsd-metadata", "gvfs-udisks2-vo", "ssh-agent", "gpg-agent", "sddm-helper", "kde-inhibit",
            "systemd-inhibit", "fcitx5-plasma-t", "kalendarac", "agent", "xdg-desktop-portal-kde", "bash", "sh", "zsh", "fish", "dash", "sleep", "beluga-do", "awk", "readlink", "cat",
            "xwaylandvideobr", "kscreen-doctor", "drkonqi-coredum", "xsettingsd", "avahi-publish-s", "beluga-display-",
            "gcr-ssh-agent", "find", "xargs", "sed", "keyd", "keyd-applicati", "kdeconnectd", "kioworker", "kiod6",
            "ksplashqml", "plasma-browser-", "kded5", "gsd-xsettings", "evolution-sourc", "evolution-addre",
            "evolution-calen", "goa-daemon", "goa-identity-se", "tracker-miner-f", "localsearch-3", "upowerd", "colord"]

        function normTab(t, i) {
            t = t || {}
            var s = (t.slots || []).slice(0, 8)
            while (s.length < 8) s.push(null)
            for (var k = 0; k < 8; k++) {
                var x = s[k]
                if (x && !x.icon) x.icon = (x.action && x.action.type === "app") ? String(x.action.value).replace(/\.desktop$/, "") : "application-x-executable"
            }
            return { name: t.name || ("탭 " + (i + 1)), slots: s }
        }
        function reload() {
            exe.run("cat " + root.cfgUser + " 2>/dev/null || cat /usr/share/beluga/wheel-default.json", function (out) {
                var d = {}
                try { d = JSON.parse(out) } catch (e) {}
                var src = d.tabs || [], t = []
                for (var i = 0; i < 9; i++) t.push(normTab(src[i], i))
                shell.tabs = t
            })
        }
        function b64(v) { return Qt.btoa(unescape(encodeURIComponent(String(v)))) }
        function runSlot(t, i) {
            var tab = t < 0 ? sleepTab : tabs[t]
            var s = tab && tab.slots ? tab.slots[i] : null
            if (!s || !s.action) return
            var a = s.action
            if (a.type === "system" && a.value === "killer") { root.openKiller(); return }
            exe.run(root.helper + " run " + a.type + " " + b64(a.value) + " #" + Date.now())
        }
        function openSettings() { exe.run("setsid -f systemsettings beluga-wheel #" + Date.now()) }
        function killPids(pids) {
            var p = []
            for (var i = 0; i < pids.length; i++) p.push(parseInt(pids[i]))
            exe.run(root.helper + " kill " + p.join(" "), function () { shell.refreshProcs() })
        }
        function size(kb) { return kb >= 1048576 ? (kb / 1048576).toFixed(1) + " GB" : Math.round(kb / 1024) + " MB" }
        function refreshProcs() {
            exe.run(root.helper + " procs", function (out) {
                var now = Date.now(), groups = {}, np = {}, lines = out.split("\n")
                for (var i = 0; i < lines.length; i++) {
                    var f = lines[i].split("\t")
                    if (f.length < 5 || shell.hidden.indexOf(f[1]) >= 0) continue
                    var pid = parseInt(f[0]), tk = parseInt(f[2]), kb = parseInt(f[3]), gn = parseFloat(f[4])
                    var pv = shell.prev[pid], cpu = 0, gpu = 0
                    if (pv && now > pv[0]) {
                        var dt = (now - pv[0]) / 1000
                        cpu = Math.max(0, (tk - pv[1]) / 100 / dt / shell.ncpu * 100)
                        gpu = Math.max(0, (gn - pv[2]) / (dt * 1e9) * 100)
                    }
                    np[pid] = [now, tk, gn]
                    var g = groups[f[1]]
                    if (!g) g = groups[f[1]] = { key: f[1], name: f[1], icon: f[1].toLowerCase(), pids: [], kb: 0, cpu: 0, gpu: 0 }
                    g.pids.push(pid); g.kb += kb; g.cpu += cpu; g.gpu += gpu
                }
                shell.prev = np
                var list = []
                for (var k in groups) {
                    var x = groups[k]
                    x.count = x.pids.length; x.ram = x.kb; x.ramText = shell.size(x.kb)
                    x.cpu = Math.round(Math.min(x.cpu, 100) * 10) / 10; x.gpu = Math.round(Math.min(x.gpu, 100) * 10) / 10
                    list.push(x)
                }
                list.sort(function (a, b) { return b.kb - a.kb })
                shell.procs = list
            })
        }
        // 업데이트 상태 (/var/lib/beluga-update/status): 카드가 열려 있으면 1초, 아니면 5분마다
        property var update: ({})
        function refreshUpdate() {
            exe.run(root.helper + " update-status #" + Date.now(), function (out) {
                var o = {}, l = out.split("\n")
                for (var i = 0; i < l.length; i++) { var k = l[i].indexOf("="); if (k > 0) o[l[i].substring(0, k)] = l[i].substring(k + 1) }
                shell.update = o
            })
        }
        function updateCommand(what) {
            exe.run(root.helper + " update " + what + " #" + Date.now(), function () { shell.refreshUpdate() })
        }
        function refreshSleep() {
            exe.run(root.helper + " sleep-state #" + Date.now(), function (out) { shell.sleepState = out.trim() })
        }
    }
    Component.onCompleted: {
        shell.reload()
        shell.reloadApps()
        exe.run("nproc", function (out) { shell.ncpu = parseInt(out) || 1 })
        listen()
    }

    Timer { interval: 1000; repeat: true; running: killerWin.visible; onTriggered: shell.refreshProcs() }
    Timer { interval: updateWin.visible ? 1000 : 300000; repeat: true; running: true; triggeredOnStart: true; onTriggered: shell.refreshUpdate() }
    // 위쪽 바 로고의 점: 업데이트가 있거나(파랑) 다시 시작하면 설치(초록) / 되돌림·실패(빨강)
    readonly property string updateBadge: {
        var s = shell.update.state || ""
        return s === "available" ? "#185FA5" : s === "ready" ? "#3B9B4F" : (s === "rolledback" || s === "failed") ? "#E24B4A" : ""
    }

    function show(w) {
        w.showFullScreen()
        w.raise()
        w.requestActivate()
    }
    function openWheel(tab) {
        if (killerWin.visible) killer.close()
        if (searchWin.visible) search.close()
        if (wheelWin.visible && wheel.tab === tab) { wheel.close(); return }   // 같은 단축키 한 번 더 = 닫기
        shell.reload()                                                         // 설정에서 바꾼 것 바로 반영
        if (tab < 0) shell.refreshSleep()
        wheel.open(tab)
        show(wheelWin)
    }
    function openSearch() {
        if (wheelWin.visible) wheel.close()
        if (killerWin.visible) killer.close()
        if (searchWin.visible) { search.close(); return }      // 윈도우 키 한 번 더 = 닫기
        shell.reloadApps()
        search.open()
        show(searchWin)
    }
    function openUpdate() {
        if (wheelWin.visible) wheel.close()
        if (searchWin.visible) search.close()
        if (killerWin.visible) killer.close()
        if (updateWin.visible) { upd.close(); return }
        shell.refreshUpdate()
        upd.open()
        show(updateWin)
    }
    function openKiller() {
        if (wheelWin.visible) wheel.close()
        if (searchWin.visible) search.close()
        if (killerWin.visible) { killer.close(); return }
        shell.refreshProcs()
        killer.open()
        show(killerWin)
    }

    // ---- 화면 (화면 전체를 덮는 투명 창) ----
    Window {
        id: wheelWin
        title: "Beluga 휠"
        flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        color: "transparent"
        visible: false
        Wheel {
            id: wheel
            anchors.fill: parent
            shell: shell
            onClosed: wheelWin.hide()
        }
        onActiveChanged: if (!active && visible) wheel.close()      // 다른 데를 누르면 닫힘
    }
    Window {
        id: killerWin
        title: "Beluga 프로세스 종료"
        flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        color: "transparent"
        visible: false
        Killer {
            id: killer
            anchors.fill: parent
            shell: shell
            onClosed: killerWin.hide()
        }
    }
    Window {
        id: searchWin
        title: "Beluga 검색"
        flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        color: "transparent"
        visible: false
        Search {
            id: search
            anchors.fill: parent
            apps: shell.apps
            onClosed: searchWin.hide()
            onRunAction: (a) => {
                if (a.type === "system" && a.value === "killer") { root.openKiller(); return }
                if (a.type === "system" && a.value === "update") { search.close(); root.openUpdate(); return }
                exe.run(root.helper + " run " + a.type + " " + shell.b64(a.value) + " #" + Date.now())
            }
            onLaunchApp: (p) => exe.run(root.helper + " launch '" + p.replace(/'/g, "'\''") + "' #" + Date.now())
        }
        onActiveChanged: if (!active && visible) search.close()
    }
    Window {
        id: updateWin
        title: "Beluga 업데이트"
        flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        color: "transparent"
        visible: false
        Update {
            id: upd
            anchors.fill: parent
            st: shell.update
            onClosed: updateWin.hide()
            onCommand: (what) => shell.updateCommand(what)
        }
    }
}
