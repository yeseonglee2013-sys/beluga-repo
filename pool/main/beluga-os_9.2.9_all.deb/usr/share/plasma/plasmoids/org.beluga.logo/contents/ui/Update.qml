// Beluga 업데이트 카드 (2026-11-06) — 윈도우 업데이트처럼
//  상태는 /var/lib/beluga-update/status (beluga-update 가 씀), 1초마다 읽음
//  확인 → "업데이트 N개 (MB)" [받기] → 받는 중 N% 막대 → "다시 시작하면 설치돼요" [지금 다시 시작] [나중에]
//  다시 시작하면 부팅 화면에서 "업데이트 설치 중 N% · 컴퓨터를 끄지 마세요" → 끝나면 저절로 다시 켜짐
//  디자인 규칙 A: 강조색 #185FA5, 모서리 4/8, 촘촘하게
import QtQuick
import QtQuick.Controls

Item {
    id: root
    signal closed()
    signal command(string what)          // check | download | cancel | reboot
    property var st: ({})                // 상태 key=value
    property bool shown: false

    SystemPalette { id: pal }
    readonly property bool light: Math.max(pal.window.r, pal.window.g, pal.window.b) > 0.5
    readonly property color cardColor: light ? "#FFFFFF" : "#1F2227"
    readonly property color rowColor: light ? "#F5F6F8" : "#272A30"
    readonly property color lineColor: light ? "#D9DCE1" : "#33373E"
    readonly property color textColor: light ? "#1D2129" : "#E8EAED"
    readonly property color subColor: light ? "#5B6270" : "#9AA0AA"
    readonly property color accent: "#185FA5"
    readonly property string state_: st.state || "idle"
    readonly property int pct: parseInt(st.pct) || 0
    readonly property bool busy: state_ === "checking" || state_ === "downloading" || state_ === "installing"

    function open() { shown = true; keys.forceActiveFocus() }
    function close() { shown = false; closeTimer.restart() }
    Timer { id: closeTimer; interval: 130; onTriggered: root.closed() }

    readonly property string title: ({
        "idle": "업데이트", "checking": "업데이트 확인 중", "uptodate": "최신 상태예요",
        "available": "업데이트가 있어요", "downloading": "업데이트 받는 중", "ready": "다시 시작하면 설치돼요",
        "installing": "업데이트 설치 중", "done": "업데이트를 설치했어요", "failed": "업데이트를 하지 못했어요",
        "rolledback": "이전 커널로 되돌렸어요" })[state_] || "업데이트"
    readonly property string detail: {
        if (state_ === "available" || state_ === "ready")
            return "업데이트 " + (st.count || "?") + "개 · " + (st.size || "?") + " MB" + (st.kernel ? " · 새 커널 " + st.kernel : "")
        if (state_ === "downloading") return pct + "% 받았어요"
        if (state_ === "uptodate" || state_ === "done") return st.time ? "마지막 확인 " + st.time : ""
        return st.msg || ""
    }

    Item { id: keys; focus: true; Keys.onEscapePressed: root.close() }

    Rectangle {
        anchors.fill: parent
        color: "black"
        opacity: root.shown ? 0.4 : 0
        Behavior on opacity { NumberAnimation { duration: 120 } }
        MouseArea { anchors.fill: parent; onClicked: root.close() }
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: 480
        height: col.implicitHeight + 48
        radius: 8
        color: root.cardColor
        border.color: root.lineColor
        scale: root.shown ? 1 : 0.94
        opacity: root.shown ? 1 : 0
        Behavior on scale { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
        Behavior on opacity { NumberAnimation { duration: 110 } }
        MouseArea { anchors.fill: parent }

        Column {
            id: col
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 24
            spacing: 12

            Text { text: "Beluga 업데이트"; color: root.subColor; font.pixelSize: 13 }
            Text { text: root.title; color: root.textColor; font.pixelSize: 20; font.weight: Font.DemiBold }
            Text {
                width: parent.width
                text: root.detail
                visible: text !== ""
                wrapMode: Text.WordWrap
                color: root.state_ === "failed" || root.state_ === "rolledback" ? "#E24B4A" : root.subColor
                font.pixelSize: 13
            }
            // 진행 막대 (받는 중 / 확인 중)
            Rectangle {
                width: parent.width
                height: 6
                radius: 3
                color: root.rowColor
                visible: root.busy
                Rectangle {
                    height: parent.height
                    radius: 3
                    color: root.accent
                    width: root.state_ === "checking" ? parent.width * 0.3 : parent.width * root.pct / 100
                    x: root.state_ === "checking" ? (parent.width * 0.7) * (0.5 + 0.5 * Math.sin(spin.t)) : 0
                    Behavior on width { NumberAnimation { duration: 250; easing.type: Easing.OutCubic } }
                }
                // 확인 중일 때 왔다갔다
                QtObject { id: spin; property real t: 0 }
                Timer { interval: 30; repeat: true; running: root.shown && root.state_ === "checking"; onTriggered: spin.t += 0.08 }
            }
            Text {
                width: parent.width
                visible: root.state_ === "ready"
                wrapMode: Text.WordWrap
                text: "다시 시작하면 설치 화면이 나와요. 끝날 때까지 컴퓨터를 끄지 마세요. 끝나면 저절로 다시 켜져요."
                color: root.subColor
                font.pixelSize: 13
            }

            // 버튼
            Row {
                anchors.right: parent.right
                spacing: 8
                Btn { label: "닫기"; onClicked: root.close() }
                Btn { label: "확인"; visible: !root.busy && root.state_ !== "ready"; onClicked: root.command("check") }
                Btn { label: "예약 취소"; visible: root.state_ === "ready"; onClicked: root.command("cancel") }
                Btn { label: "받기"; primary: true; visible: root.state_ === "available"; onClicked: root.command("download") }
                Btn { label: "지금 다시 시작"; primary: true; visible: root.state_ === "ready"; onClicked: root.command("reboot") }
            }
        }
    }

    component Btn: Rectangle {
        id: b
        property string label: ""
        property bool primary: false
        signal clicked()
        width: Math.max(72, t.implicitWidth + 24)
        height: 32
        radius: 4
        color: primary ? (m.pressed ? Qt.darker(root.accent, 1.15) : (m.containsMouse ? Qt.lighter(root.accent, 1.12) : root.accent))
                       : (m.pressed ? Qt.darker(root.rowColor, 1.08) : (m.containsMouse ? Qt.lighter(root.rowColor, 1.04) : root.rowColor))
        border.color: primary ? "transparent" : root.lineColor
        Behavior on color { ColorAnimation { duration: 100 } }
        Text {
            id: t
            anchors.centerIn: parent
            text: b.label
            color: b.primary ? "#FFFFFF" : root.textColor
            font.pixelSize: 13
        }
        MouseArea { id: m; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: b.clicked() }
    }
}
