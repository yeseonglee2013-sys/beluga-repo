/*
    Beluga OS 바탕화면 큰 시계 (2026-11-05)
    - 큰 시각 + 날짜(요일), 글자에 은은한 그림자 → 어떤 배경화면 위에서도 잘 보임
    - 바탕화면 위젯이라 옮기기/크기 바꾸기/지우기 가능 (오른쪽 클릭)
    SPDX-License-Identifier: GPL-2.0-or-later
*/
import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore

PlasmoidItem {
    id: root
    preferredRepresentation: fullRepresentation
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground

    property date now: new Date()
    Timer {
        interval: 1000; running: true; repeat: true; triggeredOnStart: true
        onTriggered: root.now = new Date()
    }

    readonly property string timeText: {
        var h = now.getHours(), m = now.getMinutes(), s = now.getSeconds();
        var ampm = "";
        if (!Plasmoid.configuration.use24h) { ampm = h < 12 ? "오전 " : "오후 "; h = h % 12; if (h === 0) h = 12; }
        var t = h + ":" + (m < 10 ? "0" : "") + m;
        if (Plasmoid.configuration.showSeconds) t += ":" + (s < 10 ? "0" : "") + s;
        return t;
    }
    readonly property string ampmText: Plasmoid.configuration.use24h ? "" : (now.getHours() < 12 ? "오전" : "오후")
    readonly property string dateText: {
        var days = ["일", "월", "화", "수", "목", "금", "토"];
        return (now.getMonth() + 1) + "월 " + now.getDate() + "일 " + days[now.getDay()] + "요일";
    }

    fullRepresentation: Item {
        Layout.minimumWidth: 220
        Layout.minimumHeight: 120
        Layout.preferredWidth: 420
        Layout.preferredHeight: 200

        ColumnLayout {
            id: col
            anchors.centerIn: parent
            spacing: 0
            layer.enabled: true
            layer.effect: MultiEffect {
                shadowEnabled: true
                shadowColor: "#80000000"
                shadowBlur: 0.6
                shadowVerticalOffset: 2
            }
            RowLayout {
                Layout.alignment: Qt.AlignHCenter
                spacing: 10
                Text {
                    visible: root.ampmText !== ""
                    Layout.alignment: Qt.AlignBottom
                    Layout.bottomMargin: big.font.pixelSize * 0.16
                    text: root.ampmText
                    color: "white"
                    font.pixelSize: big.font.pixelSize * 0.28
                    font.weight: Font.Medium
                }
                Text {
                    id: big
                    text: root.timeText.replace(/^오[전후] /, "")
                    color: "white"
                    font.pixelSize: Math.max(32, Math.min(col.parent.height * 0.55, col.parent.width * 0.28))
                    font.weight: Font.Light
                }
            }
            Text {
                Layout.alignment: Qt.AlignHCenter
                text: root.dateText
                color: "white"
                opacity: 0.9
                font.pixelSize: big.font.pixelSize * 0.22
            }
        }
    }
}
