#!/usr/bin/python3
"""Beluga 덱 서버 (2026-11-05): 폰을 스트림덱처럼

  폰 앱(안드로이드) ⇄ 이 서버 (같은 와이파이, 포트 41234)
  - 폰이 자동으로 찾음 (mDNS: _beluga-deck._tcp)
  - 처음 한 번 4자리 연결 코드 (Beluga 설정 → 폰 덱 탭에 보임) → 그다음부턴 자동
  - 배열(예: 6×2)·페이지·버튼 그림/글자/색은 PC에서 정함 → 바뀌면 폰에 바로 반영
  - 버튼 누르면 PC에서 동작 (휠과 같은 동작: 앱/명령/열기/시스템)
  - http://<PC>:41234/            안내 페이지 (폰 앱 내려받기)
  - http://<PC>:41234/app.apk     폰 앱
  - http://<PC>:41234/icon/<이름>  버튼 그림 (Beluga 설정이 만들어 둔 PNG)

설정: ~/.config/beluga/deck.json, 연결 코드: ~/.config/beluga/deck-pin
"""
import asyncio
import json
import os
import random
import socket
import subprocess
import sys
from pathlib import Path

from aiohttp import WSMsgType, web

sys.path.insert(0, "/usr/lib/beluga/shell")
import actions  # noqa: E402  (휠과 같은 동작 코드)

PORT = 41234
CFG_DIR = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "beluga"
DECK = CFG_DIR / "deck.json"
PIN = CFG_DIR / "deck-pin"
ICONS = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache") / "beluga" / "deck-icons"
APK = Path("/usr/share/beluga/deck/beluga-deck.apk")
DEFAULT = Path("/usr/share/beluga/deck-default.json")
clients = set()


def pin():
    try:
        p = PIN.read_text().strip()
        if p.isdigit() and len(p) == 4:
            return p
    except OSError:
        pass
    CFG_DIR.mkdir(parents=True, exist_ok=True)
    p = f"{random.randint(0, 9999):04d}"
    PIN.write_text(p + "\n")
    return p


def load_deck():
    for f in (DECK, DEFAULT):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            break
        except (OSError, ValueError):
            d = None
    d = d or {}
    cols = max(1, min(10, int(d.get("cols", 5))))
    rows = max(1, min(8, int(d.get("rows", 3))))
    pages = d.get("pages") or [{"name": "페이지 1", "buttons": []}]
    for pg in pages:
        b = list(pg.get("buttons") or [])[: cols * rows]
        pg["buttons"] = b + [None] * (cols * rows - len(b))
    return {"cols": cols, "rows": rows, "pages": pages}


def layout_msg():
    d = load_deck()
    for pg in d["pages"]:
        for b in pg["buttons"]:
            if b:
                # 폰은 그림을 /icon/<파일> 로 받음 (Beluga 설정이 저장할 때 PNG로 만들어 둠)
                b["iconUrl"] = f"/icon/{b['iconFile']}" if b.get("iconFile") else ""
    return {"type": "layout", "host": socket.gethostname(), **d}


async def ws_handler(request):
    ws = web.WebSocketResponse(heartbeat=20)
    await ws.prepare(request)
    if request.query.get("pin") != pin():
        await ws.send_json({"type": "error", "reason": "pin"})
        await ws.close()
        return ws
    clients.add(ws)
    await ws.send_json(layout_msg())
    try:
        async for msg in ws:
            if msg.type != WSMsgType.TEXT:
                continue
            try:
                m = json.loads(msg.data)
            except ValueError:
                continue
            if m.get("type") == "press":
                d = load_deck()
                try:
                    b = d["pages"][int(m["page"])]["buttons"][int(m["index"])]
                except (KeyError, IndexError, ValueError, TypeError):
                    b = None
                if b:
                    await asyncio.get_running_loop().run_in_executor(None, actions.run, b.get("action"))
                    await ws.send_json({"type": "pressed", "page": m["page"], "index": m["index"]})
    finally:
        clients.discard(ws)
    return ws


async def icon(request):
    name = os.path.basename(request.match_info["name"])
    f = ICONS / name
    if not f.is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(f, headers={"Cache-Control": "max-age=86400"})


async def apk(request):
    if not APK.is_file():
        raise web.HTTPNotFound(text="폰 앱이 아직 없어요")
    return web.FileResponse(APK, headers={"Content-Disposition": 'attachment; filename="beluga-deck.apk"'})


async def index(request):
    return web.Response(content_type="text/html", text=f"""<!doctype html><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Beluga 덱</title>
<body style="font-family:sans-serif;background:#0b2a4a;color:#fff;text-align:center;padding:40px 16px">
<h1>Beluga 덱</h1><p>{socket.gethostname()} 에 연결하는 폰 앱이에요.</p>
<p><a href="/app.apk" style="display:inline-block;background:#3d63d6;color:#fff;padding:14px 22px;border-radius:12px;text-decoration:none;font-size:18px">폰 앱 내려받기 (안드로이드)</a></p>
<p style="opacity:.8">설치하고 열면 이 컴퓨터를 자동으로 찾아요.<br>연결 코드는 PC의 Beluga 설정 → 폰 덱 탭에 있어요.</p></body>""")


async def watch_config(app):
    """deck.json / 그림이 바뀌면 연결된 폰 전부에 새 배열 보내기"""
    last = None
    while True:
        try:
            st = (DECK.stat().st_mtime if DECK.exists() else 0, ICONS.stat().st_mtime if ICONS.exists() else 0)
        except OSError:
            st = None
        if last is not None and st != last:
            msg = layout_msg()
            for ws in list(clients):
                try:
                    await ws.send_json(msg)
                except Exception:
                    clients.discard(ws)
        last = st
        await asyncio.sleep(1)


async def on_start(app):
    app["watch"] = asyncio.create_task(watch_config(app))
    # 같은 와이파이의 폰이 자동으로 찾게 (avahi)
    try:
        app["avahi"] = subprocess.Popen(["avahi-publish-service", f"Beluga 덱 ({socket.gethostname()})",
                                         "_beluga-deck._tcp", str(PORT)],
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        app["avahi"] = None


async def on_stop(app):
    app["watch"].cancel()
    if app.get("avahi"):
        app["avahi"].terminate()


def main():
    pin()
    app = web.Application()
    app.add_routes([web.get("/", index), web.get("/ws", ws_handler),
                    web.get("/icon/{name}", icon), web.get("/app.apk", apk)])
    app.on_startup.append(on_start)
    app.on_cleanup.append(on_stop)
    web.run_app(app, host="0.0.0.0", port=PORT, print=None)


if __name__ == "__main__":
    main()
