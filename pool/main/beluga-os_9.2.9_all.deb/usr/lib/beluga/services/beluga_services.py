#!/usr/bin/python3
"""Beluga 서비스 관리자 (2026-11-05): 윈도우 "서비스"처럼 백그라운드 서비스 보기·켜기·끄기·자동 시작

- 시스템 서비스: 바꿀 때 관리자 비밀번호 (pkexec systemctl)
- 내 서비스(로그인한 사용자 것): 비밀번호 없이 (systemctl --user)
"""
import json
import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QObject, QUrl, Slot
from PySide6.QtGui import QGuiApplication, QIcon
from PySide6.QtQml import QQmlApplicationEngine

HERE = Path(__file__).resolve().parent


def _ctl(user, *args):
    return ["systemctl", "--user", *args] if user else ["systemctl", *args]


class Services(QObject):
    @Slot(bool, result=str)
    def list(self, user):
        units = {}
        r = subprocess.run(_ctl(user, "list-units", "--type=service", "--all", "--no-pager", "--output=json"),
                           capture_output=True, text=True)
        try:
            for u in json.loads(r.stdout or "[]"):
                units[u["unit"]] = {"name": u["unit"], "desc": u.get("description", ""), "active": u.get("active", ""),
                                    "sub": u.get("sub", ""), "enabled": ""}
        except ValueError:
            pass
        r = subprocess.run(_ctl(user, "list-unit-files", "--type=service", "--no-pager", "--output=json"),
                           capture_output=True, text=True)
        try:
            for f in json.loads(r.stdout or "[]"):
                n = f["unit_file"]
                if n.endswith("@.service"):
                    continue                                   # 틀(템플릿)은 빼기
                u = units.setdefault(n, {"name": n, "desc": "", "active": "inactive", "sub": "dead", "enabled": ""})
                u["enabled"] = f.get("state", "")
        except ValueError:
            pass
        out = sorted(units.values(), key=lambda u: (u["active"] != "active", u["name"]))
        return json.dumps(out, ensure_ascii=False)

    @Slot(bool, str, str, result=str)
    def act(self, user, verb, name):
        """verb = start / stop / restart / enable / disable"""
        if verb not in ("start", "stop", "restart", "enable", "disable") or "/" in name:
            return "잘못된 요청"
        argv = _ctl(user, verb, name)
        if not user:
            argv = ["pkexec", *argv]
        r = subprocess.run(argv, capture_output=True, text=True)
        return "" if r.returncode == 0 else (r.stderr.strip() or "실패 (비밀번호를 취소했을 수 있어요)")


def main():
    os.environ.setdefault("QT_QUICK_CONTROLS_STYLE", "Basic")
    app = QGuiApplication(sys.argv)
    app.setApplicationDisplayName("서비스 관리자")
    app.setDesktopFileName("beluga-services")
    app.setWindowIcon(QIcon.fromTheme("preferences-system-services"))
    s = Services()
    e = QQmlApplicationEngine()
    e.rootContext().setContextProperty("svc", s)
    e.load(QUrl.fromLocalFile(str(HERE / "Services.qml")))
    return app.exec() if e.rootObjects() else 1


if __name__ == "__main__":
    sys.exit(main())
