// Beluga 서비스 관리자 화면
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ApplicationWindow {
    id: win
    width: 980
    height: 680
    visible: true
    title: "서비스 관리자"
    SystemPalette { id: pal }
    readonly property bool light: Math.max(pal.window.r, pal.window.g, pal.window.b) > 0.5
    readonly property color textColor: light ? "#1b1d21" : "#e6e9ee"
    readonly property color subColor: light ? "#69707a" : "#9aa1ab"
    readonly property color rowColor: light ? "#ffffff" : "#1f2227"
    color: light ? "#f4f6f8" : "#16181c"

    property bool user: false
    property var all: JSON.parse(svc.list(false))
    property string msg: ""
    function reload() { all = JSON.parse(svc.list(user)) }
    readonly property var shown: {
        var q = search.text.toLowerCase(), out = []
        for (var i = 0; i < all.length; i++) {
            var u = all[i]
            if (q && u.name.toLowerCase().indexOf(q) < 0 && u.desc.toLowerCase().indexOf(q) < 0) continue
            if (onlyRunning.checked && u.active !== "active") continue
            out.push(u)
        }
        return out
    }
    function stateText(u) {
        if (u.active === "active") return u.sub === "running" ? "실행 중" : "켜짐 (" + u.sub + ")"
        if (u.active === "failed") return "오류로 멈춤"
        return "꺼짐"
    }
    function enabledText(e) {
        return { enabled: "자동 시작", disabled: "수동", static: "다른 것이 켬", masked: "막힘", "enabled-runtime": "자동 (이번만)",
                 indirect: "다른 것이 켬", generated: "자동 생성", alias: "별명" }[e] || (e || "-")
    }
    function act(verb, name) {
        var e = svc.act(win.user, verb, name)
        win.msg = e ? "⚠ " + e : name + " : " + { start: "켰어요", stop: "껐어요", restart: "다시 켰어요", enable: "자동 시작으로", disable: "수동으로" }[verb]
        reload()
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 22
        spacing: 12
        RowLayout {
            Text { text: "서비스 관리자"; color: win.textColor; font.pixelSize: 24; font.bold: true }
            Item { Layout.fillWidth: true }
            TabBar {
                currentIndex: win.user ? 1 : 0
                onCurrentIndexChanged: { win.user = currentIndex === 1; win.reload() }
                TabButton { text: "시스템"; width: 110 }
                TabButton { text: "내 것"; width: 110 }
            }
        }
        RowLayout {
            TextField { id: search; Layout.fillWidth: true; placeholderText: "이름이나 설명으로 찾기" }
            CheckBox { id: onlyRunning; text: "실행 중인 것만" }
            Button { text: "새로고침"; onClicked: win.reload() }
        }
        Text { visible: win.msg !== ""; text: win.msg; color: win.textColor }
        ListView {
            id: list
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            spacing: 6
            model: win.shown
            ScrollBar.vertical: ScrollBar {}
            delegate: Rectangle {
                required property var modelData
                width: list.width
                height: 58
                radius: 10
                color: win.rowColor
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 10
                    spacing: 10
                    Rectangle { width: 10; height: 10; radius: 5; color: modelData.active === "active" ? "#3fb950" : modelData.active === "failed" ? "#e5534b" : "#8b949e" }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 1
                        Text { text: modelData.desc || modelData.name; color: win.textColor; font.bold: true; elide: Text.ElideRight; Layout.fillWidth: true }
                        Text { text: modelData.name; color: win.subColor; font.pixelSize: 12; elide: Text.ElideRight; Layout.fillWidth: true }
                    }
                    Text { text: win.stateText(modelData); color: win.textColor; Layout.preferredWidth: 110 }
                    Text { text: win.enabledText(modelData.enabled); color: win.subColor; Layout.preferredWidth: 100 }
                    Button { text: modelData.active === "active" ? "끄기" : "켜기"; onClicked: win.act(modelData.active === "active" ? "stop" : "start", modelData.name) }
                    Button { text: "다시 켜기"; visible: modelData.active === "active"; onClicked: win.act("restart", modelData.name) }
                    Button {
                        visible: modelData.enabled === "enabled" || modelData.enabled === "disabled"
                        text: modelData.enabled === "enabled" ? "자동 시작 끄기" : "자동 시작 켜기"
                        onClicked: win.act(modelData.enabled === "enabled" ? "disable" : "enable", modelData.name)
                    }
                }
            }
        }
    }
}
