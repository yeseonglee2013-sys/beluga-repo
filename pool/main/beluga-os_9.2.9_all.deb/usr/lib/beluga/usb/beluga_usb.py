#!/usr/bin/python3
"""Beluga USB 굽기 (2026-11-05): ISO 고르고 → USB 고르고 → 굽기 → 검증
USB로 꽂은 것만 보여줌 (내장 디스크를 실수로 지우지 않게). 실제 쓰기는 beluga-usb-write (관리자 권한)
"""
import json
import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import Property, QObject, QProcess, QUrl, Signal, Slot
from PySide6.QtGui import QGuiApplication, QIcon
from PySide6.QtQml import QQmlApplicationEngine

HERE = Path(__file__).resolve().parent


class Usb(QObject):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self._status, self._pct, self._busy = "", 0, False
        self._proc = None

    status = Property(str, lambda s: s._status, notify=changed)
    percent = Property(int, lambda s: s._pct, notify=changed)
    busy = Property(bool, lambda s: s._busy, notify=changed)

    @Slot(result=str)
    def drives(self):
        r = subprocess.run(["lsblk", "-J", "-b", "-d", "-o", "NAME,SIZE,TRAN,MODEL,VENDOR,TYPE"],
                           capture_output=True, text=True)
        out = []
        try:
            devs = json.loads(r.stdout or "{}").get("blockdevices", [])
        except ValueError:
            devs = []
        for d in devs:
            if d.get("tran") == "usb" and d.get("type") == "disk" and int(d.get("size") or 0) > 0:
                gb = int(d["size"]) / 1e9
                name = " ".join(x.strip() for x in (d.get("vendor") or "", d.get("model") or "") if x and x.strip()) or "USB"
                out.append({"dev": "/dev/" + d["name"], "label": f"{name} · {gb:.1f} GB · /dev/{d['name']}"})
        return json.dumps(out, ensure_ascii=False)

    @Slot(str, str)
    def burn(self, iso, dev):
        iso = iso.replace("file://", "")
        self._busy, self._pct, self._status = True, 0, "굽는 중… (USB를 빼지 마세요)"
        self.changed.emit()
        self._proc = QProcess(self)
        self._proc.setProcessChannelMode(QProcess.MergedChannels)
        self._proc.readyReadStandardOutput.connect(self._read)
        self._proc.finished.connect(self._done)
        self._proc.start("pkexec", ["/usr/bin/beluga-usb-write", iso, dev])

    def _read(self):
        for line in bytes(self._proc.readAllStandardOutput()).decode("utf-8", "replace").splitlines():
            if line.startswith("PROGRESS "):
                try:
                    self._pct = min(100, int(line.split()[1]))
                except (IndexError, ValueError):
                    pass
            elif line.startswith("VERIFY"):
                self._pct, self._status = 100, "다 썼어요. 제대로 써졌는지 확인하는 중…"
            elif line == "DONE":
                self._status = "완료! 이제 USB를 빼도 돼요."
            elif line.startswith("FAIL"):
                self._status = "실패: " + line[5:]
        self.changed.emit()

    def _done(self, code, _status):
        if code != 0 and not self._status.startswith("실패"):
            self._status = "취소했거나 실패했어요 (관리자 비밀번호를 안 넣었을 수 있어요)"
        self._busy = False
        self.changed.emit()


def main():
    os.environ.setdefault("QT_QUICK_CONTROLS_STYLE", "Basic")
    app = QGuiApplication(sys.argv)
    app.setApplicationDisplayName("USB 굽기")
    app.setDesktopFileName("beluga-usb")
    app.setWindowIcon(QIcon.fromTheme("media-flash"))
    u = Usb()
    e = QQmlApplicationEngine()
    e.rootContext().setContextProperty("usb", u)
    e.load(QUrl.fromLocalFile(str(HERE / "Usb.qml")))
    return app.exec() if e.rootObjects() else 1


if __name__ == "__main__":
    sys.exit(main())
