// Beluga USB 굽기 화면
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

ApplicationWindow {
    id: win
    width: 560
    height: 440
    visible: true
    title: "USB 굽기"
    SystemPalette { id: pal }
    readonly property bool light: Math.max(pal.window.r, pal.window.g, pal.window.b) > 0.5
    readonly property color textColor: light ? "#1b1d21" : "#e6e9ee"
    readonly property color subColor: light ? "#69707a" : "#9aa1ab"
    color: light ? "#f4f6f8" : "#16181c"
    property string iso: ""
    property var drives: JSON.parse(usb.drives())
    // USB를 꽂거나 빼면 2초 안에 목록이 바뀜
    Timer { interval: 2000; running: !usb.busy; repeat: true; onTriggered: win.drives = JSON.parse(usb.drives()) }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 28
        spacing: 14
        Text { text: "USB 굽기"; color: win.textColor; font.pixelSize: 24; font.bold: true }
        Text {
            Layout.fillWidth: true
            text: "ISO 파일을 USB에 굽고, 다 쓴 뒤 똑같이 써졌는지 확인해요. USB 안의 내용은 전부 지워져요."
            color: win.subColor
            wrapMode: Text.WordWrap
        }
        Text { text: "1. ISO 파일"; color: win.textColor; font.bold: true }
        RowLayout {
            Text {
                Layout.fillWidth: true
                text: win.iso ? decodeURIComponent(win.iso.replace("file://", "")) : "아직 안 골랐어요"
                color: win.subColor
                elide: Text.ElideMiddle
            }
            Button { text: "고르기"; enabled: !usb.busy; onClicked: isoDialog.open() }
        }
        Text { text: "2. USB (USB로 꽂은 것만 보여요)"; color: win.textColor; font.bold: true }
        ComboBox {
            id: drive
            Layout.fillWidth: true
            enabled: !usb.busy
            model: win.drives
            textRole: "label"
            displayText: count ? currentText : "USB를 꽂아 주세요"
        }
        Item { Layout.fillHeight: true }
        ProgressBar { Layout.fillWidth: true; visible: usb.busy || usb.percent > 0; from: 0; to: 100; value: usb.percent }
        Text { Layout.fillWidth: true; text: usb.status; color: win.textColor; wrapMode: Text.WordWrap }
        Button {
            Layout.alignment: Qt.AlignRight
            text: usb.busy ? "굽는 중…" : "굽기"
            enabled: !usb.busy && win.iso !== "" && drive.count > 0
            onClicked: confirm.open()
        }
    }
    FileDialog { id: isoDialog; nameFilters: ["ISO (*.iso *.img)"]; onAccepted: win.iso = selectedFile.toString() }
    Dialog {
        id: confirm
        modal: true
        anchors.centerIn: parent
        title: "정말 구울까요?"
        standardButtons: Dialog.Yes | Dialog.No
        Text { text: drive.currentText + "\n이 USB의 내용이 전부 지워져요."; color: win.textColor }
        onAccepted: usb.burn(decodeURIComponent(win.iso), win.drives[drive.currentIndex].dev)
    }
}
