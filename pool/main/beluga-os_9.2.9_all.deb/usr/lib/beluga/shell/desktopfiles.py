"""설치된 앱 목록(.desktop) 읽기: 앱 실행, 프로세스 이름 → 앱 이름/아이콘 찾기"""
import os
import shlex
from configparser import ConfigParser
from functools import lru_cache
from pathlib import Path


def _app_dirs():
    home = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local/share")
    dirs = [home] + (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":")
    dirs += ["/var/lib/flatpak/exports/share", str(Path.home() / ".local/share/flatpak/exports/share")]
    out = []
    for d in dirs:
        p = Path(d) / "applications"
        if p.is_dir() and p not in out:
            out.append(p)
    return out


def _read(path):
    cp = ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    try:
        cp.read(path, encoding="utf-8")
        return cp["Desktop Entry"] if cp.has_section("Desktop Entry") else None
    except Exception:
        return None


def find_desktop(name):
    """"code" / "code.desktop" / 전체 경로 → .desktop 파일 경로"""
    if not name:
        return None
    if name.startswith("/") and Path(name).is_file():
        return Path(name)
    fn = name if name.endswith(".desktop") else name + ".desktop"
    for d in _app_dirs():
        p = d / fn
        if p.is_file():
            return p
    return None


def exec_argv(path):
    e = _read(path)
    if not e or "Exec" not in e:
        return None
    try:
        argv = shlex.split(e["Exec"])
    except ValueError:
        return None
    # %f %u %F %U %i %c %k 같은 자리표시 빼기
    return [a for a in argv if not (len(a) == 2 and a[0] == "%")]


def display_name(e):
    return e.get("Name[ko]") or e.get("Name") or ""


@lru_cache(maxsize=1)
def index():
    """실행파일 이름 / 창 이름(StartupWMClass) → {name, icon}"""
    idx = {}
    for d in reversed(_app_dirs()):          # 앞 폴더(사용자)가 이기게 뒤에서부터
        for p in d.glob("*.desktop"):
            e = _read(p)
            if not e or e.get("Type", "Application") != "Application":
                continue
            info = {"name": display_name(e), "icon": e.get("Icon", "")}
            argv = exec_argv(p) or []
            # flatpak run org.x.Y 는 앱 ID, env A=B cmd 는 cmd
            args = [a for a in argv if "=" not in a or a.startswith("-")]
            if args[:2] == ["flatpak", "run"] or (args and args[0].endswith("/flatpak")):
                keys = [a for a in args[2:] if not a.startswith("-")][:1]
            else:
                keys = [os.path.basename(args[0])] if args else []
            if e.get("StartupWMClass"):
                keys.append(e["StartupWMClass"].lower())
            keys.append(p.stem.lower())
            for k in keys:
                idx[k.lower()] = info
    return idx


def lookup(proc_name, exe):
    idx = index()
    for k in (os.path.basename(exe or ""), proc_name or ""):
        if k and k.lower() in idx:
            return idx[k.lower()]
    return None
