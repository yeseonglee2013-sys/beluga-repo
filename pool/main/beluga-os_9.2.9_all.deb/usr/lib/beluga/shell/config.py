"""Beluga 셸 설정 읽기/쓰기 (휠 9개 + 절전 휠)

사용자 설정: ~/.config/beluga/wheel.json  (Beluga 설정 앱이 씀)
기본값:      /usr/share/beluga/wheel-default.json
사용자 파일이 없거나 깨졌으면 기본값을 씀 → 휠이 안 뜨는 일이 없게.
"""
import json
import os
from pathlib import Path

DEFAULT = Path("/usr/share/beluga/wheel-default.json")
TABS = 9                 # Tab+1 ~ Tab+9
SLOTS = 8                # 휠 한 개에 칸 8개 (위부터 시계 방향)


def user_path() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "beluga" / "wheel.json"


def _empty_tab(i):
    return {"name": f"탭 {i + 1}", "slots": [None] * SLOTS}


def _normalize(data):
    tabs = list(data.get("tabs") or [])[:TABS]
    while len(tabs) < TABS:
        tabs.append(_empty_tab(len(tabs)))
    for i, t in enumerate(tabs):
        if not isinstance(t, dict):
            tabs[i] = t = _empty_tab(i)
        t.setdefault("name", f"탭 {i + 1}")
        slots = list(t.get("slots") or [])[:SLOTS]
        slots += [None] * (SLOTS - len(slots))
        for s in slots:
            if isinstance(s, dict) and not s.get("icon"):
                s["icon"] = _app_icon(s.get("action") or {})
        t["slots"] = slots
    return {"tabs": tabs}


def _app_icon(action):
    """앱 칸인데 아이콘을 안 정했으면 그 앱의 아이콘을 씀"""
    if action.get("type") == "app":
        try:
            from desktopfiles import find_desktop, _read
            p = find_desktop(str(action.get("value", "")))
            e = _read(p) if p else None
            if e and e.get("Icon"):
                return e["Icon"]
        except Exception:
            pass
    return "application-x-executable"


def load():
    for p in (user_path(), DEFAULT):
        try:
            with open(p, encoding="utf-8") as f:
                return _normalize(json.load(f))
        except (OSError, ValueError):
            continue
    return _normalize({})


def save(data):
    p = user_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_normalize(data), f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)       # 쓰다가 꺼져도 반쯤 쓴 파일이 남지 않게


# 절전 휠 (Esc+Tab): 고정 메뉴
SLEEP_TAB = {
    "name": "절전",
    "slots": [
        {"label": "계속 안 꺼지기", "icon": "system-suspend-inhibited", "action": {"type": "sleep", "value": "never"}},
        {"label": "5분 뒤 절전", "icon": "chronometer", "action": {"type": "sleep", "value": "5"}},
        {"label": "10분 뒤 절전", "icon": "chronometer", "action": {"type": "sleep", "value": "10"}},
        {"label": "30분 뒤 절전", "icon": "chronometer", "action": {"type": "sleep", "value": "30"}},
        {"label": "1시간 뒤 절전", "icon": "chronometer", "action": {"type": "sleep", "value": "60"}},
        {"label": "지금 절전", "icon": "system-suspend", "action": {"type": "sleep", "value": "now"}},
        {"label": "원래대로", "icon": "edit-undo", "action": {"type": "sleep", "value": "reset"}},
        None,
    ],
}
