"""프로세스 종료 창(Ctrl+Shift+Backspace)에 보여줄 "내가 켠 프로그램" 목록

- 내 계정으로 도는 것만 (백그라운드 포함), 화면·소리·입력기 같은 시스템 부품은 숨김
- 같은 앱의 여러 프로세스(크롬 탭들 등)는 하나로 묶어서 램/CPU/GPU를 더함 → 누르면 통째로 종료
- GPU: 그래픽 드라이버가 /proc/<pid>/fdinfo 에 적는 사용 시간(drm-engine-*)으로 계산 (AMD/인텔)
"""
import os
import signal
import time

import psutil

from desktopfiles import lookup

# 숨길 것: 이게 죽으면 화면/로그인/소리/입력이 망가지는 시스템 부품
HIDDEN = {
    "systemd", "(sd-pam)", "dbus-daemon", "dbus-broker", "dbus-broker-launch",
    "pipewire", "pipewire-pulse", "wireplumber", "pulseaudio",
    "kwin_wayland", "kwin_wayland_wrapper", "kwin_x11", "Xwayland", "plasmashell", "ksmserver", "kded6",
    "kglobalacceld", "kaccess", "polkit-kde-authentication-agent-1", "polkit-kde-auth",
    "startplasma-wayland", "startplasma-x11", "plasma_session", "kactivitymanagerd", "kwalletd6", "ksecretd",
    "xdg-desktop-portal", "xdg-desktop-portal-kde", "xdg-desktop-portal-gtk", "xdg-document-portal",
    "xdg-permission-store", "at-spi-bus-launcher", "at-spi2-registryd", "dconf-service",
    "baloo_file", "baloo_file_extractor", "baloorunner", "krunner", "fcitx5", "xembedsniproxy", "gmenudbusmenuproxy",
    "kscreen_backend_launcher", "org_kde_powerdevil", "kdeconnectd", "DiscoverNotifier", "kalendarac",
    "obexd", "mpris-proxy", "gvfsd", "gvfsd-fuse", "gvfsd-metadata", "gvfs-udisks2-volume-monitor",
    "ssh-agent", "gpg-agent", "sddm-helper", "sddm", "kde-inhibit", "systemd-inhibit",
    "bash", "sh", "zsh", "fish", "dash", "sleep",
}


def _gpu_ns(pid):
    """이 프로세스가 GPU를 쓴 누적 시간(ns). 같은 GPU 연결(drm-client-id)은 한 번만 셈"""
    total, seen = 0, set()
    fd_dir = f"/proc/{pid}/fd"
    try:
        fds = os.listdir(fd_dir)
    except OSError:
        return 0
    for fd in fds:
        try:
            if not os.readlink(f"{fd_dir}/{fd}").startswith("/dev/dri/"):
                continue
            with open(f"/proc/{pid}/fdinfo/{fd}") as f:
                text = f.read()
        except OSError:
            continue
        cid, ns = None, 0
        for line in text.splitlines():
            if line.startswith("drm-client-id:"):
                cid = line.split(":", 1)[1].strip()
            elif line.startswith("drm-engine-") and line.endswith(" ns"):
                try:
                    ns += int(line.split(":", 1)[1].split()[0])
                except ValueError:
                    pass
        if cid in seen:
            continue
        seen.add(cid)
        total += ns
    return total


class ProcTable:
    def __init__(self):
        self._proc = {}        # pid → psutil.Process (CPU %를 재려면 같은 객체를 계속 써야 함)
        self._gpu_prev = {}    # pid → (시각, ns)
        self.me = os.getuid()
        self.self_pid = os.getpid()
        self.ncpu = psutil.cpu_count() or 1

    def _app_key(self, p, name, exe):
        """같은 앱으로 묶을 이름: 부모가 같은 앱이면 부모 쪽 이름"""
        return os.path.basename(exe) if exe else name

    def sample(self):
        now = time.monotonic()
        groups = {}
        alive = set()
        for p in psutil.process_iter(["pid", "name", "exe", "uids", "memory_info", "cmdline"]):
            info = p.info
            pid = info["pid"]
            if pid == self.self_pid or not info.get("uids") or info["uids"].real != self.me:
                continue
            name = info.get("name") or ""
            if name in HIDDEN or not info.get("cmdline"):       # cmdline 없음 = 커널 스레드/좀비
                continue
            exe = info.get("exe") or ""
            if "/beluga/shell/" in " ".join(info["cmdline"][:2]):
                continue                                         # Beluga 셸 자신
            alive.add(pid)
            proc = self._proc.get(pid)
            if proc is None:
                proc = self._proc[pid] = p
                proc.cpu_percent(None)                           # 첫 측정은 기준점
                cpu = 0.0
            else:
                try:
                    cpu = proc.cpu_percent(None) / self.ncpu
                except psutil.Error:
                    continue
            g_ns = _gpu_ns(pid)
            prev = self._gpu_prev.get(pid)
            gpu = 0.0
            if prev and now > prev[0] and g_ns >= prev[1]:
                gpu = min(100.0, (g_ns - prev[1]) / ((now - prev[0]) * 1e9) * 100)
            self._gpu_prev[pid] = (now, g_ns)

            key = self._app_key(p, name, exe)
            g = groups.get(key)
            if g is None:
                app = lookup(name, exe)
                g = groups[key] = {
                    "key": key,
                    "name": (app or {}).get("name") or name,
                    "icon": (app or {}).get("icon") or "application-x-executable",
                    "pids": [], "ram": 0, "cpu": 0.0, "gpu": 0.0,
                }
            g["pids"].append(pid)
            mem = info.get("memory_info")
            g["ram"] += mem.rss if mem else 0
            g["cpu"] += cpu
            g["gpu"] += gpu
        for pid in list(self._proc):
            if pid not in alive:
                self._proc.pop(pid, None)
                self._gpu_prev.pop(pid, None)
        out = []
        for g in groups.values():
            g["count"] = len(g["pids"])
            g["ramText"] = _size(g["ram"])
            g["cpu"] = round(min(g["cpu"], 100.0), 1)
            g["gpu"] = round(min(g["gpu"], 100.0), 1)
            out.append(g)
        out.sort(key=lambda g: g["ram"], reverse=True)
        return out

    def kill(self, pids):
        """먼저 정상 종료 요청(TERM) → 2초 뒤에도 살아 있으면 강제 종료(KILL)"""
        procs = []
        for pid in pids:
            try:
                pr = psutil.Process(pid)
                if pr.uids().real != self.me:
                    continue
                pr.send_signal(signal.SIGTERM)
                procs.append(pr)
            except psutil.Error:
                pass
        _, left = psutil.wait_procs(procs, timeout=2)
        for pr in left:
            try:
                pr.kill()
            except psutil.Error:
                pass


def _size(b):
    if b >= 1 << 30:
        return f"{b / (1 << 30):.1f} GB"
    return f"{b / (1 << 20):.0f} MB"
