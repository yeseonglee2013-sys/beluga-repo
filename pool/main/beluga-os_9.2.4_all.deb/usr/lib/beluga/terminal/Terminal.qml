// Beluga 터미널 화면: 위 = 명령 카드들, 아래 = 입력창 (AI 대화창처럼)
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window

ApplicationWindow {
    id: win
    width: 980
    height: 680
    visible: true
    title: "터미널 — " + term.cwd

    SystemPalette { id: pal }
    readonly property bool light: Math.max(pal.window.r, pal.window.g, pal.window.b) > 0.5
    readonly property color bg: light ? "#f4f6f8" : "#16181c"
    readonly property color cardBg: light ? "#ffffff" : "#1f2227"
    readonly property color outBg: light ? "#f0f2f5" : "#121418"
    readonly property color textColor: light ? "#1b1d21" : "#e6e9ee"
    readonly property color subColor: light ? "#69707a" : "#9aa1ab"
    readonly property color accent: "#3d63d6"
    readonly property string mono: "DejaVu Sans Mono, Noto Sans Mono CJK KR, monospace"

    color: bg

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        ListView {
            id: list
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            spacing: 14
            topMargin: 18
            bottomMargin: 18
            leftMargin: 22
            rightMargin: 22
            model: term.cards
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar {}
            onCountChanged: Qt.callLater(() => list.positionViewAtEnd())

            // 처음 화면 (카드가 없을 때)
            Column {
                anchors.centerIn: parent
                visible: list.count === 0
                spacing: 8
                Text { anchors.horizontalCenter: parent.horizontalCenter; text: "무엇을 실행할까요?"; color: win.textColor; font.pixelSize: 24; font.bold: true }
                Text { anchors.horizontalCenter: parent.horizontalCenter; text: "아래에 명령을 입력하고 Enter · ↑↓ 이전 명령 · Tab 파일 이름 채우기 · Ctrl+C 멈추기"; color: win.subColor; font.pixelSize: 13 }
            }

            delegate: Rectangle {
                id: card
                required property var modelData
                readonly property var c: modelData
                width: list.width - list.leftMargin - list.rightMargin
                height: cardCol.implicitHeight + 24
                radius: 14
                color: win.cardBg
                border.color: c.state === "fail" ? Qt.rgba(0.9, 0.3, 0.3, 0.5) : (win.light ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(1, 1, 1, 0.05))

                ColumnLayout {
                    id: cardCol
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 12
                    spacing: 8

                    // 명령 줄: 상태 점 + 명령 + 걸린 시간 + 버튼
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 10
                        Rectangle {
                            width: 10; height: 10; radius: 5
                            color: card.c.state === "running" ? win.accent : card.c.state === "ok" ? "#3fb950" : card.c.state === "fail" ? "#e5534b" : "#a371f7"
                            SequentialAnimation on opacity {
                                running: card.c.state === "running"; loops: Animation.Infinite
                                NumberAnimation { to: 0.3; duration: 500 } NumberAnimation { to: 1; duration: 500 }
                            }
                        }
                        Text {
                            Layout.fillWidth: true
                            text: card.c.cmd
                            color: win.textColor
                            font.family: win.mono
                            font.pixelSize: 14
                            font.bold: true
                            wrapMode: Text.WrapAnywhere
                        }
                        Text {
                            text: card.c.cwd + " · " + card.c.took + (card.c.state === "fail" ? " · 종료 코드 " + card.c.code : "")
                            color: win.subColor
                            font.pixelSize: 12
                        }
                        SmallButton { text: "복사"; onClicked: term.copy(card.c.plain) }
                        SmallButton { text: "다시"; visible: card.c.state !== "running"; onClicked: term.run(card.c.cmd) }
                        SmallButton { text: "멈추기"; visible: card.c.state === "running"; onClicked: term.interrupt() }
                    }

                    // 결과
                    Rectangle {
                        Layout.fillWidth: true
                        visible: out.text.length > 0
                        implicitHeight: Math.min(out.implicitHeight + 16, 520)
                        radius: 10
                        color: win.outBg
                        Flickable {
                            anchors.fill: parent
                            anchors.margins: 8
                            contentHeight: out.implicitHeight
                            clip: true
                            boundsBehavior: Flickable.StopAtBounds
                            interactive: contentHeight > height
                            onContentHeightChanged: if (card.c.state === "running") contentY = Math.max(0, contentHeight - height)
                            ScrollBar.vertical: ScrollBar {}
                            TextEdit {
                                id: out
                                width: parent.width
                                readOnly: true
                                selectByMouse: true
                                textFormat: TextEdit.RichText
                                text: card.c.html
                                color: win.textColor
                                font.family: win.mono
                                font.pixelSize: 13
                                wrapMode: TextEdit.WrapAnywhere
                            }
                        }
                    }

                    // 실행 중인 명령이 입력을 기다릴 때 (비밀번호 등)
                    RowLayout {
                        Layout.fillWidth: true
                        visible: card.c.state === "running" && card.c.waitingInput
                        TextField {
                            id: answer
                            Layout.fillWidth: true
                            placeholderText: "여기에 입력하고 Enter (비밀번호는 안 보여요)"
                            echoMode: /password|암호|비밀번호/i.test(card.c.plain.slice(-80)) ? TextInput.Password : TextInput.Normal
                            color: win.textColor
                            background: Rectangle { radius: 8; color: win.outBg; border.color: win.accent }
                            onAccepted: { term.send(text); text = "" }
                            onVisibleChanged: if (visible) forceActiveFocus()
                        }
                    }
                }
            }
        }

        // ---- 입력창 ----
        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: inputBox.implicitHeight + 28
            color: win.bg
            Rectangle {
                id: inputBox
                anchors.fill: parent
                anchors.leftMargin: 22
                anchors.rightMargin: 22
                anchors.bottomMargin: 16
                anchors.topMargin: 6
                implicitHeight: Math.max(52, input.implicitHeight + 22)
                radius: 18
                color: win.cardBg
                border.color: input.activeFocus ? win.accent : (win.light ? Qt.rgba(0, 0, 0, 0.1) : Qt.rgba(1, 1, 1, 0.1))
                border.width: input.activeFocus ? 2 : 1

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 16
                    anchors.rightMargin: 8
                    spacing: 10
                    Text { text: term.cwd; color: win.subColor; font.family: win.mono; font.pixelSize: 13 }
                    Text { text: "›"; color: win.accent; font.pixelSize: 20; font.bold: true }
                    TextArea {
                        id: input
                        Layout.fillWidth: true
                        placeholderText: term.busy ? "실행 중… 입력하면 그 명령으로 보내요" : "명령을 입력하세요"
                        placeholderTextColor: win.subColor
                        color: win.textColor
                        font.family: win.mono
                        font.pixelSize: 15
                        wrapMode: TextArea.WrapAnywhere
                        background: null
                        focus: true
                        Keys.onPressed: (e) => {
                            if ((e.key === Qt.Key_Return || e.key === Qt.Key_Enter) && !(e.modifiers & Qt.ShiftModifier)) {
                                term.run(input.text); input.text = ""; e.accepted = true
                            } else if (e.key === Qt.Key_Up && input.cursorPosition <= input.text.indexOf("\n") + 1 || e.key === Qt.Key_Up && input.text.indexOf("\n") < 0) {
                                input.text = term.historyPrev(input.text); input.cursorPosition = input.text.length; e.accepted = true
                            } else if (e.key === Qt.Key_Down && input.text.indexOf("\n") < 0) {
                                input.text = term.historyNext(input.text); input.cursorPosition = input.text.length; e.accepted = true
                            } else if (e.key === Qt.Key_Tab) {
                                input.text = term.complete(input.text); input.cursorPosition = input.text.length; e.accepted = true
                            } else if (e.key === Qt.Key_C && (e.modifiers & Qt.ControlModifier) && input.selectedText === "") {
                                term.interrupt(); e.accepted = true
                            } else if (e.key === Qt.Key_L && (e.modifiers & Qt.ControlModifier)) {
                                term.run("clear"); e.accepted = true
                            }
                        }
                    }
                    Rectangle {
                        width: 36; height: 36; radius: 18
                        color: input.text.length ? win.accent : Qt.rgba(0.5, 0.5, 0.5, 0.25)
                        Text { anchors.centerIn: parent; text: term.busy && !input.text.length ? "■" : "↑"; color: "white"; font.pixelSize: 16; font.bold: true }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: { if (input.text.length) { term.run(input.text); input.text = "" } else if (term.busy) term.interrupt() }
                        }
                    }
                }
            }
        }
    }

    component SmallButton: Rectangle {
        property alias text: lbl.text
        signal clicked()
        implicitWidth: lbl.implicitWidth + 16
        implicitHeight: 24
        radius: 7
        color: ma.containsMouse ? Qt.rgba(0.5, 0.5, 0.5, 0.22) : Qt.rgba(0.5, 0.5, 0.5, 0.1)
        Text { id: lbl; anchors.centerIn: parent; color: win.textColor; font.pixelSize: 12 }
        MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: parent.clicked() }
    }
}
