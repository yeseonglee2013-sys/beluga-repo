#!/usr/bin/python3
"""Beluga 터미널 (2026-11-05): AI 대화창처럼 생긴 터미널

- 아래 입력창에 명령 → 위에 명령+결과가 카드로 쌓임 (성공 ✓ / 실패 ✗ / 걸린 시간)
- 셸(bash) 하나를 계속 켜 두고 씀 → cd, export 한 게 다음 명령에도 그대로
- 가짜 터미널(PTY)로 돌려서 ls 색깔 등이 그대로 나옴 (색은 화면용으로 바꿔서 표시)
- 실행 중인 명령이 입력을 기다리면(sudo 비밀번호 등) 카드 안에 입력칸
- vim/htop 같은 전체 화면 프로그램은 일반 터미널 창(Konsole)으로 따로 열어 줌
  beluga-terminal --run '명령'   → 켜자마자 그 명령 실행
"""
import argparse
import html
import os
import pty
import re
import shlex
import signal
import sys
import termios
import time
from pathlib import Path

from PySide6.QtCore import QObject, Property, QSocketNotifier, QTimer, QUrl, Signal, Slot
from PySide6.QtGui import QGuiApplication, QIcon
from PySide6.QtQml import QQmlApplicationEngine

HERE = Path(__file__).resolve().parent
MARK = "\x1eBELUGA_DONE"          # 명령이 끝났다는 표시 (화면에는 안 보임)
FULLSCREEN = {"vim", "vi", "nvim", "nano", "htop", "top", "btop", "less", "more", "man", "mc", "tmux",
              "screen", "ssh", "watch", "emacs", "ranger", "nmtui", "alsamixer", "fzf"}
REPL = {"python", "python3", "node", "irb", "ghci", "bash", "sh", "zsh", "lua", "sqlite3", "mysql", "psql"}

# ---- 터미널 색 코드 → 화면용 글자(HTML) ----
_ANSI = re.compile(r"\x1b\[([0-9;?]*)([A-Za-z])|\x1b\][^\x07]*(\x07|\x1b\\)|\x1b[()][0-9A-Za-z]|\r(?!\n)")
_COLORS = ["#3b3f45", "#e5534b", "#57ab5a", "#c69026", "#539bf5", "#b083f0", "#39c5cf", "#c9d1d9"]
_BRIGHT = ["#768390", "#ff938a", "#6bc46d", "#daaa3f", "#6cb6ff", "#dcbdfb", "#56d4dd", "#ffffff"]


def ansi_to_html(text):
    out, style, pos = [], {}, 0

    def open_span():
        css = []
        if "fg" in style:
            css.append(f"color:{style['fg']}")
        if style.get("bold"):
            css.append("font-weight:bold")
        return f'<span style="{";".join(css)}">' if css else ""

    def emit(s):
        if not s:
            return
        span = open_span()
        out.append(span + html.escape(s) + ("</span>" if span else ""))

    for m in _ANSI.finditer(text):
        emit(text[pos:m.start()])
        pos = m.end()
        if m.group(2) == "m":
            codes = [int(c) for c in (m.group(1) or "0").split(";") if c.isdigit()] or [0]
            i = 0
            while i < len(codes):
                c = codes[i]
                if c == 0:
                    style.clear()
                elif c == 1:
                    style["bold"] = True
                elif c == 22:
                    style.pop("bold", None)
                elif 30 <= c <= 37:
                    style["fg"] = _COLORS[c - 30]
                elif 90 <= c <= 97:
                    style["fg"] = _BRIGHT[c - 90]
                elif c == 39:
                    style.pop("fg", None)
                elif c == 38 and i + 2 < len(codes) and codes[i + 1] == 5:
                    n = codes[i + 2]
                    style["fg"] = (_COLORS + _BRIGHT)[n] if n < 16 else "#c9d1d9"
                    i += 2
                elif c == 38 and i + 4 < len(codes) and codes[i + 1] == 2:
                    style["fg"] = "#%02x%02x%02x" % tuple(codes[i + 2:i + 5])
                    i += 4
                i += 1
    emit(text[pos:])
    return "".join(out).replace("\n", "<br>")


def strip_ansi(text):
    return _ANSI.sub("", text)


class Card(QObject):
    changed = Signal()

    def __init__(self, cmd, cwd):
        super().__init__()
        self._cmd, self._cwd = cmd, cwd
        self._raw = ""
        self._state = "running"      # running / ok / fail / external
        self._code = 0
        self._started = time.monotonic()
        self._took = 0.0
        self._waiting = False

    cmd = Property(str, lambda s: s._cmd, notify=changed)
    cwd = Property(str, lambda s: s._cwd, notify=changed)
    state = Property(str, lambda s: s._state, notify=changed)
    code = Property(int, lambda s: s._code, notify=changed)
    waitingInput = Property(bool, lambda s: s._waiting, notify=changed)

    @Property(str, notify=changed)
    def html(self):
        raw = self._raw[-200_000:]          # 아주 긴 출력은 끝부분만 (화면이 느려지지 않게)
        return ansi_to_html(raw.rstrip("\n"))

    @Property(str, notify=changed)
    def plain(self):
        return strip_ansi(self._raw).rstrip("\n")

    @Property(str, notify=changed)
    def took(self):
        t = self._took if self._state != "running" else time.monotonic() - self._started
        return f"{t:.1f}초" if t < 60 else f"{int(t // 60)}분 {int(t % 60)}초"

    def add(self, s):
        self._raw += s.replace("\r\n", "\n")
        # 줄바꿈 없이 끝났는데 질문처럼 보이면(비밀번호:, [Y/n] 등) 입력칸 보여주기
        tail = strip_ansi(self._raw[-200:])
        self._waiting = bool(tail) and not tail.endswith("\n") and bool(re.search(r"(:|\?|\]|>)\s*$", tail))
        self.changed.emit()

    def finish(self, code):
        self._state = "ok" if code == 0 else "fail"
        self._code = code
        self._took = time.monotonic() - self._started
        self._waiting = False
        self.changed.emit()

    def external(self, note):
        self._raw = note
        self._state = "external"
        self._took = 0
        self.changed.emit()


class Term(QObject):
    cardsChanged = Signal()
    cwdChanged = Signal()
    busyChanged = Signal()

    def __init__(self):
        super().__init__()
        self._cards = []
        self._cur = None
        self._buf = ""
        self._cwd = str(Path.home())
        self._history = self._load_history()
        self._hpos = len(self._history)
        self._start_shell()
        self._tick = QTimer(self, interval=500, timeout=self._on_tick)
        self._tick.start()

    # ---- 셸 ----
    def _start_shell(self):
        pid, fd = pty.fork()
        if pid == 0:
            env = dict(os.environ, TERM="xterm-256color", PS1="", PS2="", PROMPT_COMMAND="",
                       CLICOLOR_FORCE="1", PAGER="cat", GIT_PAGER="cat", SYSTEMD_PAGER="", COLUMNS="200")
            os.chdir(self._cwd)
            os.execvpe("bash", ["bash", "--noprofile", "--norc"], env)
        self.pid, self.fd = pid, fd
        attrs = termios.tcgetattr(fd)
        attrs[3] &= ~termios.ECHO                       # 입력한 명령이 결과에 또 찍히지 않게
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
        self._notifier = QSocketNotifier(fd, QSocketNotifier.Read, self)
        self._notifier.activated.connect(self._on_read)
        # 사용자 설정(.bashrc: alias 등)은 읽되, 프롬프트는 안 나오게
        # 명령이 끝날 때마다 bash가 스스로 끝 표시(번호·종료코드·폴더)를 찍게 (PROMPT_COMMAND)
        #   → read 처럼 입력을 기다리는 명령이 끝 표시를 입력으로 먹어버리는 일이 없음
        self._write("[ -f ~/.bashrc ] && . ~/.bashrc >/dev/null 2>&1; PS1=''; PS2=''; "
                    "PROMPT_COMMAND='__r=$?; printf \"\\n\\036BELUGA_DONE %s %d %s\\037\" \"${__bseq:-0}\" \"$__r\" \"$PWD\"'; "
                    "alias ls='ls --color=always' grep='grep --color=always' 2>/dev/null; "
                    "bind 'set enable-bracketed-paste off' 2>/dev/null; stty -echo\n")
        self._seq = 0

    def _write(self, s):
        try:
            os.write(self.fd, s.encode())
        except OSError:
            pass

    def _on_read(self):
        try:
            data = os.read(self.fd, 65536).decode("utf-8", "replace")
        except OSError:
            self._notifier.setEnabled(False)
            return
        if self._cur is None:
            return                                      # 시작할 때 .bashrc가 찍는 것 등은 버림
        self._buf += data
        while self._cur is not None:
            i = self._buf.find(MARK)
            if i < 0:
                # 표시가 두 번에 나눠 올 수 있음 → 끝부분이 표시의 앞부분일 때만 남겨 둠
                #   (항상 남겨 두면 "이름? " 같은 질문이 화면에 안 나와서 입력칸이 안 뜸)
                j = self._buf.rfind("\x1e")
                cut = j if j >= 0 and MARK.startswith(self._buf[j:j + len(MARK)]) else len(self._buf)
                out, self._buf = self._buf[:cut], self._buf[cut:]
                if out:
                    self._cur.add(out)
                return
            m = re.match(re.escape(MARK) + r" (\d+) (-?\d+) (.*?)\x1f", self._buf[i:], re.S)
            if not m:
                return                                  # 표시 뒷부분이 아직 안 옴
            before, after = self._buf[:i], self._buf[i + m.end():]
            if int(m.group(1)) != self._seq:            # 예전 명령(또는 켤 때) 표시 → 버리고 계속 살펴봄
                self._buf = before + after
                continue
            self._cur.add(before)
            code, cwd = int(m.group(2)), m.group(3)
            self._buf = ""
            self._cur.finish(code)
            self._cur = None
            if cwd and cwd != self._cwd:
                self._cwd = cwd
                self.cwdChanged.emit()
            self.busyChanged.emit()

    def _on_tick(self):
        if self._cur is not None:
            self._cur.changed.emit()                    # 걸린 시간 표시 갱신

    # ---- QML ----
    @Property("QVariantList", notify=cardsChanged)
    def cards(self):
        return self._cards

    @Property(str, notify=cwdChanged)
    def cwd(self):
        home = str(Path.home())
        return "~" + self._cwd[len(home):] if self._cwd.startswith(home) else self._cwd

    @Property(bool, notify=busyChanged)
    def busy(self):
        return self._cur is not None

    @Slot(str)
    def run(self, cmd):
        cmd = cmd.strip()
        if not cmd:
            return
        self._remember(cmd)
        if cmd in ("clear", "cls"):
            self._cards = []
            self.cardsChanged.emit()
            return
        if self._cur is not None:                       # 실행 중이면 그 명령의 입력으로 보냄
            self.send(cmd)
            return
        card = Card(cmd, self.cwd)
        self._cards.append(card)
        self.cardsChanged.emit()
        first = os.path.basename(shlex.split(cmd)[0]) if _safe_split(cmd) else ""
        if first in FULLSCREEN or (first in REPL and len(_safe_split(cmd)) == 1):
            for term in (["konsole", "--workdir", self._cwd, "-e", "bash", "-lc", cmd],
                         ["x-terminal-emulator", "-e", "bash", "-lc", cmd]):
                try:
                    os.spawnvp(os.P_NOWAIT, term[0], term)
                    break
                except OSError:
                    continue
            card.external(f"'{first}' 은(는) 전체 화면 프로그램이라 따로 창에서 열었어요.")
            return
        self._cur = card
        self.busyChanged.emit()
        # 명령 전체를 { } 로 묶어서 한 번에 읽게 함 (여러 줄이어도 끝 표시는 한 번, 번호로 이 명령 것인지 확인)
        self._seq += 1
        self._write(f"__bseq={self._seq}; {{ {cmd}\n}}\n")

    @Slot(str)
    def send(self, text):
        """실행 중인 명령에 입력 보내기 (비밀번호 등)"""
        self._write(text + "\n")

    @Slot()
    def interrupt(self):
        self._write("\x03")                             # Ctrl+C

    @Slot(str, result=str)
    def historyPrev(self, current):
        if self._hpos > 0:
            self._hpos -= 1
        return self._history[self._hpos] if self._history else current

    @Slot(str, result=str)
    def historyNext(self, current):
        if self._hpos < len(self._history) - 1:
            self._hpos += 1
            return self._history[self._hpos]
        self._hpos = len(self._history)
        return ""

    @Slot(str, result=str)
    def complete(self, text):
        """Tab: 마지막 단어를 파일/폴더 이름으로 채우기"""
        parts = text.split(" ")
        word = parts[-1]
        base = os.path.expanduser(word)
        d, pre = os.path.split(base)
        d = os.path.join(self._cwd, d) if not os.path.isabs(d) else d
        try:
            hits = sorted(n for n in os.listdir(d or self._cwd) if n.startswith(pre) and (pre.startswith(".") or not n.startswith(".")))
        except OSError:
            return text
        if not hits:
            return text
        common = os.path.commonprefix(hits)
        full = os.path.join(os.path.dirname(word), common) if os.path.dirname(word) else common
        if len(hits) == 1 and os.path.isdir(os.path.join(d or self._cwd, hits[0])):
            full += "/"
        parts[-1] = full
        return " ".join(parts)

    @Slot(str)
    def copy(self, text):
        QGuiApplication.clipboard().setText(text)

    # ---- 기록 ----
    def _hist_path(self):
        return Path(os.environ.get("XDG_STATE_HOME") or Path.home() / ".local/state") / "beluga" / "terminal-history"

    def _load_history(self):
        try:
            return self._hist_path().read_text(encoding="utf-8").splitlines()[-1000:]
        except OSError:
            return []

    def _remember(self, cmd):
        if not self._history or self._history[-1] != cmd:
            self._history.append(cmd)
        self._hpos = len(self._history)
        try:
            p = self._hist_path()
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "a", encoding="utf-8") as f:
                f.write(cmd.replace("\n", " ") + "\n")
        except OSError:
            pass

    def shutdown(self):
        try:
            os.kill(self.pid, signal.SIGHUP)
        except OSError:
            pass


def _safe_split(cmd):
    try:
        return shlex.split(cmd)
    except ValueError:
        return []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", help="켜자마자 실행할 명령")
    ap.add_argument("--workdir", help="시작 폴더")
    args, _ = ap.parse_known_args()
    os.environ.setdefault("QT_QUICK_CONTROLS_STYLE", "Basic")
    app = QGuiApplication(sys.argv)
    app.setApplicationName("beluga-terminal")
    app.setApplicationDisplayName("터미널")
    app.setDesktopFileName("beluga-terminal")
    app.setWindowIcon(QIcon.fromTheme("utilities-terminal"))
    if args.workdir and os.path.isdir(args.workdir):
        os.chdir(args.workdir)
    term = Term()
    if args.workdir and os.path.isdir(args.workdir):
        term._cwd = os.path.abspath(args.workdir)
        term._write(f"cd {shlex.quote(term._cwd)}\n")
    engine = QQmlApplicationEngine()
    engine.rootContext().setContextProperty("term", term)
    engine.load(QUrl.fromLocalFile(str(HERE / "Terminal.qml")))
    if not engine.rootObjects():
        return 1
    if args.run:
        QTimer.singleShot(300, lambda: term.run(args.run))
    app.aboutToQuit.connect(term.shutdown)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
