// Beluga 설정 화면 (왼쪽 메뉴 + 오른쪽 내용)
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

ApplicationWindow {
    id: win
    width: 1040
    height: 720
    visible: true
    title: "Beluga 설정"

    SystemPalette { id: pal }
    readonly property bool light: Math.max(pal.window.r, pal.window.g, pal.window.b) > 0.5
    readonly property color bg: light ? "#f4f6f8" : "#16181c"
    readonly property color panel: light ? "#ffffff" : "#1f2227"
    readonly property color soft: light ? Qt.rgba(0, 0, 0, 0.04) : Qt.rgba(1, 1, 1, 0.05)
    readonly property color textColor: light ? "#1b1d21" : "#e6e9ee"
    readonly property color subColor: light ? "#69707a" : "#9aa1ab"
    readonly property color accent: "#3d63d6"
    color: bg

    property var apps: JSON.parse(beluga.apps())
    property var systemChoices: JSON.parse(beluga.systemChoices())

    // 칸 설명 글자: "앱 · VS Code" 등
    function describe(s) {
        if (!s || !s.action) return "비어 있음"
        var a = s.action
        if (a.type === "app") { for (var i = 0; i < apps.length; i++) if (apps[i].id === a.value || apps[i].id + ".desktop" === a.value) return "앱 · " + apps[i].name; return "앱 · " + a.value }
        if (a.type === "system") { for (var j = 0; j < systemChoices.length; j++) if (systemChoices[j].id === a.value) return "동작 · " + systemChoices[j].name; return "동작 · " + a.value }
        if (a.type === "command") return "명령 · " + a.value
        if (a.type === "open") return "열기 · " + a.value
        return a.type
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        // ---- 왼쪽 메뉴 ----
        Rectangle {
            Layout.fillHeight: true
            Layout.preferredWidth: 220
            color: win.panel
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 14
                spacing: 4
                RowLayout {
                    Layout.bottomMargin: 14
                    spacing: 10
                    Image { source: "file:///usr/share/pixmaps/beluga-start.png"; sourceSize.width: 64; Layout.preferredWidth: 30; Layout.preferredHeight: 30; fillMode: Image.PreserveAspectFit }
                    Text { text: "Beluga 설정"; color: win.textColor; font.pixelSize: 18; font.bold: true }
                }
                Repeater {
                    model: [ { t: "휠", i: "view-pie" }, { t: "폰 덱", i: "smartphone" }, { t: "바탕화면 · 브금", i: "preferences-desktop-wallpaper" },
                             { t: "절전", i: "system-suspend" }, { t: "단축키", i: "preferences-desktop-keyboard-shortcut" }, { t: "정보", i: "help-about" } ]
                    delegate: Rectangle {
                        required property var modelData
                        required property int index
                        Layout.fillWidth: true
                        height: 40
                        radius: 10
                        color: pages.currentIndex === index ? win.accent : (ma.containsMouse ? win.soft : "transparent")
                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: 10
                            spacing: 10
                            Image { source: "image://icon/" + modelData.i; sourceSize.width: 48; Layout.preferredWidth: 20; Layout.preferredHeight: 20 }
                            Text { text: modelData.t; color: pages.currentIndex === index ? "white" : win.textColor; font.pixelSize: 14; Layout.fillWidth: true }
                        }
                        MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; onClicked: pages.currentIndex = index }
                    }
                }
                Item { Layout.fillHeight: true }
            }
        }

        StackLayout {
            id: pages
            currentIndex: startPage          // --page 로 고른 칸부터 (Beluga 설정 왼쪽 메뉴에서 열 때)
            Layout.fillWidth: true
            Layout.fillHeight: true

            // ================= 휠 =================
            Page {
                id: wheelPage
                background: null
                property var cfg: JSON.parse(beluga.wheel())
                property int tab: 0
                function save() { beluga.saveWheel(JSON.stringify(cfg)); cfg = JSON.parse(beluga.wheel()) }
                ScrollView {
                    anchors.fill: parent
                    contentWidth: availableWidth
                    ColumnLayout {
                        width: parent.width
                        anchors.margins: 28
                        x: 28
                        spacing: 16
                        Item { height: 12 }
                        Title { text: "휠" ; sub: "Tab 누른 채로 1~9 를 누르면 그 번호의 휠이 떠요. 칸을 눌러서 바꾸세요." }
                        Flow {
                            Layout.fillWidth: true
                            Layout.rightMargin: 56
                            spacing: 8
                            Repeater {
                                model: 9
                                delegate: Chip {
                                    required property int index
                                    text: "Ctrl+" + (index + 1) + "  " + wheelPage.cfg.tabs[index].name
                                    on: wheelPage.tab === index
                                    onClicked: wheelPage.tab = index
                                }
                            }
                        }
                        RowLayout {
                            spacing: 10
                            Text { text: "이 휠 이름"; color: win.subColor }
                            TextField {
                                id: tabName
                                Layout.preferredWidth: 260
                                text: wheelPage.cfg.tabs[wheelPage.tab].name
                                onEditingFinished: { var d = wheelPage.cfg; d.tabs[wheelPage.tab].name = text; wheelPage.cfg = d; wheelPage.save() }
                            }
                        }
                        GridLayout {
                            Layout.fillWidth: true
                            Layout.rightMargin: 56
                            columns: 2
                            rowSpacing: 10
                            columnSpacing: 10
                            Repeater {
                                model: 8
                                delegate: SlotCard {
                                    required property int index
                                    Layout.fillWidth: true
                                    title: ["위", "오른쪽 위", "오른쪽", "오른쪽 아래", "아래", "왼쪽 아래", "왼쪽", "왼쪽 위"][index]
                                    slotData: wheelPage.cfg.tabs[wheelPage.tab].slots[index]
                                    onEdit: editor.openFor(slotData, false, function(s) {
                                        var d = wheelPage.cfg; d.tabs[wheelPage.tab].slots[index] = s; wheelPage.cfg = d; wheelPage.save()
                                    })
                                }
                            }
                        }
                        Item { height: 20 }
                    }
                }
            }

            // ================= 폰 덱 =================
            Page {
                id: deckPage
                background: null
                property var cfg: JSON.parse(beluga.deck())
                property var info: JSON.parse(beluga.deckInfo())
                property int page: 0
                function save() { beluga.saveDeck(JSON.stringify(cfg)); cfg = JSON.parse(beluga.deck()) }
                function resize(c, r) {
                    var d = cfg; var n = c * r
                    d.cols = c; d.rows = r
                    for (var i = 0; i < d.pages.length; i++) {
                        var b = d.pages[i].buttons || []
                        while (b.length < n) b.push(null)
                        d.pages[i].buttons = b.slice(0, n)
                    }
                    cfg = d; save()
                }
                Timer { interval: 3000; running: pages.currentIndex === 1; repeat: true; onTriggered: deckPage.info = JSON.parse(beluga.deckInfo()) }
                ScrollView {
                    anchors.fill: parent
                    contentWidth: availableWidth
                    ColumnLayout {
                        width: parent.width - 56
                        x: 28
                        spacing: 16
                        Item { height: 12 }
                        Title { text: "폰 덱"; sub: "폰을 스트림덱처럼. 여기서 정한 그대로 폰에 나오고, 폰에서 누르면 이 컴퓨터에서 실행돼요." }

                        // 연결 안내
                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: conn.implicitHeight + 28
                            radius: 14
                            color: win.panel
                            ColumnLayout {
                                id: conn
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 6
                                RowLayout {
                                    Text { text: "연결 코드"; color: win.subColor; font.pixelSize: 13 }
                                    Text { text: deckPage.info.pin; color: win.textColor; font.pixelSize: 26; font.bold: true; font.letterSpacing: 4 }
                                    Item { Layout.fillWidth: true }
                                    Text { text: deckPage.info.running ? "● 덱 서버 켜짐" : "● 덱 서버 꺼짐"; color: deckPage.info.running ? "#3fb950" : "#e5534b" }
                                    Btn { text: "코드 새로 만들기"; onClicked: { beluga.newPin(); deckPage.info = JSON.parse(beluga.deckInfo()) } }
                                }
                                Text {
                                    Layout.fillWidth: true
                                    wrapMode: Text.WordWrap
                                    color: win.textColor
                                    text: "폰 앱 받기: 폰 브라우저에서 " + deckPage.info.ips.map(function(ip) { return "http://" + ip + ":41234" }).join("  또는  ") +
                                          "\n같은 와이파이면 폰 앱이 이 컴퓨터(" + deckPage.info.host + ")를 자동으로 찾아요."
                                }
                            }
                        }

                        RowLayout {
                            spacing: 10
                            Text { text: "배열"; color: win.subColor }
                            SpinBox { id: colsBox; from: 1; to: 10; value: deckPage.cfg.cols; onValueModified: deckPage.resize(value, rowsBox.value) }
                            Text { text: "×"; color: win.textColor; font.pixelSize: 18 }
                            SpinBox { id: rowsBox; from: 1; to: 8; value: deckPage.cfg.rows; onValueModified: deckPage.resize(colsBox.value, value) }
                            Text { text: "(가로 × 세로)"; color: win.subColor }
                            Item { Layout.preferredWidth: 20 }
                            Repeater {
                                model: [[6, 2], [5, 3], [8, 4], [4, 4]]
                                delegate: Chip { required property var modelData; text: modelData[0] + "×" + modelData[1]; on: deckPage.cfg.cols === modelData[0] && deckPage.cfg.rows === modelData[1]; onClicked: deckPage.resize(modelData[0], modelData[1]) }
                            }
                        }
                        RowLayout {
                            spacing: 8
                            Text { text: "페이지"; color: win.subColor }
                            Repeater {
                                model: deckPage.cfg.pages.length
                                delegate: Chip { required property int index; text: deckPage.cfg.pages[index].name; on: deckPage.page === index; onClicked: deckPage.page = index }
                            }
                            Btn { text: "+ 페이지"; onClicked: { var d = deckPage.cfg; var b = []; for (var i = 0; i < d.cols * d.rows; i++) b.push(null); d.pages.push({ name: "페이지 " + (d.pages.length + 1), buttons: b }); deckPage.cfg = d; deckPage.page = d.pages.length - 1; deckPage.save() } }
                            Btn { text: "이 페이지 지우기"; visible: deckPage.cfg.pages.length > 1; onClicked: { var d = deckPage.cfg; d.pages.splice(deckPage.page, 1); deckPage.page = 0; deckPage.cfg = d; deckPage.save() } }
                            TextField {
                                Layout.preferredWidth: 160
                                text: deckPage.cfg.pages[deckPage.page] ? deckPage.cfg.pages[deckPage.page].name : ""
                                onEditingFinished: { var d = deckPage.cfg; d.pages[deckPage.page].name = text; deckPage.cfg = d; deckPage.save() }
                            }
                        }

                        // 폰처럼 보이는 미리보기 (누르면 편집)
                        Rectangle {
                            Layout.alignment: Qt.AlignHCenter
                            readonly property real cell: Math.min(100, (win.width - 360) / deckPage.cfg.cols)
                            implicitWidth: deckPage.cfg.cols * cell + (deckPage.cfg.cols + 1) * 10
                            implicitHeight: deckPage.cfg.rows * cell + (deckPage.cfg.rows + 1) * 10
                            radius: 24
                            color: "#0d0f12"
                            Grid {
                                anchors.centerIn: parent
                                columns: deckPage.cfg.cols
                                spacing: 10
                                Repeater {
                                    model: deckPage.cfg.cols * deckPage.cfg.rows
                                    delegate: Rectangle {
                                        required property int index
                                        readonly property var b: (deckPage.cfg.pages[deckPage.page] || { buttons: [] }).buttons[index] || null
                                        width: parent.parent.cell; height: width
                                        radius: width * 0.18
                                        color: b ? (b.color || "#2d333b") : "#1a1d22"
                                        border.color: bm.containsMouse ? win.accent : "transparent"
                                        border.width: 2
                                        Image {
                                            visible: !!b
                                            anchors.centerIn: parent
                                            anchors.verticalCenterOffset: -parent.height * 0.08
                                            width: parent.width * 0.46; height: width
                                            source: b ? "image://icon/" + (b.image || b.icon || "application-x-executable") : ""
                                            sourceSize.width: 96
                                        }
                                        Text {
                                            visible: !!b
                                            anchors.bottom: parent.bottom; anchors.bottomMargin: parent.height * 0.08
                                            anchors.horizontalCenter: parent.horizontalCenter
                                            width: parent.width - 8
                                            horizontalAlignment: Text.AlignHCenter
                                            elide: Text.ElideRight
                                            text: b ? b.label : ""
                                            color: "white"
                                            font.pixelSize: Math.max(9, parent.width * 0.12)
                                        }
                                        Text { visible: !b; anchors.centerIn: parent; text: "+"; color: "#555b64"; font.pixelSize: parent.width * 0.35 }
                                        MouseArea {
                                            id: bm
                                            anchors.fill: parent
                                            hoverEnabled: true
                                            onClicked: editor.openFor(b, true, function(s) {
                                                var d = deckPage.cfg; d.pages[deckPage.page].buttons[index] = s; deckPage.cfg = d; deckPage.save()
                                            })
                                        }
                                    }
                                }
                            }
                        }
                        Item { height: 20 }
                    }
                }
            }

            // ================= 바탕화면 · 브금 =================
            Page {
                id: deskPage
                background: null
                property var bgm: JSON.parse(beluga.bgm())
                property string wall: "/usr/share/wallpapers/Beluga/contents/images/3840x2160.jpg"
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 28
                    spacing: 16
                    Title { text: "바탕화면 · 브금"; sub: "잔잔하게 움직이는 배경화면과 배경 음악" }
                    Rectangle {
                        Layout.fillWidth: true
                        implicitHeight: wcol.implicitHeight + 28
                        radius: 14
                        color: win.panel
                        ColumnLayout {
                            id: wcol
                            anchors.fill: parent
                            anchors.margins: 14
                            spacing: 10
                            Text { text: "배경화면"; color: win.textColor; font.bold: true; font.pixelSize: 15 }
                            RowLayout {
                                Text { Layout.fillWidth: true; text: deskPage.wall; color: win.subColor; elide: Text.ElideMiddle }
                                Btn { text: "그림/영상 고르기"; onClicked: wallDialog.open() }
                            }
                            CheckBox { id: motion; text: "천천히 움직이기"; checked: true }
                            CheckBox { id: bubbles; text: "물방울 떠오르기"; checked: true }
                            Btn { text: "적용"; primary: true; onClicked: beluga.applyWallpaper(deskPage.wall, motion.checked, bubbles.checked) }
                        }
                    }
                    Rectangle {
                        Layout.fillWidth: true
                        implicitHeight: bcol.implicitHeight + 28
                        radius: 14
                        color: win.panel
                        ColumnLayout {
                            id: bcol
                            anchors.fill: parent
                            anchors.margins: 14
                            spacing: 10
                            RowLayout {
                                Text { text: "브금"; color: win.textColor; font.bold: true; font.pixelSize: 15 }
                                Text { text: deskPage.bgm.playing ? "● 재생 중" : "● 꺼짐"; color: deskPage.bgm.playing ? "#3fb950" : win.subColor }
                            }
                            Switch { id: bgmOn; text: "로그인하면 브금 틀기"; checked: deskPage.bgm.enabled }
                            RowLayout {
                                Text { text: "음량"; color: win.subColor }
                                Slider { id: vol; from: 0; to: 100; stepSize: 1; value: deskPage.bgm.volume; Layout.preferredWidth: 280 }
                                Text { text: Math.round(vol.value); color: win.textColor }
                            }
                            CheckBox { id: builtin; text: "Beluga 기본 곡도 같이"; checked: deskPage.bgm.builtin }
                            RowLayout {
                                Text { text: "내 음악 폴더: " + deskPage.bgm.folder; color: win.subColor; Layout.fillWidth: true }
                                Btn { text: "폴더 열기"; onClicked: beluga.openBgmFolder() }
                            }
                            Btn {
                                text: "저장"; primary: true
                                onClicked: {
                                    var d = deskPage.bgm; d.enabled = bgmOn.checked; d.volume = Math.round(vol.value); d.builtin = builtin.checked
                                    beluga.saveBgm(JSON.stringify(d)); deskPage.bgm = JSON.parse(beluga.bgm())
                                }
                            }
                        }
                    }
                    Item { Layout.fillHeight: true }
                }
                FileDialog {
                    id: wallDialog
                    title: "배경화면 고르기"
                    nameFilters: ["그림/영상 (*.jpg *.jpeg *.png *.webp *.mp4 *.webm *.mkv *.mov)"]
                    onAccepted: deskPage.wall = selectedFile.toString().replace("file://", "")
                }
            }

            // ================= 절전 =================
            Page {
                id: sleepPage
                background: null
                property string sleepNow: beluga.sleepState()
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 28
                    spacing: 16
                    Title { text: "절전"; sub: "Esc + Tab 을 같이 누르면 어디서든 절전 휠이 떠요" }
                    Text { text: "지금: " + sleepPage.sleepNow; color: win.textColor; font.pixelSize: 16 }
                    Flow {
                        Layout.fillWidth: true
                        spacing: 10
                        Repeater {
                            model: [["계속 안 꺼지기", "never"], ["5분 뒤", "5"], ["10분 뒤", "10"], ["30분 뒤", "30"], ["1시간 뒤", "60"], ["지금 절전", "now"], ["원래대로", "reset"]]
                            delegate: Btn { required property var modelData; text: modelData[0]; onClicked: { beluga.sleep(modelData[1]); sleepPage.sleepNow = beluga.sleepState() } }
                        }
                    }
                    Item { Layout.fillHeight: true }
                }
            }

            // ================= 단축키 =================
            Page {
                background: null
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 28
                    spacing: 10
                    Title { text: "단축키"; sub: "Beluga에서 쓰는 단축키" }
                    Repeater {
                        model: [["윈도우 키 / 왼쪽 위 로고", "가운데 검색창"], ["Ctrl + 1 ~ 9", "휠 1~9"], ["Esc + Tab (동시에)", "절전 휠"],
                                ["Ctrl + Shift + Backspace", "프로세스 종료 창 (누르면 바로 종료)"], ["Ctrl + Shift + Esc", "작업 관리자"],
                                ["Ctrl + Alt + T", "터미널"], ["한/영", "한국어 ↔ 영어"]]
                        delegate: Rectangle {
                            required property var modelData
                            Layout.fillWidth: true
                            height: 44
                            radius: 10
                            color: win.panel
                            RowLayout {
                                anchors.fill: parent; anchors.margins: 12
                                Text { text: modelData[0]; color: win.textColor; font.bold: true; Layout.preferredWidth: 280 }
                                Text { text: modelData[1]; color: win.subColor; Layout.fillWidth: true }
                            }
                        }
                    }
                    Btn { text: "단축키 바꾸기 (시스템 설정)"; onClicked: beluga.run("systemsettings kcm_keys") }
                    Item { Layout.fillHeight: true }
                }
            }

            // ================= 정보 =================
            Page {
                background: null
                ColumnLayout {
                    anchors.centerIn: parent
                    spacing: 12
                    Image { Layout.alignment: Qt.AlignHCenter; source: "file:///usr/share/pixmaps/beluga-start.png"; sourceSize.width: 256; Layout.preferredWidth: 110; Layout.preferredHeight: 110; fillMode: Image.PreserveAspectFit }
                    Text { Layout.alignment: Qt.AlignHCenter; text: "Beluga OS"; color: win.textColor; font.pixelSize: 28; font.bold: true }
                    Text { Layout.alignment: Qt.AlignHCenter; text: "버전 " + beluga.version(); color: win.subColor }
                    Btn { Layout.alignment: Qt.AlignHCenter; text: "업데이트 확인"; onClicked: beluga.run("plasma-discover --mode update") }
                }
            }
        }
    }

    // ================= 칸 편집 창 (휠/덱 같이 씀) =================
    Dialog {
        id: editor
        modal: true
        anchors.centerIn: parent
        width: 560
        title: "칸 바꾸기"
        property bool deck: false
        property var done: null
        property string kind: "app"
        function openFor(s, isDeck, cb) {
            deck = isDeck; done = cb
            var a = (s && s.action) || { type: "app", value: "" }
            kind = s ? a.type : "app"
            label.text = s ? (s.label || "") : ""
            iconName.text = s ? (s.icon || "") : ""
            imagePath.text = s ? (s.image || "") : ""
            colorField.text = s ? (s.color || "#2d333b") : "#2d333b"
            valueField.text = (a.type === "command" || a.type === "open") ? a.value : ""
            appBox.currentIndex = -1
            for (var i = 0; i < apps.length; i++) if (apps[i].id === a.value) appBox.currentIndex = i
            sysBox.currentIndex = 0
            for (var j = 0; j < systemChoices.length; j++) if (systemChoices[j].id === a.value) sysBox.currentIndex = j
            open()
        }
        function makeSlot() {
            if (kind === "none") return null
            var v = kind === "app" ? (appBox.currentIndex >= 0 ? apps[appBox.currentIndex].id : "")
                  : kind === "system" ? systemChoices[sysBox.currentIndex].id : valueField.text
            var lbl = label.text || (kind === "app" && appBox.currentIndex >= 0 ? apps[appBox.currentIndex].name
                                   : kind === "system" ? systemChoices[sysBox.currentIndex].name : v)
            var s = { label: lbl, action: { type: kind, value: v } }
            if (iconName.text) s.icon = iconName.text
            if (deck) { s.color = colorField.text; if (imagePath.text) s.image = imagePath.text }
            return s
        }
        contentItem: ColumnLayout {
            spacing: 10
            RowLayout {
                spacing: 6
                Repeater {
                    model: [["app", "앱"], ["command", "명령"], ["open", "열기"], ["system", "동작"], ["none", "비우기"]]
                    delegate: Chip { required property var modelData; text: modelData[1]; on: editor.kind === modelData[0]; onClicked: editor.kind = modelData[0] }
                }
            }
            ComboBox {
                id: appBox
                visible: editor.kind === "app"
                Layout.fillWidth: true
                model: apps
                textRole: "name"
                displayText: currentIndex >= 0 ? apps[currentIndex].name : "앱 고르기"
            }
            ComboBox { id: sysBox; visible: editor.kind === "system"; Layout.fillWidth: true; model: systemChoices; textRole: "name" }
            TextField {
                id: valueField
                visible: editor.kind === "command" || editor.kind === "open"
                Layout.fillWidth: true
                placeholderText: editor.kind === "command" ? "예: docker compose up -d" : "예: ~/프로젝트 또는 https://github.com"
            }
            TextField { id: label; visible: editor.kind !== "none"; Layout.fillWidth: true; placeholderText: "보일 이름 (비우면 자동)" }
            TextField { id: iconName; visible: editor.kind !== "none"; Layout.fillWidth: true; placeholderText: "아이콘 이름 (비우면 앱 아이콘, 예: media-record)" }
            RowLayout {
                visible: editor.deck && editor.kind !== "none"
                TextField { id: imagePath; Layout.fillWidth: true; placeholderText: "버튼 그림 파일 (선택)" }
                Btn { text: "고르기"; onClicked: imgDialog.open() }
            }
            RowLayout {
                visible: editor.deck && editor.kind !== "none"
                spacing: 6
                Text { text: "색"; color: win.subColor }
                Repeater {
                    model: ["#2d333b", "#3a3f47", "#21398a", "#1f6feb", "#238636", "#b62324", "#c15f3c", "#8957e5", "#bf8700", "#0d0f12"]
                    delegate: Rectangle {
                        required property var modelData
                        width: 26; height: 26; radius: 7; color: modelData
                        border.color: colorField.text === modelData ? win.accent : "transparent"; border.width: 3
                        MouseArea { anchors.fill: parent; onClicked: colorField.text = parent.modelData }
                    }
                }
                TextField { id: colorField; Layout.preferredWidth: 90 }
            }
            RowLayout {
                Layout.topMargin: 6
                Btn { text: "시험해 보기"; visible: editor.kind !== "none"; onClicked: { var s = editor.makeSlot(); if (s) beluga.tryAction(JSON.stringify(s.action)) } }
                Item { Layout.fillWidth: true }
                Btn { text: "취소"; onClicked: editor.close() }
                Btn { text: "저장"; primary: true; onClicked: { var cb = editor.done; var s = editor.makeSlot(); editor.close(); if (cb) cb(s) } }
            }
        }
        FileDialog { id: imgDialog; nameFilters: ["그림 (*.png *.jpg *.jpeg *.svg *.webp)"]; onAccepted: imagePath.text = selectedFile.toString().replace("file://", "") }
    }

    // ---- 작은 부품들 ----
    component Title: ColumnLayout {
        property alias text: t.text
        property alias sub: s.text
        spacing: 4
        Text { id: t; color: win.textColor; font.pixelSize: 24; font.bold: true }
        Text { id: s; color: win.subColor; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }
    }
    component Btn: Rectangle {
        property alias text: bl.text
        property bool primary: false
        signal clicked()
        implicitWidth: bl.implicitWidth + 24
        implicitHeight: 34
        radius: 9
        color: primary ? (bma.containsMouse ? "#5277e0" : win.accent) : (bma.containsMouse ? Qt.rgba(0.5, 0.5, 0.5, 0.22) : win.soft)
        Text { id: bl; anchors.centerIn: parent; color: parent.primary ? "white" : win.textColor; font.pixelSize: 13 }
        MouseArea { id: bma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: parent.clicked() }
    }
    component Chip: Rectangle {
        property alias text: cl.text
        property bool on: false
        signal clicked()
        implicitWidth: cl.implicitWidth + 22
        implicitHeight: 32
        radius: 16
        color: on ? win.accent : (cma.containsMouse ? Qt.rgba(0.5, 0.5, 0.5, 0.22) : win.soft)
        Text { id: cl; anchors.centerIn: parent; color: parent.on ? "white" : win.textColor; font.pixelSize: 13 }
        MouseArea { id: cma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: parent.clicked() }
    }
    component SlotCard: Rectangle {
        property string title
        property var slotData
        signal edit()
        implicitHeight: 64
        radius: 12
        color: sma.containsMouse ? Qt.rgba(0.24, 0.39, 0.84, 0.12) : win.panel
        RowLayout {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 12
            Rectangle {
                Layout.preferredWidth: 40; Layout.preferredHeight: 40; radius: 20; color: win.soft
                Image { anchors.centerIn: parent; visible: !!slotData; width: 24; height: 24; source: slotData ? "image://icon/" + (slotData.icon || "application-x-executable") : ""; sourceSize.width: 48 }
                Text { anchors.centerIn: parent; visible: !slotData; text: "+"; color: win.subColor; font.pixelSize: 20 }
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Text { text: title + (slotData ? " · " + slotData.label : ""); color: win.textColor; font.bold: true; elide: Text.ElideRight; Layout.fillWidth: true }
                Text { text: win.describe(slotData); color: win.subColor; font.pixelSize: 12; elide: Text.ElideRight; Layout.fillWidth: true }
            }
        }
        MouseArea { id: sma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: parent.edit() }
    }
}
