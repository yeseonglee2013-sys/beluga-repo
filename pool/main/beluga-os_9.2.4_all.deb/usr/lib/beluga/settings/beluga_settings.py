#!/usr/bin/python3
"""Beluga 설정 (2026-11-05): 휠 · 폰 덱 · 바탕화면/브금 · 절전 · 단축키 · 정보

QML 화면과 주고받는 값은 JSON 글자로 (복잡한 목록도 안전하게)
"""
import hashlib
import json
import os
import socket
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, "/usr/lib/beluga/shell")

from PySide6.QtCore import QObject, QUrl, Slot
from PySide6.QtGui import QGuiApplication, QIcon, QPixmap, QImage, Qt
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuick import QQuickImageProvider

import actions          # noqa: E402
import config           # noqa: E402
import desktopfiles     # noqa: E402

HERE = Path(__file__).resolve().parent
CFG = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "beluga"
DECK = CFG / "deck.json"
BGM = CFG / "bgm.json"
ICONS = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache") / "beluga" / "deck-icons"

SYSTEM_CHOICES = [
    ("lock", "화면 잠금"), ("screenshot", "스크린샷"), ("record", "화면 녹화"), ("search", "검색창"),
    ("terminal", "터미널"), ("settings", "Beluga 설정"), ("taskmgr", "작업 관리자"), ("killer", "프로세스 종료 창"),
    ("files", "파일"), ("bgm", "브금 켜기/끄기"), ("mute", "음소거"), ("volup", "소리 크게"), ("voldown", "소리 작게"),
    ("suspend", "절전"), ("reboot", "재부팅"), ("shutdown", "전원 끄기"), ("logout", "로그아웃"),
]


class IconProvider(QQuickImageProvider):
    def __init__(self):
        super().__init__(QQuickImageProvider.Pixmap)

    def requestPixmap(self, name, size, requested):
        s = max(requested.width(), requested.height(), 64)
        icon = QIcon(name) if name.startswith("/") else QIcon.fromTheme(name)
        if icon.isNull():
            icon = QIcon.fromTheme("application-x-executable")
        pm = icon.pixmap(s, s)
        if pm.isNull():                      # 아이콘 테마에 없으면 빈 칸 (오류 대신)
            pm = QPixmap(s, s)
            pm.fill(Qt.transparent)
        return pm


def _write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _sh(*argv):
    return subprocess.run(argv, capture_output=True, text=True)


class Settings(QObject):
    # ---- 휠 ----
    @Slot(result=str)
    def wheel(self):
        return json.dumps(config.load(), ensure_ascii=False)

    @Slot(str)
    def saveWheel(self, text):
        config.save(json.loads(text))            # Beluga 셸이 파일 바뀐 걸 보고 바로 다시 읽음

    @Slot(result=str)
    def apps(self):
        """앱 고르기 목록: 설치된 앱 (이름순)"""
        out, seen = [], set()
        for d in desktopfiles._app_dirs():
            for p in sorted(d.glob("*.desktop")):
                if p.stem in seen:
                    continue
                e = desktopfiles._read(p)
                if not e or e.get("NoDisplay", "false") == "true" or e.get("Hidden", "false") == "true" \
                        or e.get("Type", "Application") != "Application":
                    continue
                seen.add(p.stem)
                out.append({"id": p.stem, "name": desktopfiles.display_name(e) or p.stem, "icon": e.get("Icon", "")})
        out.sort(key=lambda a: a["name"].lower())
        return json.dumps(out, ensure_ascii=False)

    @Slot(result=str)
    def systemChoices(self):
        return json.dumps([{"id": k, "name": n} for k, n in SYSTEM_CHOICES], ensure_ascii=False)

    @Slot(str, result=str)
    def appIcon(self, app_id):
        return config._app_icon({"type": "app", "value": app_id})

    @Slot(str)
    def tryAction(self, text):
        actions.run(json.loads(text))

    # ---- 폰 덱 ----
    @Slot(result=str)
    def deck(self):
        for f in (DECK, Path("/usr/share/beluga/deck-default.json")):
            try:
                return f.read_text(encoding="utf-8")
            except OSError:
                continue
        return json.dumps({"cols": 5, "rows": 3, "pages": [{"name": "페이지 1", "buttons": []}]})

    @Slot(str)
    def saveDeck(self, text):
        d = json.loads(text)
        ICONS.mkdir(parents=True, exist_ok=True)
        for pg in d.get("pages", []):
            for b in pg.get("buttons", []):
                if not b:
                    continue
                if not b.get("icon") and not b.get("image"):
                    b["icon"] = config._app_icon(b.get("action") or {})
                b["iconFile"] = self._render_icon(b.get("image") or b.get("icon") or "")
        _write_json(DECK, d)                     # 덱 서버가 보고 폰에 바로 보냄

    def _render_icon(self, src):
        """폰에 보낼 버튼 그림 PNG 만들기 (아이콘 이름 또는 그림 파일)"""
        if not src:
            return ""
        name = hashlib.sha1(src.encode()).hexdigest()[:16] + ".png"
        out = ICONS / name
        if src.startswith("/") and Path(src).is_file():
            img = QImage(src)
            if not img.isNull():
                img.scaled(256, 256, Qt.KeepAspectRatio, Qt.SmoothTransformation).save(str(out), "PNG")
                return name
        icon = QIcon.fromTheme(src)
        if icon.isNull():
            return ""
        icon.pixmap(192, 192).save(str(out), "PNG")
        return name

    @Slot(result=str)
    def deckInfo(self):
        try:
            code = (CFG / "deck-pin").read_text().strip()
        except OSError:
            code = "(덱 서버가 처음 켜지면 생김)"
        ips = [a for a in _sh("hostname", "-I").stdout.split() if ":" not in a]
        running = _sh("systemctl", "--user", "is-active", "beluga-deck.service").stdout.strip() == "active"
        return json.dumps({"pin": code, "ips": ips, "host": socket.gethostname(), "running": running}, ensure_ascii=False)

    @Slot()
    def newPin(self):
        try:
            (CFG / "deck-pin").unlink()
        except OSError:
            pass
        _sh("systemctl", "--user", "restart", "beluga-deck.service")

    # ---- 바탕화면 / 브금 ----
    @Slot(result=str)
    def bgm(self):
        d = {"enabled": False, "volume": 20, "folder": "~/음악/Beluga 브금", "builtin": True}   # 기본값 = 브금 끔
        try:
            d.update(json.loads(BGM.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            pass
        d["playing"] = _sh("systemctl", "--user", "is-active", "beluga-bgm.service").stdout.strip() == "active"
        return json.dumps(d, ensure_ascii=False)

    @Slot(str)
    def saveBgm(self, text):
        d = json.loads(text)
        d.pop("playing", None)
        _write_json(BGM, d)
        _sh("systemctl", "--user", "restart" if d.get("enabled") else "stop", "beluga-bgm.service")

    @Slot()
    def openBgmFolder(self):
        try:
            folder = json.loads(self.bgm()).get("folder", "~/음악/Beluga 브금")
        except ValueError:
            folder = "~/음악/Beluga 브금"
        p = Path(os.path.expanduser(folder))
        p.mkdir(parents=True, exist_ok=True)
        actions.run({"type": "open", "value": str(p)})

    @Slot(str, bool, bool)
    def applyWallpaper(self, src, motion, bubbles):
        """모든 화면의 배경을 Beluga 움직이는 배경으로 + 고른 그림/영상"""
        if src and not src.startswith("file://"):
            src = "file://" + src
        js = ("desktops().forEach(function(d){d.wallpaperPlugin='org.beluga.live';"
              "d.currentConfigGroup=['Wallpaper','org.beluga.live','General'];"
              f"d.writeConfig('Source',{json.dumps(src)});"
              f"d.writeConfig('Motion',{'true' if motion else 'false'});"
              f"d.writeConfig('Bubbles',{'true' if bubbles else 'false'});}});")
        for q in ("qdbus6", "qdbus"):
            r = subprocess.run([q, "org.kde.plasmashell", "/PlasmaShell", "org.kde.PlasmaShell.evaluateScript", js],
                               capture_output=True)
            if r.returncode == 0:
                break

    # ---- 시작 영상 (로그인할 때 벨루가 영상) ----
    @Slot(result=bool)
    def introOn(self):
        return not (CFG / "intro-off").exists()

    @Slot(bool)
    def setIntro(self, on):
        f = CFG / "intro-off"
        if on:
            f.unlink(missing_ok=True)
        else:
            CFG.mkdir(parents=True, exist_ok=True)
            f.touch()

    # ---- 절전 ----
    @Slot(result=str)
    def sleepState(self):
        return actions.sleep_state()

    @Slot(str)
    def sleep(self, v):
        actions.sleep_action(v)

    # ---- 기타 ----
    @Slot(result=str)
    def version(self):
        try:
            for line in Path("/etc/os-release").read_text().splitlines():
                if line.startswith("VERSION="):
                    return line.split("=", 1)[1].strip('"')
        except OSError:
            pass
        return ""

    @Slot(str)
    def run(self, cmd):
        subprocess.Popen(["bash", "-lc", cmd], start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main():
    os.environ.setdefault("QT_QUICK_CONTROLS_STYLE", "Basic")
    app = QGuiApplication(sys.argv)
    app.setApplicationName("beluga-settings")
    app.setApplicationDisplayName("Beluga 설정")
    app.setDesktopFileName("beluga-settings")
    app.setWindowIcon(QIcon.fromTheme("preferences-system"))
    s = Settings()
    # beluga-settings --page wheel|deck|desktop|sleep|keys|about : 그 칸을 바로 열기 (Beluga 설정(시스템 설정) 왼쪽 메뉴에서 부름)
    pages = ["wheel", "deck", "desktop", "sleep", "keys", "about"]
    start = 0
    if "--page" in sys.argv:
        i = sys.argv.index("--page")
        if i + 1 < len(sys.argv) and sys.argv[i + 1] in pages:
            start = pages.index(sys.argv[i + 1])
    engine = QQmlApplicationEngine()
    engine.addImageProvider("icon", IconProvider())
    engine.rootContext().setContextProperty("beluga", s)
    engine.rootContext().setContextProperty("startPage", start)
    engine.load(QUrl.fromLocalFile(str(HERE / "Settings.qml")))
    if not engine.rootObjects():
        return 1
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
