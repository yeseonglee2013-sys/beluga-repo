# Plasma(Wayland)에서는 한글 입력기를 KWin이 직접 연결하므로 옛날 방식 변수는 끔 (fcitx "Wayland Diagnose" 경고 방지)
# X11 프로그램(XWayland)용 XMODIFIERS는 남김
unset GTK_IM_MODULE QT_IM_MODULE
export XMODIFIERS=@im=fcitx
