// Beluga OS 기본 화면 배치: 맥처럼 화면 아래 가운데에 떠 있는 반투명 유리 독
// (KDE 기본 배치 파일 org.debian.desktop 레이아웃을 이걸로 바꿈 → 새 사용자마다 적용)
var panel = new Panel;
panel.location = "bottom";
panel.height = 2 * Math.floor(gridUnit * 2.9 / 2);   // 아이콘이 시원하게 보이는 높이
panel.floating = true;                                 // 화면 가장자리에서 살짝 떠 있음 + 둥근 모서리
panel.lengthMode = "fit";                              // 폭 = 아이콘 개수만큼 (맥 독처럼)
panel.alignment = "center";
panel.opacity = "translucent";                         // 뒤가 흐릿하게 비치는 유리 효과
panel.hiding = "none";

var start = panel.addWidget("org.kde.plasma.kickoff");
start.currentConfigGroup = ["General"];
start.writeConfig("icon", "/usr/share/pixmaps/beluga-start.png");

var tasks = panel.addWidget("org.kde.plasma.icontasks");
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers", [
    "applications:org.kde.dolphin.desktop",
    "applications:firefox.desktop",
    "applications:google-chrome.desktop",
    "applications:com.anthropic.Claude.desktop",
    "applications:org.vinegarhq.Sober.desktop",
    "applications:org.vinegarhq.Vinegar.desktop",
    "applications:org.kde.discover.desktop",
    "applications:org.kde.konsole.desktop"
].join(","));
tasks.writeConfig("iconSpacing", "2");

panel.addWidget("org.kde.plasma.marginsseparator");
panel.addWidget("org.kde.plasma.kimpanel");            // 한/영 입력기 표시
panel.addWidget("org.kde.plasma.systemtray");
var clock = panel.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", "true");
clock.writeConfig("dateDisplayFormat", "BelowTime");

// 배경화면 = 벨루가
var desktopsArray = desktopsForActivity(currentActivity());
for (var j = 0; j < desktopsArray.length; j++) {
    desktopsArray[j].wallpaperPlugin = "org.kde.image";
    desktopsArray[j].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    desktopsArray[j].writeConfig("Image", "file:///usr/share/wallpapers/Beluga");
}
