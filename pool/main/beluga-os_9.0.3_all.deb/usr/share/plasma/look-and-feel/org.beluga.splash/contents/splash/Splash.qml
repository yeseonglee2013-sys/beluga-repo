// Beluga OS 로그인 직후 로딩 화면: 부팅 화면과 똑같이 (남색 배경 + 로고 + 빙글빙글 점 8개)
import QtQuick 2.15

Rectangle {
    id: root
    color: "#21398a"
    property int stage    // KSplash가 단계마다 올려줌 (끝나면 알아서 닫힘)

    Image {
        id: logo
        source: "images/logo.png"
        height: root.height * 0.22
        fillMode: Image.PreserveAspectFit
        smooth: true
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.height * 0.40 - height / 2
    }

    Item {
        id: spinner
        property int head: 0
        width: root.height * 0.052; height: width
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.height * 0.72 - height / 2
        Repeater {
            model: 8
            Image {
                source: "images/dot.png"
                width: Math.max(4, root.height * 0.0105); height: width
                smooth: true
                property real a: index * 2 * Math.PI / 8
                x: spinner.width / 2 + Math.sin(a) * spinner.width / 2 - width / 2
                y: spinner.height / 2 - Math.cos(a) * spinner.height / 2 - height / 2
                opacity: Math.max(0.12, 1.0 - ((spinner.head - index + 8) % 8) * 0.16)
            }
        }
        Timer { interval: 90; running: true; repeat: true; onTriggered: spinner.head = (spinner.head + 1) % 8 }
    }
}
