// Beluga OS 잠금 화면 (2026-11-06) — 로그인 화면(sddm/themes/beluga/Main.qml)과 같은 모양, 디자인 규칙 A
//  KDE 원본(LockScreenUi.qml)은 dpkg-divert로 비켜 두고 이 파일이 진입점이 됨.
//  kscreenlocker_greet 가 주는 것: authenticator(startAuthenticating/respond/succeeded/failed/promptForSecret),
//  kscreenlocker_userName / kscreenlocker_userImage, 그리고 아래 "magical" 속성·신호 (없으면 기본 잠금 화면으로 되돌아감)
import QtQuick
import QtQuick.Controls
import QtQuick.Effects

Item {
    id: root
    // ---- kscreenlocker 가 찾는 속성·신호 (지우면 안 됨) ----
    property bool debug: false
    property string notification
    signal clearPassword()
    signal notificationRepeated()
    property bool viewVisible: false
    property bool suspendToRamSupported: false
    property bool suspendToDiskSupported: false
    signal suspendToDisk()
    signal suspendToRam()

    implicitWidth: 800
    implicitHeight: 600

    readonly property color accent: "#185FA5"
    readonly property string fontName: "Pretendard Variable"
    readonly property string userName: (typeof kscreenlocker_userName !== "undefined") ? kscreenlocker_userName : ""
    readonly property string faceIcon: (typeof kscreenlocker_userImage !== "undefined" && kscreenlocker_userImage !== "")
                                       ? "file://" + kscreenlocker_userImage.split("/").map(encodeURIComponent).join("/") : ""
    property bool busy: false
    property bool pending: false   // 확인 준비가 되기 전에 Enter를 누른 경우

    onClearPassword: { pw.text = ""; pw.forceActiveFocus() }

    function submit() {
        if (busy) return
        err.text = ""
        busy = true
        if (authenticator.promptForSecret) {
            authenticator.respond(pw.text)
        } else {
            pending = true
            authenticator.startAuthenticating()
        }
    }

    Connections {
        target: authenticator
        function onPromptForSecretChanged() {
            if (authenticator.promptForSecret && root.pending) {
                root.pending = false
                authenticator.respond(pw.text)
            }
        }
        function onFailed(kind) {
            if (kind !== 0) return   // 지문·스마트카드 같은 다른 방법의 실패는 무시
            root.busy = false
            root.pending = false
            pw.text = ""
            err.text = "비밀번호가 맞지 않아요. 다시 입력해 주세요."
            shake.restart()
            retry.restart()
        }
        function onSucceeded() { Qt.quit() }
    }
    // 틀리면 잠깐 쉬었다가 다시 받을 준비 (KDE 원본과 같은 3초)
    Timer { id: retry; interval: 3000; onTriggered: { authenticator.startAuthenticating(); pw.forceActiveFocus() } }

    // ---- 배경: 벨루가 그림 + 살짝 흐리고 어둡게 (로그인 화면과 같음) ----
    Rectangle { anchors.fill: parent; color: "#16181C" }
    Image {
        id: bg
        anchors.fill: parent
        source: "file:///usr/share/wallpapers/Beluga/contents/images/2560x1440.jpg"
        fillMode: Image.PreserveAspectCrop
        visible: false
    }
    MultiEffect {
        anchors.fill: bg
        source: bg
        blurEnabled: true
        blur: 0.5
        blurMax: 48
        brightness: -0.1
    }
    Rectangle { anchors.fill: parent; color: "#000000"; opacity: 0.18 }

    // 아무 키나 누르거나 움직이면 바로 비밀번호 칸으로
    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        onPressed: pw.forceActiveFocus()
    }

    // ---- 시계 ----
    Column {
        id: clock
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.16
        spacing: 4
        Text {
            id: timeT
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#FFFFFF"
            font.family: root.fontName
            font.pixelSize: Math.round(root.height * 0.1)
            font.weight: Font.DemiBold
            text: Qt.formatTime(new Date(), "HH:mm")
        }
        Text {
            id: dateT
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#E8EAED"
            font.family: root.fontName
            font.pixelSize: 20
            text: Qt.locale("ko_KR").toString(new Date(), "M월 d일 dddd")
        }
        Timer {
            interval: 1000
            repeat: true
            running: true
            onTriggered: {
                timeT.text = Qt.formatTime(new Date(), "HH:mm")
                dateT.text = Qt.locale("ko_KR").toString(new Date(), "M월 d일 dddd")
            }
        }
    }

    // ---- 잠금 해제 카드 ----
    Rectangle {
        id: card
        width: 360
        height: col.implicitHeight + 48
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: clock.bottom
        anchors.topMargin: root.height * 0.07
        radius: 8
        color: Qt.rgba(0.086, 0.094, 0.11, 0.72)
        border.color: Qt.rgba(1, 1, 1, 0.08)
        border.width: 1
        transform: Translate { id: shakeX; x: 0 }
        SequentialAnimation {
            id: shake
            loops: 2
            NumberAnimation { target: shakeX; property: "x"; to: -8; duration: 40 }
            NumberAnimation { target: shakeX; property: "x"; to: 8; duration: 60 }
            NumberAnimation { target: shakeX; property: "x"; to: 0; duration: 40 }
        }

        Column {
            id: col
            anchors.centerIn: parent
            width: parent.width - 48
            spacing: 12

            // 사진 (동그라미)
            Item {
                width: 80
                height: 80
                anchors.horizontalCenter: parent.horizontalCenter
                Image {
                    id: face
                    anchors.fill: parent
                    source: root.faceIcon !== "" ? root.faceIcon : "file:///usr/share/sddm/faces/.face.icon"
                    onStatusChanged: if (status === Image.Error) source = "file:///usr/share/sddm/faces/.face.icon"
                    fillMode: Image.PreserveAspectCrop
                    sourceSize: Qt.size(160, 160)
                    visible: false
                }
                Rectangle { id: faceMask; anchors.fill: parent; radius: width / 2; visible: false; layer.enabled: true }
                MultiEffect {
                    anchors.fill: parent
                    source: face
                    maskEnabled: true
                    maskSource: faceMask
                }
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: root.userName
                color: "#FFFFFF"
                font.family: root.fontName
                font.pixelSize: 20
                font.weight: Font.DemiBold
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: "잠겨 있어요"
                color: "#9AA0AA"
                font.family: root.fontName
                font.pixelSize: 13
            }
            // 비밀번호 + 풀기
            Row {
                width: parent.width
                spacing: 8
                TextField {
                    id: pw
                    width: parent.width - go.width - 8
                    height: 40
                    echoMode: TextInput.Password
                    passwordCharacter: "●"
                    placeholderText: "비밀번호"
                    placeholderTextColor: "#9AA0AA"
                    color: "#FFFFFF"
                    font.family: root.fontName
                    font.pixelSize: 15
                    leftPadding: 12
                    focus: true
                    enabled: !root.busy && !retry.running
                    background: Rectangle {
                        radius: 4
                        color: Qt.rgba(1, 1, 1, 0.08)
                        border.width: 1
                        border.color: pw.activeFocus ? root.accent : Qt.rgba(1, 1, 1, 0.14)
                    }
                    Keys.onReturnPressed: root.submit()
                    Keys.onEnterPressed: root.submit()
                    onTextChanged: if (text !== "") err.text = ""
                }
                Rectangle {
                    id: go
                    width: 40
                    height: 40
                    radius: 4
                    color: goMouse.pressed ? Qt.darker(root.accent, 1.15) : (goMouse.containsMouse ? Qt.lighter(root.accent, 1.12) : root.accent)
                    Text {
                        anchors.centerIn: parent
                        text: root.busy ? "…" : "→"
                        color: "#FFFFFF"
                        font.pixelSize: 18
                        font.family: root.fontName
                    }
                    MouseArea {
                        id: goMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.submit()
                    }
                }
            }
            Text {
                id: err
                width: parent.width
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                color: "#FF8A89"
                font.family: root.fontName
                font.pixelSize: 13
                visible: text !== ""
            }
        }
    }

    // ---- 아래 오른쪽: 절전 ----
    Row {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 24
        spacing: 8
        SmallBtn { label: "절전"; visible: root.suspendToRamSupported; onClicked: root.suspendToRam() }
    }

    Component.onCompleted: {
        authenticator.startAuthenticating()
        pw.forceActiveFocus()
    }

    // 작은 글자 버튼 (반투명 칸, 모서리 4) — 로그인 화면과 같음
    component SmallBtn: Rectangle {
        id: sb
        property string label: ""
        signal clicked()
        width: Math.max(40, t.implicitWidth + 24)
        height: 32
        radius: 4
        color: m.pressed ? Qt.rgba(1, 1, 1, 0.18) : (m.containsMouse ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(1, 1, 1, 0.08))
        Text {
            id: t
            anchors.centerIn: parent
            text: sb.label
            color: "#E8EAED"
            font.family: root.fontName
            font.pixelSize: 13
        }
        MouseArea {
            id: m
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sb.clicked()
        }
    }
}
