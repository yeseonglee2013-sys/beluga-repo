"""휠 칸 / 폰 덱 버튼이 하는 일 (둘이 같은 동작 종류를 씀)

action = {"type": ..., "value": ...}
  app      value = 앱 이름(.desktop 파일 이름, 예: "code" 또는 "code.desktop")
  command  value = 셸 명령 (bash -lc 로 실행)
  open     value = 폴더 / 파일 / 웹 주소
  system   value = lock | screenshot | record | search | terminal | settings | taskmgr | killer | files
                   | suspend | reboot | shutdown | logout | mute | volup | voldown | bgm(브금 켜기/끄기)
  sleep    value = never | 5 | 10 | 30 | 60 | now | reset   (절전 휠)
"""
import os
import shlex
import shutil
import subprocess
from pathlib import Path

from desktopfiles import find_desktop, exec_argv


def _spawn(argv):
    # 이 프로그램과 따로 살게 (Beluga 셸이 다시 켜져도 실행한 앱은 안 꺼짐)
    subprocess.Popen(argv, start_new_session=True, stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _have(cmd):
    return shutil.which(cmd) is not None


SYSTEM = {
    "lock":       ["loginctl", "lock-session"],
    "screenshot": ["spectacle"],
    "record":     ["spectacle", "--record", "s"],
    "search":     ["beluga-ctl", "search"],
    "terminal":   ["beluga-terminal"],
    "settings":   ["systemsettings"],            # Beluga 설정 (= KDE 시스템 설정을 Beluga 것으로)
    "taskmgr":    ["plasma-systemmonitor"],
    "files":      ["dolphin"],
    "suspend":    ["systemctl", "suspend"],
    "reboot":     ["qdbus6", "org.kde.LogoutPrompt", "/LogoutPrompt", "promptReboot"],
    "shutdown":   ["qdbus6", "org.kde.LogoutPrompt", "/LogoutPrompt", "promptShutDown"],
    "logout":     ["qdbus6", "org.kde.LogoutPrompt", "/LogoutPrompt", "promptLogout"],
    "mute":       ["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"],
    "volup":      ["wpctl", "set-volume", "-l", "1.5", "@DEFAULT_AUDIO_SINK@", "5%+"],
    "voldown":    ["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", "5%-"],
}


def run(action, shell=None):
    """동작 실행. shell = Beluga 셸 (프로세스 종료 창, 절전처럼 셸 안에서 하는 동작용)"""
    if not action:
        return
    t = action.get("type")
    v = str(action.get("value", "")).strip()
    if t == "app":
        path = find_desktop(v)
        argv = exec_argv(path) if path else None
        if argv:
            _spawn(argv)
        elif v:
            _spawn(shlex.split(v))              # .desktop이 없으면 명령 이름으로 보고 실행
    elif t == "command":
        if v:
            _spawn(["bash", "-lc", v])
    elif t == "open":
        if v:
            _spawn(["xdg-open", os.path.expanduser(v)])
    elif t == "system":
        if v == "killer" and shell is not None:
            shell.openKiller()
        elif v == "bgm":                         # 브금 켜기/끄기
            on = subprocess.run(["systemctl", "--user", "is-active", "--quiet", "beluga-bgm.service"]).returncode == 0
            subprocess.run(["systemctl", "--user", "stop" if on else "start", "beluga-bgm.service"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif v in SYSTEM:
            argv = SYSTEM[v]
            if argv[0] == "qdbus6" and not _have("qdbus6"):
                argv = ["qdbus"] + argv[1:]
            _spawn(argv)
    elif t == "sleep":
        sleep_action(v)


# ---- 절전 휠 ----
# "N분 뒤 절전" = 사용자 타이머(beluga-sleep-timer), "계속 안 꺼지기" = 절전/화면꺼짐 막기(beluga-keep-awake)
_UNITS = ("beluga-sleep-timer.timer", "beluga-sleep-timer.service", "beluga-keep-awake.service")


def _stop_all():
    subprocess.run(["systemctl", "--user", "stop", *_UNITS],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def sleep_action(v):
    if v == "now":
        _stop_all()
        _spawn(["systemctl", "suspend"])
        return
    _stop_all()
    if v == "reset":
        return
    if v == "never":
        inhibit = (["kde-inhibit", "--power", "--screenSaver", "sleep", "infinity"] if _have("kde-inhibit")
                   else ["systemd-inhibit", "--what=idle:sleep", "--who=Beluga", "--why=계속 안 꺼지기", "sleep", "infinity"])
        subprocess.run(["systemd-run", "--user", "--unit=beluga-keep-awake", "--collect", *inhibit],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return
    if v.isdigit():
        subprocess.run(["systemd-run", "--user", "--unit=beluga-sleep-timer", "--collect",
                        f"--on-active={int(v)}m", "systemctl", "suspend"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def sleep_state():
    """절전 휠 가운데에 보여줄 지금 상태"""
    def active(unit):
        return subprocess.run(["systemctl", "--user", "is-active", "--quiet", unit]).returncode == 0
    if active("beluga-keep-awake.service"):
        return "계속 켜 두는 중"
    if active("beluga-sleep-timer.timer"):
        r = subprocess.run(["systemctl", "--user", "show", "beluga-sleep-timer.timer",
                            "-p", "NextElapseUSecMonotonic", "--value"],
                           capture_output=True, text=True)
        try:
            with open("/proc/uptime") as f:
                up = float(f.read().split()[0])
            left = _usec(r.stdout.strip()) / 1e6 - up
            if left > 0:
                return f"{int(left // 60) + 1}분 뒤 절전"
        except (OSError, ValueError):
            pass
        return "절전 예약됨"
    return "보통 (시스템 설정대로)"


def _usec(s):
    # systemctl 값 예: "1h 5min 3.2s" 또는 숫자(µs)
    if s.isdigit():
        return int(s)
    total = 0.0
    for part in s.split():
        for unit, mul in (("min", 60e6), ("ms", 1e3), ("us", 1), ("h", 3600e6), ("s", 1e6)):
            if part.endswith(unit):
                total += float(part[: -len(unit)]) * mul
                break
    return total
