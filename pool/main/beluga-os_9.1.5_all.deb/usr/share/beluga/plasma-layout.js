// Beluga OS 기본 화면 배치 = 맥처럼
//   위: 메뉴바 (벨루가 메뉴 | 지금 앱의 메뉴(파일/편집…) ......... 한/영 | 트레이 | 날짜·시계)
//   아래: 가운데 떠 있는 반투명 독 (런치패드 | 앱들 | 휴지통)
// 새 사용자: KDE가 이 파일(org.debian.desktop 레이아웃)로 처음 화면을 만듦
// 기존 사용자: beluga-mac-ui 가 업데이트 후 한 번 이걸 다시 적용

// 이미 있는 패널은 지우고 새로 (기존 사용자에게 다시 적용할 때)
var old = panels();
for (var i = 0; i < old.length; i++) old[i].remove();

// ---- 위: 메뉴바 ----
var bar = new Panel;
bar.location = "top";
bar.height = 2 * Math.floor(gridUnit * 1.6 / 2);
bar.floating = false;
bar.lengthMode = "fill";
bar.opacity = "translucent";
bar.hiding = "none";

var menu = bar.addWidget("org.kde.plasma.kickoff");          // 맥의 사과 메뉴 자리 = 벨루가 메뉴
menu.currentConfigGroup = ["General"];
menu.writeConfig("icon", "/usr/share/pixmaps/beluga-start.png");
// (자체 사과 메뉴 위젯 org.beluga.menu 는 VM에서 아이콘이 안 그려져서 보류)
bar.addWidget("org.kde.plasma.appmenu");                      // 지금 앱의 메뉴 (파일/편집/보기…)
bar.addWidget("org.kde.plasma.panelspacer");
bar.addWidget("org.kde.plasma.kimpanel");                     // 한/영 입력기 표시
bar.addWidget("org.kde.plasma.systemtray");
var clock = bar.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", "true");
clock.writeConfig("dateDisplayFormat", "BesideTime");
clock.writeConfig("dateFormat", "custom");
clock.writeConfig("customDateFormat", "M월 d일 (ddd)");

// ---- 아래: 독 ----
var dock = new Panel;
dock.location = "bottom";
dock.height = 2 * Math.floor(gridUnit * 3.2 / 2);
dock.floating = true;                                          // 가장자리에서 떠 있음 + 둥근 모서리
dock.lengthMode = "fit";                                       // 폭 = 아이콘 개수만큼
dock.alignment = "center";
dock.opacity = "translucent";                                  // 뒤가 흐릿하게 비치는 유리
dock.hiding = "dodgewindows";                                  // 창이 독을 덮으면 숨고, 아래로 마우스 가져가면 나옴

var pad = dock.addWidget("org.kde.plasma.kickerdash");        // 런치패드 (앱 전체 화면)
pad.currentConfigGroup = ["General"];
pad.writeConfig("icon", "view-app-grid");
pad.currentConfigGroup = ["Shortcuts"];                        // ⊞ 키(혼자 누르기) = 런치패드 (KDE는 Alt+F1 단축키가 있는 런처를 엶)
pad.writeConfig("global", "Alt+F1");

var tasks = dock.addWidget("org.kde.plasma.icontasks");
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers", [
    "applications:org.kde.dolphin.desktop",
    "applications:firefox.desktop",
    "applications:google-chrome.desktop",
    "applications:com.anthropic.Claude.desktop",
    "applications:org.vinegarhq.Sober.desktop",
    "applications:org.vinegarhq.Vinegar.desktop",
    "applications:org.kde.discover.desktop",
    "applications:org.kde.konsole.desktop",
    "applications:systemsettings.desktop"
].join(","));
tasks.writeConfig("iconSpacing", "2");
tasks.writeConfig("indicateAudioStreams", "true");

dock.addWidget("org.kde.plasma.marginsseparator");
dock.addWidget("org.kde.plasma.trash");                        // 맥처럼 맨 끝에 휴지통

// 배경화면 = 벨루가
var desktopsArray = desktopsForActivity(currentActivity());
for (var j = 0; j < desktopsArray.length; j++) {
    desktopsArray[j].wallpaperPlugin = "org.kde.image";
    desktopsArray[j].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    desktopsArray[j].writeConfig("Image", "file:///usr/share/wallpapers/Beluga");
}
